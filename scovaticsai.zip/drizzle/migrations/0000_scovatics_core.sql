
create type public.app_role as enum ('admin','user');
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles readable" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- First signed-in user may claim admin only if no admin exists yet
create or replace function public.claim_first_admin()
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  if exists (select 1 from public.user_roles where role = 'admin') then
    return public.has_role(auth.uid(), 'admin');
  end if;
  insert into public.user_roles(user_id, role) values (auth.uid(), 'admin');
  return true;
end $$;
revoke execute on function public.claim_first_admin() from anon, public;
grant execute on function public.claim_first_admin() to authenticated;

create table public.assessments (
  id uuid primary key default gen_random_uuid(),
  access_token uuid not null unique default gen_random_uuid(),
  problem text not null,
  category text,
  status text not null default 'gathering',
  questions jsonb not null default '[]'::jsonb,
  answers jsonb not null default '[]'::jsonb,
  understanding jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant all on public.assessments to service_role;
grant select on public.assessments to authenticated;
alter table public.assessments enable row level security;
create policy "admins read assessments" on public.assessments for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.opportunity_reports (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null unique references public.assessments(id) on delete cascade,
  report jsonb not null,
  created_at timestamptz not null default now()
);
grant all on public.opportunity_reports to service_role;
grant select on public.opportunity_reports to authenticated;
alter table public.opportunity_reports enable row level security;
create policy "admins read reports" on public.opportunity_reports for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.leads (
  id uuid primary key default gen_random_uuid(),
  enquiry_ref text not null unique,
  assessment_id uuid references public.assessments(id) on delete set null,
  source text not null default 'contact',
  full_name text not null,
  email text not null,
  company text not null,
  job_role text not null,
  company_size text not null,
  country text not null,
  interest text not null,
  timeframe text not null,
  message text,
  status text not null default 'new',
  notes text,
  assigned_to text,
  next_follow_up date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant all on public.leads to service_role;
grant select, update on public.leads to authenticated;
alter table public.leads enable row level security;
create policy "admins read leads" on public.leads for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admins update leads" on public.leads for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.consent_records (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  consent_text text not null,
  created_at timestamptz not null default now()
);
grant all on public.consent_records to service_role;
grant select on public.consent_records to authenticated;
alter table public.consent_records enable row level security;
create policy "admins read consents" on public.consent_records for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.use_case_library (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  summary text not null,
  ai_application text not null,
  problem_category text not null,
  industries text[] not null default '{}',
  functions text[] not null default '{}',
  dependencies text,
  limitations text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.use_case_library to anon, authenticated;
grant insert, update, delete on public.use_case_library to authenticated;
grant all on public.use_case_library to service_role;
alter table public.use_case_library enable row level security;
create policy "public reads active use cases" on public.use_case_library for select to anon, authenticated using (active or public.has_role(auth.uid(),'admin'));
create policy "admins write use cases" on public.use_case_library for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.blog_posts (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  excerpt text not null,
  category text not null,
  body text not null,
  published boolean not null default true,
  published_at date not null default current_date,
  created_at timestamptz not null default now()
);
grant select on public.blog_posts to anon, authenticated;
grant insert, update, delete on public.blog_posts to authenticated;
grant all on public.blog_posts to service_role;
alter table public.blog_posts enable row level security;
create policy "public reads published posts" on public.blog_posts for select to anon, authenticated using (published or public.has_role(auth.uid(),'admin'));
create policy "admins write posts" on public.blog_posts for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.faqs (
  id uuid primary key default gen_random_uuid(),
  topic text not null,
  question text not null,
  answer text not null,
  sort_order int not null default 0,
  published boolean not null default true
);
grant select on public.faqs to anon, authenticated;
grant insert, update, delete on public.faqs to authenticated;
grant all on public.faqs to service_role;
alter table public.faqs enable row level security;
create policy "public reads faqs" on public.faqs for select to anon, authenticated using (published or public.has_role(auth.uid(),'admin'));
create policy "admins write faqs" on public.faqs for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.case_studies (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  illustrative boolean not null default true,
  industry text not null,
  client_context text not null,
  business_problem text not null,
  approach text not null,
  implementation text not null,
  outcomes text not null,
  lessons text not null,
  published boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.case_studies to anon, authenticated;
grant insert, update, delete on public.case_studies to authenticated;
grant all on public.case_studies to service_role;
alter table public.case_studies enable row level security;
create policy "public reads case studies" on public.case_studies for select to anon, authenticated using (published or public.has_role(auth.uid(),'admin'));
create policy "admins write case studies" on public.case_studies for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

insert into public.use_case_library (title, summary, ai_application, problem_category, industries, functions, dependencies, limitations) values
('Support query triage and drafted replies','Classifies incoming customer queries, routes them to the right team and drafts suggested replies from approved knowledge for agents to review.','Language understanding','Customer Support','{Technology,Finance,Healthcare,Logistics}','{Customer Support}','Ticketing system access; maintained knowledge base; historical tickets for evaluation.','Complex or sensitive cases still need human handling; drafts must be reviewed before sending.'),
('Self-service knowledge assistant','Answers common customer or employee questions using only approved company documents, with links to sources.','Retrieval-augmented assistant','Enterprise Knowledge','{Technology,Finance,Healthcare,Manufacturing}','{Customer Support,Operations,HR}','Curated, current documentation; access controls on sensitive content.','Quality depends on document coverage; must escalate when unsure.'),
('Content planning and drafting workflow','Generates first drafts of posts, captions and campaign variants from a brief and brand guidelines, inside an approval workflow.','Generative drafting','Marketing','{Technology,Finance,Manufacturing}','{Marketing}','Brand voice guidelines; content calendar; approval owners.','Drafts require editorial review; factual claims must be checked.'),
('Social performance summaries','Summarizes engagement data across channels into a weekly narrative with notable changes highlighted.','Analytics summarization','Marketing','{Technology}','{Marketing}','Export or API access to channel analytics.','Summaries describe what happened; they do not establish cause.'),
('Lead prioritization and follow-up prompts','Scores incoming leads against agreed criteria and reminds the sales team of follow-ups with suggested next messages.','Predictive scoring','Sales','{Technology,Finance,Manufacturing,Logistics}','{Sales}','CRM data with consistent fields; agreed qualification criteria.','Scoring reflects historical patterns and can carry their bias; reps retain judgement.'),
('Meeting and call summaries to CRM','Turns sales call notes or transcripts into structured CRM updates and action items.','Language understanding','Sales','{Technology,Finance}','{Sales}','Consent for recording; CRM integration.','Requires review for accuracy before committing to records.'),
('Document data extraction','Reads invoices, purchase orders, forms or contracts and extracts structured fields for review and entry into business systems.','Document intelligence','Document Processing','{Finance,Logistics,Healthcare,Manufacturing}','{Finance,Operations}','Representative document samples; target system for the data; exception handling owners.','Low-quality scans and unusual layouts need human verification.'),
('Automated report preparation','Assembles recurring operational or management reports from existing data sources with a written commentary draft.','Analytics summarization','Data & Reporting','{Manufacturing,Logistics,Finance,Healthcare,Technology}','{Finance,Operations}','Reliable data sources; agreed report definitions.','Commentary must be validated by the report owner.'),
('Workflow orchestration across systems','Connects systems that do not talk to each other, moving data and triggering steps with approvals where needed.','Integration and automation','Internal Workflows','{Technology,Manufacturing,Logistics,Finance}','{Operations,IT}','API or export access to each system; process owner sign-off.','Not every legacy system exposes integration points; some steps may stay manual.'),
('Candidate screening support','Summarizes applications against role criteria to help recruiters prioritise reviews.','Language understanding','HR','{Technology,Finance,Healthcare}','{HR}','Clear, job-relevant criteria; legal review for hiring use.','High-risk use: final decisions must remain human and be audited for fairness.'),
('Predictive maintenance signals','Uses equipment sensor and maintenance history to flag assets likely to need attention.','Predictive analytics','Manufacturing Operations','{Manufacturing,Logistics}','{Operations}','Sensor data with sufficient history; maintenance logs.','Requires adequate historical failure data; predictions are probabilistic.'),
('Visual quality inspection support','Assists inspectors by flagging possible defects in product images for confirmation.','Computer vision','Manufacturing Operations','{Manufacturing}','{Operations}','Labelled images of good and defective items; consistent imaging setup.','Lighting and setup changes affect accuracy; inspectors confirm results.'),
('Demand forecasting','Forecasts demand by product and location to support inventory and staffing decisions.','Forecasting','Logistics & Supply Chain','{Logistics,Manufacturing,Healthcare}','{Operations,Finance}','Clean historical sales and inventory data.','Unusual events reduce accuracy; forecasts support, not replace, planners.'),
('Shipment exception handling','Detects delayed or at-risk shipments and drafts customer or carrier communications.','Anomaly detection','Logistics & Supply Chain','{Logistics}','{Operations,Customer Support}','Tracking data feeds; communication templates.','Depends on timeliness of carrier data.'),
('Transaction anomaly review','Highlights unusual transactions or expense entries for finance team review.','Anomaly detection','Finance & Administration','{Finance,Technology}','{Finance}','Transaction history; agreed review thresholds.','Flags require investigation; false positives must be managed.'),
('Scheduling assistance','Proposes appointment or shift schedules that respect constraints and preferences.','Optimisation','Operations','{Healthcare,Logistics}','{Operations}','Calendar and constraint data.','Edge cases and urgent changes need staff judgement.'),
('Developer workflow assistance','Supports engineering teams with code review summaries, documentation drafts and internal tooling questions.','Generative drafting','Software & IT Operations','{Technology}','{IT}','Repository access policies; security review.','Generated code needs review and testing.'),
('IT service desk automation','Resolves routine IT requests such as access resets and routes the rest with context.','Language understanding','Software & IT Operations','{Technology,Finance,Healthcare}','{IT}','IT service management system integration; approved actions list.','Privileged actions require approval steps.');

insert into public.blog_posts (slug,title,excerpt,category,body,published_at) values
('start-with-the-problem','Start With the Problem, Not the Model','Why the most valuable AI initiatives begin with a clearly described operational problem rather than a technology choice.','Strategy',E'Most organisations that struggle with AI did not choose the wrong model. They chose a solution before they understood the problem.\n\n## Describe the work, not the wish\nA useful problem statement names who is doing the work, how often it happens, what it costs in time or quality, and what a better outcome would look like. "We want to use AI in customer service" is a wish. "Three agents spend most of each morning answering the same twenty questions about order status" is a problem.\n\n## Measure the current process\nBefore anything is automated, record how the process actually runs today. Even rough figures give you a baseline to judge whether a change helped.\n\n## Decide where people stay involved\nEvery workflow has steps where judgement matters. Name them early. AI can prepare, sort and draft; people should approve where the consequences warrant it.\n\n## Start small, then expand\nA narrow, well-measured pilot teaches more than a broad programme. Once it works, the same pattern often applies elsewhere.','2026-10-21'),
('document-workflows','Where Document Intelligence Actually Helps','A practical look at which document-heavy processes benefit from AI extraction, and which still need people.','Operations',E'Invoices, purchase orders, claims and contracts are among the most common candidates for AI in operations.\n\n## Good candidates\nHigh-volume documents with a reasonably consistent structure, where the extracted data goes into another system.\n\n## Harder cases\nHandwritten material, poor scans and documents where a single field changes the legal meaning.\n\n## Design for exceptions\nThe most important part of a document workflow is what happens when the system is unsure. Route those cases to a person with the relevant context already attached.','2026-10-08'),
('responsible-ai-basics','Responsible AI Is an Operating Practice','Governance is not a document you write once. It is how you run AI systems day to day.','Responsible AI',E'Responsible AI is often treated as a policy exercise. In practice it is operational.\n\n## Know what data goes where\nMap which data a system reads, where it is processed and who can see the output.\n\n## Keep humans accountable\nDecide which decisions an AI system may support and which it may never make alone.\n\n## Monitor after launch\nModels and data drift. Review samples of outputs regularly and keep a way for users to report problems.','2026-09-24'),
('reporting-time','Getting Hours Back From Recurring Reports','How teams reduce the time spent assembling the same reports every week.','Decision Intelligence',E'Recurring reports quietly consume significant time across finance and operations teams.\n\n## Separate assembly from analysis\nMost of the effort goes into collecting and formatting data, not thinking about it. That assembly work is a strong automation candidate.\n\n## Draft the commentary, own the conclusion\nAI can propose a written summary of what changed. The report owner should still confirm the interpretation.\n\n## Fix the data first\nIf the inputs are inconsistent, automation will only produce inconsistent reports faster.','2026-09-10');

insert into public.faqs (topic,question,answer,sort_order) values
('AI consulting','What does Scovatics actually do?','We help organisations identify where AI can improve specific business processes, decide which opportunities are worth pursuing, and design and implement practical solutions with appropriate controls.',1),
('Assessments','Is the AI Problem Solver assessment free?','Yes. The online assessment is free and gives you an initial view of relevant AI opportunities. It is a starting point, not a full implementation plan.',2),
('Assessments','How accurate is the AI-generated report?','It is based only on what you describe and a curated library of use cases. It identifies assumptions separately from the facts you provide. A consultation is needed to validate it against your actual systems and data.',3),
('Data privacy','What happens to the information I enter?','Your description and answers are stored so the report can be generated and, if you choose to contact us, reviewed by our team. Please avoid entering confidential or personal data in the assessment.',4),
('Pricing','How much does an engagement cost?','Pricing depends on scope. We agree a defined scope and fee before any work begins. We do not publish fixed prices because every engagement is different.',5),
('Project timelines','How long does an AI project take?','It varies with scope and readiness. A focused opportunity assessment is typically short; implementation timelines are agreed once systems, data and requirements are understood.',6),
('Existing systems','Do we need to replace our current systems?','Usually not. Most of our work connects AI capabilities to the systems you already use.',7),
('Human oversight','Will AI make decisions on its own?','Only where you decide that is appropriate. We design workflows with human review and approval wherever outcomes are consequential.',8),
('AI implementation','Do you build solutions or only advise?','Both. We can provide strategy and assessment only, or design, build, integrate and support solutions.',9);

insert into public.case_studies (slug,title,illustrative,industry,client_context,business_problem,approach,implementation,outcomes,lessons) values
('illustrative-support-triage','Illustrative example: Support query triage for a mid-sized distributor',true,'Logistics','This is an illustrative example showing how a case study is structured. It does not describe a real client.','A support team receives a high volume of repetitive order-status and returns questions, delaying responses to complex issues.','Map the current support process, categorise a sample of historical queries and identify which categories are routine and well documented.','Introduce query classification and drafted replies for routine categories, with agents reviewing every draft before sending.','Outcomes would be recorded here only once verified with the client, using the baseline measured at the start.','Knowledge base quality determined most of the result; defining escalation rules early avoided confusion.');
