# Scovatics — Enterprise AI Consulting Platform

A premium, gradient-free enterprise website with a working AI Problem Solver, opportunity reports, lead capture and a protected admin area. Built in stages, all on one shared design system.

## Visual direction
- Solid surfaces only: white base, Navy #062A73 for brand and primary buttons, Cyan #25C6E8 for small accents, light gray (#F5F7FA / #F8FAFC) section bands, 1px #E2E8F0 borders.
- Sora for display headings, Inter for body and interface.
- 12-column grid, max width about 1280px, editorial open layouts, restrained radii (6–10px).
- Calm motion: staged hero entrance, fade-and-rise on scroll (once), 150–350ms UI transitions, honors reduced motion.
- Corporate photography (generated, realistic, no robots or holograms) for industries and articles only.
- Text wordmark "SCOVATICS" in a swappable logo component until you upload the official logo.

## Stage 1 — Design system and shell
- Color, type, spacing and motion tokens; button, input and card variants.
- Sticky header with Services/Industries dropdowns, mobile slide-in menu, "Solve a Business Problem" CTA.
- Full footer with placeholder contact details clearly marked "to be supplied".

## Stage 2 — Homepage
All 12 sections from the brief: hero with live Problem Solver preview, problem input with clickable examples (carries text into the solver), How It Works, 12 problem areas (each opens the solver with a starter prompt), six services, five industries, Discover-to-Optimize approach, trust and responsible AI, latest insights, final CTA.

## Stage 3 — AI Problem Solver and Report (core)
1. Entry: large text area plus category chips.
2. AI reads the problem and asks only the follow-up questions it actually needs (2–5, generated per problem), one compact step at a time. Progress: Understanding Problem → Gathering Context → Preparing Assessment.
3. AI produces a structured report (streamed section by section) grounded in a curated use-case library: overview, challenges, 2–4 use cases, qualitative impact (no invented ROI or percentages), feasibility, next step, matched consulting options. Facts the visitor gave are separated from assumptions.
4. Report page has its own private link, copy and print (print-styled layout).
5. Choosing a consulting option opens the enquiry form (all required fields + consent). On confirmed save: unique enquiry ID, report linked, confirmation page.

## Stage 4 — Content pages
Services overview + 6 service pages, Industries overview + 5 industry pages, How It Works, Use Cases library (search + filters), Case Studies (template with clearly labelled illustrative example, no invented clients), Insights listing (search, categories) + article pages with reading time and related posts, About, FAQ, Contact, Responsible AI, Privacy, Terms, Enquiry Confirmation. Each page gets its own layout, title and share metadata; sitemap and robots included.

## Stage 5 — Admin (/admin)
Sign-in for staff only, with server-checked admin role. Dashboard with real counts only; leads (search, filter, status, notes, assignee, follow-up date, linked report); assessments and reports; use-case library editor (activate/deactivate); blog, FAQ and case study management.

## Things you will need to supply later
- Official logo, contact email/phone/address, LinkedIn URL, team info.
- Owner email address for new-lead notifications. Emails send only once a verified email domain is set up; until then every lead is still saved and visible in the admin area.
- Review of legal page text (drafts will be marked as drafts).

## Technical details
- Lovable Cloud for database, auth and server logic; Lovable AI for the assessment (default chat model, structured JSON schemas, streamed), key kept server-side; clear error state if AI is unavailable or out of credits — never a fake result.
- Tables: assessments, assessment_messages, opportunity_reports, recommended_use_cases, leads, consultations, use_case_library (seeded), blog_posts (seeded), faqs, case_studies, consent_records, user_roles (separate roles table + has_role function). RLS on everything; visitors reach their assessment only through an unguessable token via server functions; leads never readable publicly.
- Server functions: start assessment, submit answers / get next questions, generate report, get report by token, submit enquiry, admin CRUD (role-checked).
- TanStack routes per page, Motion for animation, shadcn + Lucide, tests for enquiry validation and admin authorization rules.
