<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Businesses leave with a clear, credible path to solving their problem with AI.

## Metric

Businesses that receive a completed Opportunity Report each week
