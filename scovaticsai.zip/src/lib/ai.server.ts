import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output, NoObjectGeneratedError, APICallError } from "ai";
import type { z } from "zod";

const GATEWAY = "https://ai.gateway.lovable.dev/v1";
const MODEL = "openai/gpt-6-astra";

export class AiError extends Error {
  constructor(message: string, public status: number) {
    super(message);
  }
}

function friendly(status: number, fallback?: string) {
  if (status === 402) return "The AI assessment is temporarily unavailable because AI credits are exhausted. Please try again later or contact us directly.";
  if (status === 429) return "The assessment service is busy right now. Please wait a moment and try again.";
  if (status === 403) return fallback || "The AI assessment is currently unavailable for this site.";
  if (status === 401) return "The AI assessment is not configured yet.";
  return "The assessment could not be completed. Please try again.";
}

export async function generateStructured<T extends z.ZodType>(opts: {
  schema: T;
  instructions: string;
  prompt: string;
}): Promise<z.infer<T>> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new AiError("The AI assessment is not configured yet.", 401);
  let runId: string | undefined;
  const provider = createOpenAI({
    baseURL: GATEWAY,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: async (input, init) => {
      const headers = new Headers(init?.headers);
      if (runId) headers.set("X-Lovable-AIG-Run-ID", runId);
      const res = await fetch(input, { ...init, headers });
      runId ??= res.headers.get("X-Lovable-AIG-Run-ID") ?? undefined;
      return res;
    },
  });
  try {
    const result = streamText({
      model: provider.responses(MODEL),
      instructions: opts.instructions,
      prompt: opts.prompt,
      output: Output.object({ schema: opts.schema }),
      providerOptions: {
        openai: {
          forceReasoning: true,
          reasoningEffort: "low",
          reasoningSummary: "auto",
          store: false,
          include: ["reasoning.encrypted_content"],
        },
      },
    } as Parameters<typeof streamText>[0]);
    return (await result.output) as z.infer<T>;
  } catch (e) {
    if (e instanceof AiError) throw e;
    if (APICallError.isInstance(e)) {
      const status = e.statusCode ?? 500;
      let msg: string | undefined;
      try { msg = JSON.parse(e.responseBody ?? "{}")?.error?.message ?? JSON.parse(e.responseBody ?? "{}")?.message; } catch {}
      throw new AiError(friendly(status, msg), status);
    }
    if (NoObjectGeneratedError.isInstance(e)) throw new AiError("The assessment returned an incomplete result. Please try again.", 502);
    console.error("AI error", e);
    throw new AiError(friendly(500), 500);
  }
}
