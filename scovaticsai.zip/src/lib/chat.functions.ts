import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { services } from "@/content/services";
import { industries } from "@/content/industries";

const input = z.object({
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(1500) })).min(1).max(20),
});
const out = z.object({
  reply: z.string().describe("Short, plain answer, max ~90 words"),
  action: z.enum(["none", "solve", "contact"]).describe("solve = suggest running the AI Problem Solver; contact = suggest a consultation"),
  problemSummary: z.string().describe("If action is solve, a one-sentence summary of the visitor's business problem; else empty"),
});

const INSTRUCTIONS = `You are the Scovatics website assistant. Scovatics is an enterprise AI consulting firm.
Services: ${services.map((s) => s.name).join(", ")}. Industries: ${industries.map((i) => i.name).join(", ")}.
Rules: be concise, professional and practical. Answer only about Scovatics, AI adoption and the visitor's business problem.
Never invent clients, case studies, prices, timelines, statistics, certifications, ROI or guarantees; say a consultant can discuss these.
When the visitor describes a concrete business problem, set action "solve". When they ask about pricing, hiring, meetings or next steps, set action "contact".`;

export const askAssistant = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => input.parse(d))
  .handler(async ({ data }) => {
    const { generateStructured, AiError } = await import("./ai.server");
    try {
      const r = await generateStructured({
        schema: out,
        instructions: INSTRUCTIONS,
        prompt: data.messages.map((m) => `${m.role === "user" ? "Visitor" : "Assistant"}: ${m.content}`).join("\n"),
      });
      return { ok: true as const, ...r };
    } catch (e) {
      return { ok: false as const, error: e instanceof AiError ? e.message : "The assistant is unavailable right now." };
    }
  });
