import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

type Ctx = { supabase: SupabaseClient<Database>; userId: string };

async function assertAdmin({ supabase, userId }: Ctx) {
  const { data } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (!data) throw new Error("Forbidden: admin access required");
}

export const getAdminStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    return { isAdmin: !!data };
  });

export const claimFirstAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("claim_first_admin");
    return { isAdmin: !!data };
  });

export const getDashboard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const s = context.supabase;
    const count = async (q: PromiseLike<{ count: number | null }>) => (await q).count ?? 0;
    const [leads, newLeads, qualified, consult, assessments, completed, withAssessment] = await Promise.all([
      count(s.from("leads").select("id", { count: "exact", head: true })),
      count(s.from("leads").select("id", { count: "exact", head: true }).eq("status", "new")),
      count(s.from("leads").select("id", { count: "exact", head: true }).eq("status", "qualified")),
      count(s.from("leads").select("id", { count: "exact", head: true }).eq("source", "report")),
      count(s.from("assessments").select("id", { count: "exact", head: true })),
      count(s.from("assessments").select("id", { count: "exact", head: true }).eq("status", "completed")),
      count(s.from("leads").select("id", { count: "exact", head: true }).not("assessment_id", "is", null)),
    ]);
    const { data: recent } = await s.from("leads").select("id, enquiry_ref, full_name, company, interest, status, created_at").order("created_at", { ascending: false }).limit(6);
    const { data: recentAssess } = await s.from("assessments").select("id, problem, category, status, created_at").order("created_at", { ascending: false }).limit(200);
    const cats: Record<string, number> = {};
    (recentAssess ?? []).forEach((a) => { const k = a.category || "Uncategorised"; cats[k] = (cats[k] ?? 0) + 1; });
    return { leads, newLeads, qualified, consult, assessments, completed, withAssessment, recent: recent ?? [], categories: Object.entries(cats).sort((a, b) => b[1] - a[1]) };
  });

export const listLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { data } = await context.supabase.from("leads").select("*").order("created_at", { ascending: false }).limit(1000);
    return data ?? [];
  });

export const getLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const s = context.supabase;
    const { data: lead } = await s.from("leads").select("*").eq("id", data.id).maybeSingle();
    if (!lead) return null;
    let assessment = null, report = null;
    if (lead.assessment_id) {
      assessment = (await s.from("assessments").select("*").eq("id", lead.assessment_id).maybeSingle()).data;
      report = (await s.from("opportunity_reports").select("report").eq("assessment_id", lead.assessment_id).maybeSingle()).data?.report ?? null;
    }
    const { data: consents } = await s.from("consent_records").select("*").eq("lead_id", lead.id);
    return { lead, assessment, report, consents: consents ?? [] };
  });

export const updateLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({
      id: z.string().uuid(),
      status: z.enum(["new", "contacted", "qualified", "proposal", "won", "lost"]),
      notes: z.string().max(5000).nullable(),
      assigned_to: z.string().max(120).nullable(),
      next_follow_up: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable(),
    }).parse(d),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { id, ...rest } = data;
    const { error } = await context.supabase.from("leads").update({ ...rest, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listAssessments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const s = context.supabase;
    const { data: a } = await s.from("assessments").select("id, problem, category, status, answers, created_at").order("created_at", { ascending: false }).limit(500);
    const { data: r } = await s.from("opportunity_reports").select("assessment_id, report");
    const map = new Map((r ?? []).map((x) => [x.assessment_id, x.report]));
    return (a ?? []).map((x) => ({ ...x, report: map.get(x.id) ?? null }));
  });

// Generic content management for use cases, blog posts, FAQs, case studies
const tables = ["use_case_library", "blog_posts", "faqs", "case_studies"] as const;
type T = (typeof tables)[number];

export const listContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ table: z.enum(tables) }).parse(d))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { data: rows } = await context.supabase.from(data.table as T).select("*");
    return JSON.stringify(rows ?? []);
  });

export const saveContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ table: z.enum(tables), id: z.string().uuid().nullable(), values: z.record(z.string(), z.unknown()) }).parse(d))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { id: _ignored, created_at: _c, ...values } = data.values as Record<string, unknown>;
    const q = context.supabase.from(data.table as T);
    const { error } = data.id
      ? await q.update(values as never).eq("id", data.id)
      : await q.insert(values as never);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ table: z.enum(tables), id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { error } = await context.supabase.from(data.table as T).delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
