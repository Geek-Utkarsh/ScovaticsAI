import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { understandingSchema, reportSchema, type Report, type Understanding } from "./assessment-schema";
import { services } from "@/content/services";

type Fail = { ok: false; error: string; status: number };

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

const UNDERSTAND_INSTRUCTIONS = `You are the intake analyst for Scovatics, an enterprise AI consulting firm.
A business visitor describes an operational problem in plain language. Your job:
1. Decide if this is a genuine business/operational problem (isBusinessProblem). If it is unrelated, abusive or nonsense, set false and return no questions.
2. Write a neutral 1–2 sentence summary in the visitor's terms and name the most affected department.
3. Ask ONLY the follow-up questions that are genuinely needed to give a useful initial assessment: between 2 and 5. Do not ask for anything already stated. Prioritise: team size involved, which activities take the most time, current tools/systems, volume or frequency, primary objective, constraints such as data sensitivity.
Each question must be short, plain-language, non-technical, and have 3–5 short answer options (the visitor may also type their own). Use ids q1, q2, ...
Never ask for personal data, contact details or confidential information.`;

const REPORT_INSTRUCTIONS = `You are a senior consultant at Scovatics writing a free initial AI opportunity assessment.
Rules:
- Base everything on the visitor's description and answers. List facts the visitor stated in providedFacts; list anything you inferred in assumptions. Never present an assumption as fact.
- Recommend 2–4 use cases. Prefer and adapt items from the APPROVED USE-CASE LIBRARY provided; only go beyond it when clearly justified.
- Impact must be qualitative (time efficiency, operational workload, process consistency, reporting efficiency, decision support, customer experience — only those relevant). NEVER give percentages, ROI, cost savings, monetary figures, headcount reduction, or guarantees.
- Feasibility: dependencies, data requirements, existing tools mentioned or likely needed, and human oversight needs.
- Do NOT provide system architecture, code, detailed integration maps, cost estimates or deployment plans; those belong in a paid engagement. Keep it genuinely useful but initial.
- nextStep: one practical, specific next step.
- consultingOptions: 1–3 of assessment (validate opportunity), workflow (implement a specific workflow), transformation (multi-department programme), each with a one-sentence reason tied to this problem, most relevant first.
- serviceSlugs: 1–3 slugs chosen from: ${services.map((s) => s.slug).join(", ")}.
- Use clear, professional British-neutral business English. No hype words like revolutionise or unlock.`;

export const startAssessment = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ problem: z.string().trim().min(15).max(3000), category: z.string().max(40).nullable() }).parse(d))
  .handler(async ({ data }): Promise<{ ok: true; token: string; understanding: Understanding } | Fail> => {
    const { generateStructured, AiError } = await import("./ai.server");
    let understanding: Understanding;
    try {
      understanding = await generateStructured({
        schema: understandingSchema,
        instructions: UNDERSTAND_INSTRUCTIONS,
        prompt: `Category selected by visitor: ${data.category ?? "not selected"}\n\nProblem description:\n"""${data.problem}"""`,
      });
    } catch (e) {
      const err = e instanceof AiError ? e : new AiError("The assessment could not be completed.", 500);
      return { ok: false, error: err.message, status: err.status };
    }
    if (!understanding.isBusinessProblem) {
      return { ok: false, status: 422, error: "We couldn't identify a business problem in that description. Please describe what is happening in your organisation — who is involved, and what is taking too much time or effort." };
    }
    understanding.questions = understanding.questions.slice(0, 5).map((q) => ({ ...q, options: q.options.slice(0, 5) }));
    const db = await admin();
    const { data: row, error } = await db
      .from("assessments")
      .insert({ problem: data.problem, category: data.category, questions: understanding.questions, understanding, status: "gathering" })
      .select("access_token")
      .single();
    if (error || !row) return { ok: false, status: 500, error: "Your assessment could not be saved. Please try again." };
    return { ok: true, token: row.access_token, understanding };
  });

export const generateReport = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({ token: z.string().uuid(), answers: z.array(z.object({ id: z.string().max(10), question: z.string().max(400), answer: z.string().max(1000) })).max(8) }).parse(d),
  )
  .handler(async ({ data }): Promise<{ ok: true } | Fail> => {
    const db = await admin();
    const { data: a } = await db.from("assessments").select("id, problem, category, understanding").eq("access_token", data.token).maybeSingle();
    if (!a) return { ok: false, status: 404, error: "This assessment could not be found." };
    const { data: existing } = await db.from("opportunity_reports").select("id").eq("assessment_id", a.id).maybeSingle();
    if (existing) return { ok: true };
    await db.from("assessments").update({ answers: data.answers, status: "analysing", updated_at: new Date().toISOString() }).eq("id", a.id);
    const { data: lib } = await db.from("use_case_library").select("title, summary, problem_category, functions, industries, dependencies, limitations").eq("active", true);
    const library = (lib ?? []).map((u) => `- ${u.title} [${u.problem_category}; ${u.functions.join("/")}]: ${u.summary} Dependencies: ${u.dependencies ?? "—"} Limitations: ${u.limitations ?? "—"}`).join("\n");
    const answered = data.answers.filter((x) => x.answer.trim());
    const { generateStructured, AiError } = await import("./ai.server");
    let report: Report;
    try {
      report = await generateStructured({
        schema: reportSchema,
        instructions: REPORT_INSTRUCTIONS,
        prompt: `APPROVED USE-CASE LIBRARY:\n${library}\n\nVISITOR CATEGORY: ${a.category ?? "not selected"}\n\nPROBLEM DESCRIPTION:\n"""${a.problem}"""\n\nFOLLOW-UP ANSWERS:\n${answered.length ? answered.map((x) => `Q: ${x.question}\nA: ${x.answer}`).join("\n") : "(visitor skipped follow-up questions)"}`,
      });
    } catch (e) {
      await db.from("assessments").update({ status: "failed" }).eq("id", a.id);
      const err = e instanceof AiError ? e : new AiError("The report could not be generated.", 500);
      return { ok: false, error: err.message, status: err.status };
    }
    report.useCases = report.useCases.slice(0, 4);
    report.serviceSlugs = report.serviceSlugs.filter((s) => services.some((x) => x.slug === s)).slice(0, 3);
    const { error } = await db.from("opportunity_reports").insert({ assessment_id: a.id, report });
    if (error) return { ok: false, status: 500, error: "Your report could not be saved. Please try again." };
    await db.from("assessments").update({ status: "completed", updated_at: new Date().toISOString() }).eq("id", a.id);
    return { ok: true };
  });

export const getReport = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ token: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const db = await admin();
    const { data: a } = await db.from("assessments").select("id, problem, category, created_at").eq("access_token", data.token).maybeSingle();
    if (!a) return null;
    const { data: r } = await db.from("opportunity_reports").select("report, created_at").eq("assessment_id", a.id).maybeSingle();
    if (!r) return null;
    return { problem: a.problem, category: a.category, createdAt: r.created_at, report: r.report as unknown as Report };
  });
