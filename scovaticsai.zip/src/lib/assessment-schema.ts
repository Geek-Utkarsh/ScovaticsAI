import { z } from "zod";

export const understandingSchema = z.object({
  isBusinessProblem: z.boolean(),
  summary: z.string(),
  department: z.string(),
  questions: z.array(z.object({ id: z.string(), question: z.string(), reason: z.string(), options: z.array(z.string()) })),
});
export type Understanding = z.infer<typeof understandingSchema>;

export const reportSchema = z.object({
  title: z.string(),
  problemOverview: z.string(),
  department: z.string(),
  providedFacts: z.array(z.string()),
  assumptions: z.array(z.string()),
  challenges: z.array(z.object({ title: z.string(), detail: z.string() })),
  useCases: z.array(z.object({ title: z.string(), whatItDoes: z.string(), relevance: z.string(), benefit: z.string(), considerations: z.string() })),
  impact: z.array(z.object({ area: z.string(), description: z.string() })),
  feasibility: z.object({
    dependencies: z.array(z.string()),
    dataRequirements: z.array(z.string()),
    existingTools: z.array(z.string()),
    humanOversight: z.array(z.string()),
  }),
  risks: z.array(z.string()),
  missingInformation: z.array(z.string()),
  nextStep: z.object({ title: z.string(), description: z.string() }),
  consultingOptions: z.array(z.object({ key: z.enum(["assessment", "workflow", "transformation"]), reason: z.string() })),
  serviceSlugs: z.array(z.string()),
});
export type Report = z.infer<typeof reportSchema>;
