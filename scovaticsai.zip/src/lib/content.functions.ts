import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

function pub() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient<Database>(process.env["SUPABASE_URL"]!, key, {
    auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const listPosts = createServerFn({ method: "GET" }).handler(async () => {
  const { data } = await pub().from("blog_posts").select("slug, title, excerpt, category, published_at, body").eq("published", true).order("published_at", { ascending: false });
  return (data ?? []).map(({ body, ...p }) => ({ ...p, readingMinutes: Math.max(1, Math.round(body.split(/\s+/).length / 220)) }));
});

export const getPost = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ slug: z.string().max(200) }).parse(d))
  .handler(async ({ data }) => {
    const { data: p } = await pub().from("blog_posts").select("slug, title, excerpt, category, published_at, body").eq("slug", data.slug).eq("published", true).maybeSingle();
    if (!p) return null;
    return { ...p, readingMinutes: Math.max(1, Math.round(p.body.split(/\s+/).length / 220)) };
  });

export const listFaqs = createServerFn({ method: "GET" }).handler(async () => {
  const { data } = await pub().from("faqs").select("id, topic, question, answer").eq("published", true).order("sort_order");
  return data ?? [];
});

export const listUseCases = createServerFn({ method: "GET" }).handler(async () => {
  const { data } = await pub().from("use_case_library").select("id, title, summary, ai_application, problem_category, industries, functions, dependencies, limitations").eq("active", true).order("title");
  return data ?? [];
});

export const listCaseStudies = createServerFn({ method: "GET" }).handler(async () => {
  const { data } = await pub().from("case_studies").select("*").eq("published", true).order("created_at", { ascending: false });
  return data ?? [];
});

export const getCaseStudy = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ slug: z.string().max(200) }).parse(d))
  .handler(async ({ data }) => {
    const { data: c } = await pub().from("case_studies").select("*").eq("slug", data.slug).eq("published", true).maybeSingle();
    return c ?? null;
  });
