import { queryOptions } from "@tanstack/react-query";
import { listPosts, getPost, listFaqs, listUseCases, listCaseStudies, getCaseStudy } from "./content.functions";
import { getReport } from "./assessment.functions";

export const postsQuery = queryOptions({ queryKey: ["posts"], queryFn: () => listPosts() });
export const postQuery = (slug: string) => queryOptions({ queryKey: ["post", slug], queryFn: () => getPost({ data: { slug } }) });
export const faqsQuery = queryOptions({ queryKey: ["faqs"], queryFn: () => listFaqs() });
export const useCasesQuery = queryOptions({ queryKey: ["use-cases"], queryFn: () => listUseCases() });
export const caseStudiesQuery = queryOptions({ queryKey: ["case-studies"], queryFn: () => listCaseStudies() });
export const caseStudyQuery = (slug: string) => queryOptions({ queryKey: ["case-study", slug], queryFn: () => getCaseStudy({ data: { slug } }) });
export const reportQuery = (token: string) => queryOptions({ queryKey: ["report", token], queryFn: () => getReport({ data: { token } }) });

export const fmtDate = (d: string) => new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
