import { z } from "zod";

export const companySizes = ["1–10", "11–50", "51–200", "201–1,000", "1,001–5,000", "5,000+"];
export const timeframes = ["Immediately", "Within 3 months", "3–6 months", "6–12 months", "Exploring options"];
export const interests = ["AI Opportunity Assessment", "AI Workflow Implementation", "Enterprise AI Transformation", "AI Strategy Consulting", "Enterprise AI Integration", "AI Solution Development", "Business Process Transformation", "Responsible AI Adoption", "Decision Intelligence", "General enquiry"];

const freeMail = /@(gmail|yahoo|hotmail|outlook|live|aol|icloud|proton|protonmail|gmx|yandex|mail)\./i;

export const enquirySchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name").max(120),
  email: z.string().trim().email("Enter a valid email").max(200).refine((v) => !freeMail.test(v), "Please use your business email address"),
  company: z.string().trim().min(1, "Enter your company name").max(160),
  jobRole: z.string().trim().min(2, "Enter your job role").max(120),
  companySize: z.enum(companySizes as [string, ...string[]], { message: "Select company size" }),
  country: z.string().trim().min(2, "Enter your country").max(80),
  interest: z.enum(interests as [string, ...string[]], { message: "Select an area of interest" }),
  timeframe: z.enum(timeframes as [string, ...string[]], { message: "Select a timeframe" }),
  message: z.string().trim().max(3000).optional().or(z.literal("")),
  consent: z.literal(true, { message: "Please confirm consent so we can respond" }),
  assessmentToken: z.string().uuid().optional().nullable(),
  source: z.enum(["report", "contact"]),
});
export type EnquiryInput = z.infer<typeof enquirySchema>;

export const CONSENT_TEXT = "I agree that Scovatics may store the information I have provided, including any linked assessment, and contact me about this enquiry. I can ask for my data to be deleted at any time.";

export function makeEnquiryRef(date = new Date(), rand: () => number = Math.random) {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const d = date.toISOString().slice(2, 10).replace(/-/g, "");
  let s = "";
  for (let i = 0; i < 6; i++) s += alphabet[Math.floor(rand() * alphabet.length)];
  return `SCV-${d}-${s}`;
}
