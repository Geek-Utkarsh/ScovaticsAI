import { createServerFn } from "@tanstack/react-start";
import { enquirySchema, makeEnquiryRef, CONSENT_TEXT } from "./enquiry-schema";

export const submitEnquiry = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => enquirySchema.parse(d))
  .handler(async ({ data }): Promise<{ ok: true; ref: string } | { ok: false; error: string }> => {
    const { supabaseAdmin: db } = await import("@/integrations/supabase/client.server");
    let assessmentId: string | null = null;
    if (data.assessmentToken) {
      const { data: a } = await db.from("assessments").select("id").eq("access_token", data.assessmentToken).maybeSingle();
      assessmentId = a?.id ?? null;
    }
    for (let attempt = 0; attempt < 3; attempt++) {
      const ref = makeEnquiryRef();
      const { data: lead, error } = await db
        .from("leads")
        .insert({
          enquiry_ref: ref,
          assessment_id: assessmentId,
          source: data.source,
          full_name: data.fullName,
          email: data.email.toLowerCase(),
          company: data.company,
          job_role: data.jobRole,
          company_size: data.companySize,
          country: data.country,
          interest: data.interest,
          timeframe: data.timeframe,
          message: data.message || null,
        })
        .select("id")
        .single();
      if (error?.code === "23505") continue;
      if (error || !lead) return { ok: false, error: "Your enquiry could not be submitted. Please try again." };
      await db.from("consent_records").insert({ lead_id: lead.id, consent_text: CONSENT_TEXT });
      return { ok: true, ref };
    }
    return { ok: false, error: "Your enquiry could not be submitted. Please try again." };
  });
