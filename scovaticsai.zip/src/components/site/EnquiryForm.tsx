import { useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { enquirySchema, companySizes, timeframes, interests, CONSENT_TEXT } from "@/lib/enquiry-schema";
import { submitEnquiry } from "@/lib/leads.functions";

const field = "mt-2 block w-full rounded-md border border-border-strong bg-background px-3.5 py-2.5 text-[0.95rem] text-foreground focus:border-primary focus:outline-none aria-[invalid=true]:border-destructive";

function F({ name, label, errors, children }: { name: string; label: string; errors: Record<string, string>; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={`f-${name}`} className="text-sm font-medium text-foreground">{label}</label>
      {children}
      {errors[name] && <p id={`e-${name}`} className="mt-1.5 text-xs text-destructive">{errors[name]}</p>}
    </div>
  );
}

export function EnquiryForm({ defaultInterest, assessmentToken, source }: { defaultInterest?: string; assessmentToken?: string; source: "report" | "contact" }) {
  const navigate = useNavigate();
  const send = useServerFn(submitEnquiry);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const raw = {
      fullName: fd.get("fullName"), email: fd.get("email"), company: fd.get("company"), jobRole: fd.get("jobRole"),
      companySize: fd.get("companySize"), country: fd.get("country"), interest: fd.get("interest"), timeframe: fd.get("timeframe"),
      message: fd.get("message") ?? "", consent: fd.get("consent") === "on", assessmentToken: assessmentToken ?? null, source,
    };
    const parsed = enquirySchema.safeParse(raw);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => { const k = String(i.path[0]); errs[k] ??= i.message; });
      setErrors(errs);
      document.getElementById(`f-${Object.keys(errs)[0]}`)?.focus();
      return;
    }
    setErrors({}); setBusy(true); setServerError(null);
    try {
      const r = await send({ data: parsed.data });
      if (!r.ok) { setServerError(r.error); return; }
      navigate({ to: "/enquiry/confirmed", search: { ref: r.ref } });
    } catch {
      setServerError("Your enquiry could not be submitted. Please check your connection and try again.");
    } finally { setBusy(false); }
  };

  const a = (n: string) => ({ id: `f-${n}`, name: n, "aria-invalid": !!errors[n], "aria-describedby": errors[n] ? `e-${n}` : undefined });

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
      <F errors={errors} name="fullName" label="Full name"><input {...a("fullName")} autoComplete="name" className={field} /></F>
      <F errors={errors} name="email" label="Business email"><input {...a("email")} type="email" autoComplete="email" className={field} /></F>
      <F errors={errors} name="company" label="Company name"><input {...a("company")} autoComplete="organization" className={field} /></F>
      <F errors={errors} name="jobRole" label="Job role"><input {...a("jobRole")} autoComplete="organization-title" className={field} /></F>
      <F errors={errors} name="companySize" label="Company size"><select {...a("companySize")} defaultValue="" className={field}><option value="" disabled>Select</option>{companySizes.map((s) => <option key={s}>{s}</option>)}</select></F>
      <F errors={errors} name="country" label="Country"><input {...a("country")} autoComplete="country-name" className={field} /></F>
      <F errors={errors} name="interest" label="Consulting interest"><select {...a("interest")} defaultValue={defaultInterest ?? ""} className={field}><option value="" disabled>Select</option>{interests.map((s) => <option key={s}>{s}</option>)}</select></F>
      <F errors={errors} name="timeframe" label="Preferred starting timeframe"><select {...a("timeframe")} defaultValue="" className={field}><option value="" disabled>Select</option>{timeframes.map((s) => <option key={s}>{s}</option>)}</select></F>
      <div className="sm:col-span-2"><F errors={errors} name="message" label="Anything else we should know? (optional)"><textarea {...a("message")} rows={4} maxLength={3000} className={field} /></F></div>
      <div className="sm:col-span-2">
        <label className="flex items-start gap-3 text-sm leading-relaxed text-muted-foreground">
          <input type="checkbox" {...a("consent")} className="mt-1 h-4 w-4 shrink-0 accent-[var(--color-primary)]" />
          <span>{CONSENT_TEXT} See our <a href="/privacy" className="text-primary underline">Privacy Policy</a>.</span>
        </label>
        {errors["consent"] && <p id="e-consent" className="mt-1.5 text-xs text-destructive">{errors["consent"]}</p>}
      </div>
      {serverError && <p role="alert" className="text-sm text-destructive sm:col-span-2">{serverError}</p>}
      <div className="sm:col-span-2">
        <Button type="submit" size="lg" disabled={busy}>{busy ? <><Loader2 className="animate-spin" /> Submitting…</> : <>Submit Enquiry <ArrowRight /></>}</Button>
      </div>
    </form>
  );
}
