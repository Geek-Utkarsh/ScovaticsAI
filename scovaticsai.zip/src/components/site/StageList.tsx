import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { Plus } from "lucide-react";

/** Large expandable editorial list (one stage open at a time). */
export function StageList({ items }: { items: { name: string; text: string }[] }) {
  const [open, setOpen] = useState(0);
  return (
    <ul className="border-t border-border">
      {items.map((m, i) => {
        const on = open === i;
        return (
          <li key={m.name} className="border-b border-border">
            <button type="button" aria-expanded={on} onClick={() => setOpen(on ? -1 : i)} className="group grid w-full grid-cols-[3rem_1fr_auto] items-center gap-4 py-6 text-left sm:grid-cols-[5rem_1fr_auto] lg:py-8">
              <span className={`font-display text-sm tabular-nums transition-colors ${on ? "text-signal" : "text-muted-foreground"}`}>0{i + 1}</span>
              <span className={`text-[clamp(1.75rem,4.5vw,3.5rem)] font-medium leading-none tracking-[-0.04em] transition-all duration-300 ${on ? "translate-x-2 text-primary" : "text-foreground"}`}>{m.name}</span>
              <span className={`grid h-10 w-10 place-items-center rounded-full border transition-all duration-300 ${on ? "rotate-45 border-primary bg-primary text-primary-foreground" : "border-border-strong text-foreground"}`}><Plus className="h-4 w-4" /></span>
            </button>
            <AnimatePresence initial={false}>
              {on && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }} className="overflow-hidden">
                  <p className="max-w-xl pb-8 pl-[4rem] text-lg leading-relaxed text-muted-foreground sm:pl-[6rem]">{m.text}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </li>
        );
      })}
    </ul>
  );
}
