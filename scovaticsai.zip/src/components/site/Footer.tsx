import { Link, useRouterState } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { contact, telHref } from "@/content/contact";
import { services } from "@/content/services";
import { industries } from "@/content/industries";

export function Footer() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  if (path.startsWith("/admin")) return null;
  const h = "mb-4 text-xs font-semibold uppercase tracking-[0.14em] text-foreground";
  const a = "text-sm text-muted-foreground transition-colors hover:text-primary";
  return (
    <footer data-site-footer className="border-t border-border bg-surface">
      <div className="container-page grid gap-12 py-16 lg:grid-cols-12 lg:py-20">
        <div className="lg:col-span-4">
          <Logo />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">Enterprise AI consulting, integration and business process transformation. We help organisations find practical AI opportunities and implement them responsibly.</p>
          <div className="mt-6 space-y-1.5 text-sm text-muted-foreground">
            <p><a href={`mailto:${contact.primaryEmail}`} className="hover:text-primary">{contact.primaryEmail}</a></p>
            <p><a href={telHref(contact.primaryPhone)} className="hover:text-primary">{contact.primaryPhone}</a></p>
            <p>{contact.address.join(", ")}</p>
            <p>LinkedIn: <span className="italic">link to be supplied</span></p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-10 sm:grid-cols-4 lg:col-span-8">
          <div><p className={h}>Services</p><ul className="space-y-2.5">{services.map((s) => <li key={s.slug}><Link to="/services/$slug" params={{ slug: s.slug }} className={a}>{s.name}</Link></li>)}</ul></div>
          <div><p className={h}>Industries</p><ul className="space-y-2.5">{industries.map((s) => <li key={s.slug}><Link to="/industries/$slug" params={{ slug: s.slug }} className={a}>{s.name}</Link></li>)}</ul></div>
          <div><p className={h}>Explore</p><ul className="space-y-2.5">
            <li><Link to="/solve" className={a}>AI Problem Solver</Link></li>
            <li><Link to="/how-it-works" className={a}>How It Works</Link></li>
            <li><Link to="/use-cases" className={a}>Use Cases</Link></li>
            <li><Link to="/case-studies" className={a}>Case Studies</Link></li>
            <li><Link to="/insights" className={a}>Insights</Link></li>
          </ul></div>
          <div><p className={h}>Company</p><ul className="space-y-2.5">
            <li><Link to="/about" className={a}>About</Link></li>
            <li><Link to="/faq" className={a}>FAQ</Link></li>
            <li><Link to="/contact" className={a}>Contact</Link></li>
            <li><Link to="/responsible-ai" className={a}>Responsible AI</Link></li>
            <li><Link to="/privacy" className={a}>Privacy Policy</Link></li>
            <li><Link to="/terms" className={a}>Terms of Use</Link></li>
          </ul></div>
        </div>
      </div>
      <div className="container-page overflow-hidden" aria-hidden>
        <p className="select-none whitespace-nowrap font-display text-[clamp(4rem,17vw,15rem)] font-semibold leading-[0.8] tracking-[-0.05em] text-primary/[0.06]">SCOVATICS</p>
      </div>
      <div className="border-t border-border">
        <div className="container-page flex flex-col justify-between gap-2 py-6 text-xs text-muted-foreground sm:flex-row">
          <p>© {new Date().getFullYear()} Scovatics. All rights reserved.</p>
          <p>AI assessments are indicative and require professional validation.</p>
        </div>
      </div>
    </footer>
  );
}
