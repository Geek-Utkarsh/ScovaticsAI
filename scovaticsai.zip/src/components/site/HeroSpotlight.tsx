import { Link } from "@tanstack/react-router";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useEffect, useState } from "react";
import { ArrowRight, Pause, Play } from "lucide-react";

const slides = [
  { kicker: "AI Problem Solver", title: "Your business has challenges. AI can help find the way forward.", text: "Describe what is slowing your organisation down and receive an initial AI opportunity assessment in minutes.", cta: "Find your AI opportunity", to: "/solve" as const },
  { kicker: "Services", title: "AI strategy meets real business implementation.", text: "From readiness and prioritisation to integration, development and responsible adoption.", cta: "Explore our services", to: "/services" as const },
  { kicker: "Responsible AI", title: "Controls designed in from day one.", text: "Privacy, human oversight, security and transparency are part of every engagement, not added afterwards.", cta: "Our principles", to: "/responsible-ai" as const },
];
const DURATION = 6500;

/** Auto-rotating editorial spotlight with segmented progress and pause control. */
export function HeroSpotlight() {
  const reduce = useReducedMotion();
  const [i, setI] = useState(0);
  const [playing, setPlaying] = useState(true);
  useEffect(() => {
    if (!playing || reduce) return;
    const t = setTimeout(() => setI((v) => (v + 1) % slides.length), DURATION);
    return () => clearTimeout(t);
  }, [i, playing, reduce]);
  const s = slides[i] ?? slides[0]!;
  return (
    <div>
      <div className="flex items-center gap-2">
        {slides.map((sl, k) => (
          <button key={sl.kicker} type="button" onClick={() => setI(k)} aria-label={`Show ${sl.kicker}`} className="group relative h-6 flex-1">
            <span className="absolute inset-x-0 top-1/2 h-[3px] -translate-y-1/2 bg-ink-foreground/20" />
            <span
              key={`${k}-${i}-${playing}`}
              className="absolute left-0 top-1/2 h-[3px] -translate-y-1/2 bg-signal"
              style={{ width: k < i ? "100%" : k === i ? (playing && !reduce ? undefined : "100%") : "0%", animation: k === i && playing && !reduce ? `grow ${DURATION}ms linear forwards` : undefined }}
            />
          </button>
        ))}
        <button type="button" onClick={() => setPlaying((p) => !p)} aria-label={playing ? "Pause slideshow" : "Play slideshow"} className="ml-2 grid h-7 w-7 place-items-center rounded-full border border-ink-foreground/25 text-ink-foreground/80 hover:bg-ink-foreground/10">
          {playing ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
        </button>
      </div>
      <div className="relative mt-6 min-h-[260px] sm:min-h-[230px]" aria-live="polite">
        <AnimatePresence mode="wait">
          <motion.div key={i} initial={reduce ? false : { opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-signal">0{i + 1} / {s.kicker}</p>
            <p className="mt-4 text-[1.5rem] font-semibold leading-[1.2] tracking-[-0.02em] text-ink-foreground">{s.title}</p>
            <p className="mt-4 text-[1.0625rem] leading-relaxed text-ink-foreground/70">{s.text}</p>
            <Link to={s.to} className="group mt-7 inline-flex items-center gap-3 font-semibold text-ink-foreground">
              {s.cta}
              <span className="grid h-8 w-8 place-items-center bg-signal text-ink transition-transform duration-300 group-hover:translate-x-1"><ArrowRight className="h-4 w-4" /></span>
            </Link>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
