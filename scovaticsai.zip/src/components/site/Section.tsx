import type { ReactNode } from "react";
import { Reveal } from "./Reveal";
import { GridLines } from "./GridLines";

export function Section({ children, tone = "white", className = "", id }: { children: ReactNode; tone?: "white" | "surface" | "navy"; className?: string; id?: string }) {
  const bg = tone === "surface" ? "bg-surface" : tone === "navy" ? "bg-primary text-primary-foreground" : "bg-background";
  return (
    <section id={id} className={`section-y ${bg} ${tone !== "white" ? "" : ""} ${className}`}>
      <div className="container-page">{children}</div>
    </section>
  );
}

export function SectionHeading({ eyebrow, title, text, align = "left", invert = false }: { eyebrow?: string; title: ReactNode; text?: ReactNode; align?: "left" | "center"; invert?: boolean }) {
  return (
    <Reveal className={`mb-12 max-w-3xl lg:mb-16 ${align === "center" ? "mx-auto text-center" : ""}`}>
      {eyebrow && <p className={`eyebrow mb-6 flex items-center gap-3 ${align === "center" ? "justify-center" : ""} ${invert ? "text-signal" : ""}`}><span className="h-1.5 w-1.5 bg-signal" />{eyebrow}</p>}
      <h2 className={`display-lg ${invert ? "text-primary-foreground" : "text-foreground"}`}>{title}</h2>
      {text && <p className={`lead mt-5 ${invert ? "text-primary-foreground/75" : ""}`}>{text}</p>}
    </Reveal>
  );
}

export function PageHero({ eyebrow, title, text, children }: { eyebrow: string; title: ReactNode; text?: ReactNode; children?: ReactNode }) {
  return (
    <section className="relative overflow-hidden border-b border-border bg-surface pb-16 pt-32 lg:pb-24 lg:pt-44">
      <GridLines className="text-border/70" size={72} />
      <div className="container-page relative">
        <Reveal className="max-w-4xl">
          <p className="eyebrow mb-6 flex items-center gap-3"><span className="h-1.5 w-1.5 bg-signal" />{eyebrow}</p>
          <h1 className="display-xl text-foreground">{title}</h1>
          {text && <p className="lead mt-6 max-w-2xl">{text}</p>}
          {children && <div className="mt-9 flex flex-wrap gap-3">{children}</div>}
        </Reveal>
      </div>
    </section>
  );
}
