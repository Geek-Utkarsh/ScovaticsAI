import { useEffect, useState } from "react";
import { useNavigate, useRouterState } from "@tanstack/react-router";
import { AnimatePresence, motion } from "motion/react";
import { ArrowRight, Check, ShieldCheck, X } from "lucide-react";

const KEY = "scovatics-popup-seen";
const SKIP = ["/admin", "/solve", "/report", "/contact", "/auth", "/enquiry"];
const POINTS = ["Describe your problem in plain words", "Answer a few targeted questions", "Get a structured AI opportunity report"];

export function LeavePopup() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const skip = SKIP.some((p) => path.startsWith(p));

  useEffect(() => {
    if (skip || sessionStorage.getItem(KEY)) return;
    const show = () => { if (document.querySelector("[aria-label='Scovatics assistant']")) { window.setTimeout(show, 20000); return; } if (!sessionStorage.getItem(KEY)) { sessionStorage.setItem(KEY, "1"); setOpen(true); } };
    const onLeave = (e: MouseEvent) => { if (!e.relatedTarget && e.clientY <= 0) show(); };
    const timer = window.setTimeout(show, 45000); // mobile / touch fallback
    document.addEventListener("mouseout", onLeave);
    return () => { clearTimeout(timer); document.removeEventListener("mouseout", onLeave); };
  }, [skip]);

  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open]);

  function go() {
    setOpen(false);
    navigate({ to: "/solve", search: { q: text.trim() || undefined, c: undefined } });
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[70] flex items-end justify-center bg-ink/60 p-0 backdrop-blur-sm sm:items-center sm:p-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)}>
          <motion.div
            role="dialog" aria-modal="true" aria-labelledby="leave-title"
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 40 }} transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="relative grid max-h-[92dvh] w-full max-w-4xl overflow-y-auto rounded-t-3xl bg-background shadow-2xl sm:rounded-3xl md:grid-cols-[1.05fr_1fr]"
          >
            <button onClick={() => setOpen(false)} aria-label="Close" className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-background/90 text-foreground shadow hover:bg-surface"><X className="h-4 w-4" /></button>
            <div className="relative overflow-hidden bg-ink p-7 text-ink-foreground sm:p-10">
              <svg aria-hidden className="absolute inset-0 h-full w-full opacity-[0.07]"><defs><pattern id="pg" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M32 0H0V32" fill="none" stroke="currentColor" /></pattern></defs><rect width="100%" height="100%" fill="url(#pg)" /></svg>
              <div className="relative">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-signal">Before you go</p>
                <h2 id="leave-title" className="mt-4 text-3xl font-semibold leading-[1.05] tracking-tight sm:text-4xl">Find your AI opportunity in a few minutes.</h2>
                <p className="mt-4 text-sm leading-relaxed text-ink-foreground/70">A free, private assessment that starts with your business problem, not with AI tools.</p>
                <ul className="mt-7 space-y-3">
                  {POINTS.map((p, i) => (
                    <motion.li key={p} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.08 }} className="flex items-center gap-3 text-sm">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-signal/15 text-signal"><Check className="h-3.5 w-3.5" /></span>{p}
                    </motion.li>
                  ))}
                </ul>
              </div>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); go(); }} className="flex flex-col p-7 sm:p-10">
              <label htmlFor="leave-q" className="text-sm font-semibold text-foreground">What is your business trying to improve?</label>
              <textarea id="leave-q" value={text} onChange={(e) => setText(e.target.value)} rows={5} maxLength={3000} placeholder="For example: our support team answers the same customer questions every day…" className="mt-3 w-full resize-none rounded-xl border border-border-strong bg-background px-4 py-3 text-[16px] text-foreground focus:border-primary focus:outline-none sm:text-sm" />
              <p className="mt-3 flex items-center gap-2 rounded-lg bg-surface px-3 py-2.5 text-xs text-muted-foreground"><ShieldCheck className="h-4 w-4 shrink-0 text-primary" />No sign-up needed. Your description stays private.</p>
              <button type="submit" className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90">Analyze my problem <ArrowRight className="h-4 w-4" /></button>
              <button type="button" onClick={() => setOpen(false)} className="mt-3 text-xs text-muted-foreground hover:text-foreground">Maybe later</button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
