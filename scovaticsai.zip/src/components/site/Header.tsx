import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, ChevronDown, Menu, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";
import { Button } from "@/components/ui/button";
import { services } from "@/content/services";
import { industries } from "@/content/industries";

type Drop = "services" | "industries" | null;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [drop, setDrop] = useState<Drop>(null);
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => { setOpen(false); setDrop(null); }, [path]);
  useEffect(() => { document.body.style.overflow = open ? "hidden" : ""; }, [open]);

  if (path.startsWith("/admin")) return null;

  const onDark = path === "/" && !scrolled && !open;
  const linkCls = `rounded-md px-3 py-2 text-[0.875rem] transition-colors ${onDark ? "text-ink-foreground/80 hover:text-ink-foreground" : "text-foreground/75 hover:text-primary"}`;
  const active = { className: onDark ? "!text-ink-foreground font-medium" : "!text-primary font-medium" };

  return (
    <header data-site-header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-4">
      <div className={`mx-auto flex h-14 max-w-[1320px] items-center justify-between gap-6 rounded-2xl border px-4 transition-[background-color,border-color,box-shadow] duration-300 sm:px-5 lg:h-16 ${!onDark ? "border-border bg-background/90 shadow-[0_8px_30px_-12px_color-mix(in_oklab,var(--color-primary)_25%,transparent)] backdrop-blur-xl" : "border-transparent bg-transparent"}`}>
        <Logo invert={onDark} />
        <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex" onMouseLeave={() => setDrop(null)}>
          <Link to="/" className={linkCls} activeProps={active} activeOptions={{ exact: true }}>Home</Link>
          {(["services", "industries"] as const).map((k) => (
            <div key={k} className="relative" onMouseEnter={() => setDrop(k)}>
              <button type="button" aria-expanded={drop === k} aria-haspopup="true" onClick={() => setDrop(drop === k ? null : k)} onFocus={() => setDrop(k)} className={`${linkCls} inline-flex items-center gap-1 capitalize`}>
                {k} <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-200 ${drop === k ? "rotate-180" : ""}`} />
              </button>
              <AnimatePresence>
                {drop === k && (
                  <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.18 }} className="absolute left-1/2 top-full w-[560px] -translate-x-1/2 pt-3">
                    <div className="rounded-lg border border-border bg-popover p-3 shadow-[0_16px_40px_-20px_rgba(6,42,115,0.25)]">
                      <div className="grid grid-cols-2 gap-1">
                        {k === "services"
                          ? services.map((s) => (
                              <Link key={s.slug} to="/services/$slug" params={{ slug: s.slug }} className="group flex gap-3 rounded-md p-3 hover:bg-surface">
                                <s.icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                                <span><span className="block text-sm font-medium text-foreground group-hover:text-primary">{s.name}</span><span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">{s.short}</span></span>
                              </Link>
                            ))
                          : industries.map((i) => (
                              <Link key={i.slug} to="/industries/$slug" params={{ slug: i.slug }} className="group rounded-md p-3 hover:bg-surface">
                                <span className="block text-sm font-medium text-foreground group-hover:text-primary">{i.name}</span>
                                <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">{i.short}</span>
                              </Link>
                            ))}
                      </div>
                      <div className="mt-2 border-t border-border px-3 pt-3">
                        <Link to={k === "services" ? "/services" : "/industries"} className="inline-flex items-center gap-1 text-sm font-medium text-primary">View all {k} <ArrowRight className="h-3.5 w-3.5" /></Link>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
          <Link to="/how-it-works" className={linkCls} activeProps={active}>How It Works</Link>
          <Link to="/insights" className={linkCls} activeProps={active}>Insights</Link>
          <Link to="/about" className={linkCls} activeProps={active}>About</Link>
        </nav>
        <div className="hidden items-center gap-2 lg:flex">
          <Link to="/contact" className={linkCls} activeProps={active}>Contact Us</Link>
          <ThemeToggle className={onDark ? "border-ink-foreground/25 text-ink-foreground hover:bg-ink-foreground/10" : ""} />
          <Button asChild variant="default" className="h-10 px-5"><Link to="/solve">Solve a Business Problem <ArrowRight /></Link></Button>
        </div>
        <div className="flex items-center gap-2 lg:hidden"><ThemeToggle className={onDark ? "border-ink-foreground/25 text-ink-foreground hover:bg-ink-foreground/10" : ""} />
        <button type="button" className={`grid h-10 w-10 place-items-center rounded-md border lg:hidden ${onDark ? "border-ink-foreground/25 text-ink-foreground" : "border-border"}`} aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen(!open)}>
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button></div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }} className="fixed inset-x-3 bottom-3 top-[76px] overflow-y-auto rounded-2xl border border-border bg-background shadow-window sm:inset-x-4 lg:hidden" role="dialog" aria-label="Menu">
            <nav className="container-page flex flex-col py-6" aria-label="Mobile">
              {[
                ["/", "Home"], ["/solve", "AI Problem Solver"], ["/services", "Services"], ["/industries", "Industries"], ["/how-it-works", "How It Works"], ["/use-cases", "Use Cases"], ["/insights", "Insights"], ["/about", "About"], ["/faq", "FAQ"], ["/contact", "Contact"],
              ].map(([to, label]) => (
                <Link key={to} to={to as "/"} className="border-b border-border py-4 font-display text-lg text-foreground">{label}</Link>
              ))}
              <Button asChild size="lg" className="mt-8"><Link to="/solve">Solve a Business Problem <ArrowRight /></Link></Button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
