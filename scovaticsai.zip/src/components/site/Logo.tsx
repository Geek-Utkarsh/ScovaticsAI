import { Link } from "@tanstack/react-router";
import mark from "@/assets/scovatics-mark.png.asset.json";

/** Official Scovatics logo: the S symbol cropped from the brand artwork plus the wordmark. */
export function Logo({ className = "", invert = false }: { className?: string; invert?: boolean }) {
  return (
    <Link to="/" aria-label="Scovatics home" className={`inline-flex items-center gap-2.5 ${className}`}>
      <img
        src={mark.url}
        alt=""
        aria-hidden
        width={26}
        height={30}
        className={`h-[26px] w-auto transition-[filter] ${invert ? "brightness-0 invert" : "dark:brightness-0 dark:invert"}`}
      />
      <span className={`font-display text-[1.08rem] font-medium tracking-[0.22em] transition-colors ${invert ? "text-ink-foreground" : "text-primary dark:text-foreground"}`}>
        SCOVATICS
      </span>
    </Link>
  );
}
