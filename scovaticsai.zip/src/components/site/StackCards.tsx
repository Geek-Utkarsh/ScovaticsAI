import { useRef } from "react";
import { Link } from "@tanstack/react-router";
import { motion, useScroll, useTransform, useReducedMotion, type MotionValue } from "motion/react";
import { ArrowRight } from "lucide-react";
import { services } from "@/content/services";

const TONES = ["bg-background text-foreground", "bg-primary text-primary-foreground", "bg-secondary text-foreground", "bg-ink text-ink-foreground border border-ink-foreground/15", "bg-signal-soft text-foreground", "bg-background text-foreground"];

function Card({ i, progress }: { i: number; progress: MotionValue<number> }) {
  const s = services[i]!;
  const n = services.length;
  const reduce = useReducedMotion();
  const scale = useTransform(progress, [i / n, 1], [1, reduce ? 1 : 1 - (n - i) * 0.03]);
  const dark = i === 1 || i === 3;
  return (
    <div className="sticky top-24 flex h-[82vh] min-h-[520px] items-start justify-center pt-6 sm:top-28" style={{ paddingTop: i * 18 }}>
      <motion.div style={{ scale }} className={`flex min-h-[440px] w-full origin-top flex-col overflow-hidden rounded-[28px] p-7 shadow-window sm:min-h-[500px] sm:p-10 lg:p-12 ${TONES[i]}`}>
        <div className="flex items-center justify-between">
          <span className={`grid h-14 w-14 place-items-center rounded-2xl ${dark ? "bg-ink-foreground/10" : "bg-navy-soft"}`}><s.icon className={`h-6 w-6 ${dark ? "text-signal" : "text-primary"}`} strokeWidth={1.6} /></span>
          <span className="font-display text-[clamp(3rem,8vw,6rem)] font-semibold leading-none tracking-[-0.06em] opacity-15">{s.number}</span>
        </div>
        <div className="mt-8 grid flex-1 gap-8 lg:grid-cols-2 lg:gap-12">
          <div className="flex flex-col">
            <h3 className="text-[clamp(1.9rem,4vw,3.25rem)] font-medium leading-[1.02] tracking-[-0.04em]">{s.name}</h3>
            <p className={`mt-4 text-base leading-relaxed sm:text-lg ${dark ? "opacity-75" : "text-muted-foreground"}`}>{s.short}</p>
            <Link to="/services/$slug" params={{ slug: s.slug }} className={`group mt-auto inline-flex w-fit items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold max-lg:mt-6 ${dark ? "bg-signal text-ink" : "bg-primary text-primary-foreground"}`}>
              Explore service <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
          <ul className={`hidden content-start gap-2 sm:grid sm:grid-cols-2`}>
            {s.capabilities.slice(0, 6).map((c, k) => (
              <li key={c.title} className={`rounded-2xl border p-4 text-sm font-medium leading-snug ${dark ? "border-ink-foreground/15 bg-ink-foreground/[0.06]" : "border-border bg-background/70"}`}>
                <span className={`mb-2 block font-display text-xs tabular-nums ${dark ? "text-signal" : "text-primary"}`}>{String(k + 1).padStart(2, "0")}</span>{c.title}
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </div>
  );
}

/** Scroll-stacking service cards: each card pins and the earlier ones shrink behind it. */
export function StackCards() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  return <div ref={ref}>{services.map((_, i) => <Card key={i} i={i} progress={scrollYProgress} />)}</div>;
}
