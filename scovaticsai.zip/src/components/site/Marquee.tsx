import type { ReactNode } from "react";

/** Infinite horizontal ticker. Content is duplicated once for a seamless loop. */
export function Marquee({ items, className = "", speed = "marquee" }: { items: ReactNode[]; className?: string; speed?: string }) {
  const row = (hidden?: boolean) => (
    <div aria-hidden={hidden} className="flex shrink-0 items-center">
      {items.map((it, i) => <div key={i} className="flex shrink-0 items-center">{it}</div>)}
    </div>
  );
  return (
    <div className={`group overflow-hidden ${className}`}>
      <div className={`flex w-max ${speed} group-hover:[animation-play-state:paused]`}>{row()}{row(true)}</div>
    </div>
  );
}
