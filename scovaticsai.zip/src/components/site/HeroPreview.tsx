import { motion, useReducedMotion } from "motion/react";
import { useEffect, useState } from "react";
import { Check, CornerDownLeft, FileText, Sparkles } from "lucide-react";

const PROBLEM = "Our support team of six answers the same order-status and returns questions all day, so complex cases wait.";

/** Illustrative product console showing the assessment flow (example content, not a live result). */
export function HeroPreview() {
  const reduce = useReducedMotion();
  const [n, setN] = useState(reduce ? PROBLEM.length : 0);
  useEffect(() => {
    if (reduce) return;
    const t = setTimeout(() => {
      const id = setInterval(() => setN((v) => (v >= PROBLEM.length ? (clearInterval(id), v) : v + 1)), 22);
    }, 700);
    return () => clearTimeout(t);
  }, [reduce]);
  const done = n >= PROBLEM.length;
  const show = (d: number) => ({ initial: reduce ? false : { opacity: 0, y: 6 }, animate: done ? { opacity: 1, y: 0 } : reduce ? { opacity: 1, y: 0 } : { opacity: 0, y: 6 }, transition: { duration: 0.45, delay: d, ease: [0.22, 1, 0.36, 1] as const } });

  return (
    <div className="rounded-2xl border border-border bg-surface p-2 shadow-window">
      <div className="overflow-hidden rounded-xl border border-border bg-background">
        {/* window bar */}
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-1.5">{[0, 1, 2].map((i) => <span key={i} className="h-2.5 w-2.5 rounded-full bg-border-strong" />)}</div>
          <span className="rounded-md border border-border bg-muted px-3 py-1 text-[11px] text-muted-foreground">scovatics.com/solve</span>
          <span className="text-[11px] text-muted-foreground">Example</span>
        </div>

        <div className="grid text-left md:grid-cols-[180px_1fr_240px]">
          {/* steps */}
          <aside className="hidden border-r border-border bg-muted p-5 md:block">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Assessment</p>
            <ol className="mt-4 space-y-3.5 text-[13px]">
              {["Understanding problem", "Gathering context", "Preparing assessment"].map((s, i) => {
                const state = !done ? (i === 0 ? "active" : "idle") : i < 2 ? "done" : "active";
                return (
                  <li key={s} className="flex items-center gap-2.5">
                    <span className={`grid h-5 w-5 place-items-center rounded-full border text-[10px] ${state === "done" ? "border-primary bg-primary text-primary-foreground" : state === "active" ? "border-signal text-primary" : "border-border-strong text-muted-foreground"}`}>
                      {state === "done" ? <Check className="h-3 w-3" /> : i + 1}
                    </span>
                    <span className={state === "idle" ? "text-muted-foreground" : "font-medium text-foreground"}>{s}</span>
                  </li>
                );
              })}
            </ol>
            <div className="mt-8 border-t border-border pt-5">
              <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Detected</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {["Customer Support", "6 people", "Helpdesk"].map((t, i) => (
                  <motion.span {...show(0.1 + i * 0.08)} key={t} className="rounded border border-border bg-background px-2 py-0.5 text-[11px] text-foreground">{t}</motion.span>
                ))}
              </div>
            </div>
          </aside>

          {/* conversation */}
          <div className="border-border p-5 md:border-r md:p-6">
            <p className="text-[11px] font-medium text-muted-foreground">Your business problem</p>
            <div className="mt-2 min-h-[92px] rounded-lg border border-border-strong p-4 text-[14px] leading-relaxed text-foreground">
              {PROBLEM.slice(0, n)}
              {!done && <span className="ml-0.5 inline-block h-4 w-px translate-y-0.5 bg-primary pulse-dot" />}
            </div>
            <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
              <span className="inline-flex items-center gap-1"><CornerDownLeft className="h-3 w-3" /> Analyse</span>
              <span>{n}/{PROBLEM.length}</span>
            </div>
            <motion.div {...show(0.35)} className="mt-5 rounded-lg bg-navy-soft p-4">
              <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-primary"><Sparkles className="h-3 w-3" /> Follow-up</p>
              <p className="mt-2 text-[13px] text-foreground">Roughly what share of incoming queries are order-status or returns?</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {["Under 30%", "30–60%", "Over 60%"].map((o, i) => (
                  <span key={o} className={`rounded-md border px-2.5 py-1 text-[12px] ${i === 2 ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background text-foreground"}`}>{o}</span>
                ))}
              </div>
            </motion.div>
          </div>

          {/* report */}
          <div className="border-t border-border p-5 md:border-t-0 md:p-6">
            <p className="flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground"><FileText className="h-3.5 w-3.5" /> Opportunity report</p>
            <ul className="mt-4 space-y-4">
              {[["Query triage & drafted replies", 4, "High"], ["Self-service knowledge assistant", 3, "Medium"], ["Order-status automation", 2, "Depends on systems"]].map(([t, lvl, r], i) => (
                <motion.li {...show(0.55 + i * 0.12)} key={t as string}>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-[13px] font-medium text-foreground">{t}</span>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex gap-1">{[0, 1, 2, 3].map((k) => <span key={k} className={`h-1.5 w-6 rounded-full ${k < (lvl as number) ? "bg-primary" : "bg-border"}`} />)}</div>
                    <span className="text-[11px] text-muted-foreground">{r}</span>
                  </div>
                </motion.li>
              ))}
            </ul>
            <motion.div {...show(0.95)} className="mt-6 rounded-lg border border-border p-3 text-[12px] leading-relaxed text-muted-foreground">
              <span className="font-medium text-foreground">Next step:</span> map current query categories and helpdesk data access.
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
