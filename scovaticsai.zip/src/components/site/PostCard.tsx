import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { fmtDate } from "@/lib/queries";

export function PostCard({ p }: { p: { slug: string; title: string; excerpt: string; category: string; published_at: string; readingMinutes: number } }) {
  return (
    <Link to="/insights/$slug" params={{ slug: p.slug }} className="group flex h-full flex-col border-t border-border pt-6">
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span className="font-medium uppercase tracking-[0.12em] text-primary">{p.category}</span>
        <span aria-hidden>·</span><time dateTime={p.published_at}>{fmtDate(p.published_at)}</time>
        <span aria-hidden>·</span><span>{p.readingMinutes} min read</span>
      </div>
      <h3 className="mt-4 text-xl font-semibold leading-snug text-foreground transition-colors group-hover:text-primary">{p.title}</h3>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{p.excerpt}</p>
      <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-primary">Read article <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /></span>
    </Link>
  );
}
