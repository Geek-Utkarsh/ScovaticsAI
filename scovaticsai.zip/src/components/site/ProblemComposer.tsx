import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, ArrowUpRight, CornerDownLeft, Lock, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "@/components/ui/button";
import { examplePrompts } from "@/content/problems";

export function ProblemComposer({ size = "large" }: { size?: "large" | "compact" }) {
  const [text, setText] = useState("");
  const navigate = useNavigate();
  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    navigate({ to: "/solve", search: { q: text.trim() || undefined, c: undefined } });
  };
  const large = size === "large";
  const examples = large ? examplePrompts : examplePrompts.slice(0, 3);
  return (
    <form onSubmit={submit} className="w-full">
      <div className="overflow-hidden rounded-[22px] border border-border bg-background shadow-window transition-colors focus-within:border-primary">
        <div className="flex items-center justify-between gap-3 border-b border-border bg-surface px-5 py-3">
          <span className="flex min-w-0 items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-foreground">
            <span className="relative flex h-2 w-2 shrink-0"><span className="absolute inset-0 animate-ping rounded-full bg-signal opacity-60" /><span className="relative h-2 w-2 rounded-full bg-signal" /></span>
            New assessment
          </span>
          <span className="flex shrink-0 items-center gap-1.5 text-xs text-muted-foreground"><Lock className="h-3 w-3" />Private · no sign-up</span>
        </div>
        <label htmlFor={`composer-${size}`} className="sr-only">Describe your business problem</label>
        <textarea
          id={`composer-${size}`}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit(); }}
          rows={large ? 5 : 3}
          placeholder="Tell us what is taking too much time, increasing costs or slowing down your business..."
          className="block w-full resize-none bg-transparent px-6 py-5 text-lg leading-relaxed text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
        <div className="flex items-center justify-between gap-3 px-4 pb-4 sm:px-5">
          <span className="hidden items-center gap-3 text-xs text-muted-foreground sm:inline-flex">
            <span className="inline-flex items-center gap-1.5"><CornerDownLeft className="h-3.5 w-3.5" />Ctrl + Enter</span>
            <span className="tabular-nums">{text.length} chars</span>
          </span>
          <Button type="submit" size="lg" className="ml-auto rounded-full px-6">{large ? "Analyze My Business Problem" : "Analyze"} <ArrowRight /></Button>
        </div>
      </div>
      <div className="mt-6">
        <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground"><Sparkles className="h-3.5 w-3.5 text-signal" />Or start from an example</p>
        <div className={`grid gap-2.5 ${large ? "sm:grid-cols-2" : ""}`}>
          {examples.map((p, i) => {
            const on = text === p;
            return (
              <button key={p} type="button" onClick={() => setText(p)}
                className={`group flex items-start gap-3 rounded-2xl border p-4 text-left text-sm leading-snug transition-all duration-300 hover:-translate-y-0.5 ${on ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background text-foreground hover:border-primary/50"}`}>
                <span className={`font-display text-xs tabular-nums ${on ? "text-signal" : "text-muted-foreground"}`}>{String(i + 1).padStart(2, "0")}</span>
                <span className="flex-1">{p}</span>
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span key={on ? "on" : "off"} initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.6 }} transition={{ duration: 0.18 }}>
                    <ArrowUpRight className={`h-4 w-4 shrink-0 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 ${on ? "text-signal" : "text-muted-foreground"}`} />
                  </motion.span>
                </AnimatePresence>
              </button>
            );
          })}
        </div>
      </div>
    </form>
  );
}
