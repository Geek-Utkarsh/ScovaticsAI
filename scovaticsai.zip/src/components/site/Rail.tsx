import useEmblaCarousel from "embla-carousel-react";
import { Children, useCallback, useEffect, useState, type ReactNode } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";

/** Horizontal card carousel with square arrow controls and a scroll progress bar. */
export function Rail({ children, heading, slide = "basis-[84%] sm:basis-1/2 lg:basis-1/3", tone = "default", label = "Carousel" }: { children: ReactNode; heading?: ReactNode; slide?: string; tone?: "default" | "invert"; label?: string }) {
  const [ref, api] = useEmblaCarousel({ align: "start", containScroll: "trimSnaps", skipSnaps: false });
  const [progress, setProgress] = useState(0);
  const [can, setCan] = useState({ prev: false, next: true });
  const sync = useCallback(() => {
    if (!api) return;
    setProgress(Math.max(0, Math.min(1, api.scrollProgress())));
    setCan({ prev: api.canScrollPrev(), next: api.canScrollNext() });
  }, [api]);
  useEffect(() => {
    if (!api) return;
    sync();
    api.on("scroll", sync).on("reInit", sync).on("select", sync);
    return () => { api.off("scroll", sync).off("reInit", sync).off("select", sync); };
  }, [api, sync]);
  const inv = tone === "invert";
  const btn = `grid h-11 w-11 place-items-center rounded-full border transition-all duration-200 disabled:opacity-30 ${inv ? "border-primary-foreground/25 text-primary-foreground hover:bg-signal hover:text-ink hover:border-signal" : "border-border-strong text-foreground hover:bg-primary hover:text-primary-foreground hover:border-primary"}`;
  return (
    <div role="region" aria-roledescription="carousel" aria-label={label}>
      <div className="mb-8 flex flex-wrap items-end justify-between gap-6 lg:mb-10">
        <div className="min-w-0 flex-1">{heading}</div>
        <div className="flex gap-2">
          <button type="button" aria-label="Previous" className={btn} disabled={!can.prev} onClick={() => api?.scrollPrev()}><ArrowLeft className="h-4 w-4" /></button>
          <button type="button" aria-label="Next" className={btn} disabled={!can.next} onClick={() => api?.scrollNext()}><ArrowRight className="h-4 w-4" /></button>
        </div>
      </div>
      <div ref={ref} className="-mx-1 overflow-hidden px-1">
        <div className="-ml-4 flex touch-pan-y lg:-ml-6">
          {Children.map(children, (c) => <div className={`min-w-0 shrink-0 grow-0 pl-4 lg:pl-6 ${slide}`}>{c}</div>)}
        </div>
      </div>
      <div className={`mt-8 h-px w-full ${inv ? "bg-primary-foreground/15" : "bg-border"}`}>
        <div className={`h-[2px] -translate-y-[0.5px] ${inv ? "bg-signal" : "bg-primary"} transition-[width] duration-150`} style={{ width: `${Math.max(12, progress * 100)}%` }} />
      </div>
    </div>
  );
}
