import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion, useReducedMotion } from "motion/react";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { industries } from "@/content/industries";

const TONES = ["bg-background text-foreground", "bg-signal-soft text-foreground", "bg-secondary text-foreground", "bg-navy-soft text-foreground", "bg-background text-foreground"];

/** Tabbed tilted-card carousel: active card centred, neighbours rotated away. */
export function Coverflow() {
  const [i, setI] = useState(0);
  const reduce = useReducedMotion();
  const n = industries.length;
  const go = (d: number) => setI((v) => (v + d + n) % n);

  return (
    <div>
      <div className="flex items-center justify-center gap-2 sm:gap-3">
        <button aria-label="Previous" onClick={() => go(-1)} className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-ink-foreground/30 transition-colors hover:bg-ink-foreground hover:text-ink"><ArrowLeft className="h-4 w-4" /></button>
        <div role="tablist" className="no-scrollbar flex min-w-0 gap-2 overflow-x-auto">
          {industries.map((ind, k) => (
            <button key={ind.slug} role="tab" aria-selected={k === i} onClick={() => setI(k)}
              className={`shrink-0 rounded-full px-4 py-2.5 text-sm font-medium transition-all duration-300 sm:px-5 ${k === i ? "bg-ink-foreground text-ink" : "bg-ink-foreground/[0.08] text-ink-foreground hover:bg-ink-foreground/15"}`}>{ind.name}</button>
          ))}
        </div>
        <button aria-label="Next" onClick={() => go(1)} className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-ink-foreground/30 transition-colors hover:bg-ink-foreground hover:text-ink"><ArrowRight className="h-4 w-4" /></button>
      </div>

      <div className="relative mx-auto mt-12 h-[560px] max-w-6xl [perspective:1600px] sm:h-[600px]">
        {industries.map((ind, k) => {
          let off = k - i;
          if (off > n / 2) off -= n;
          if (off < -n / 2) off += n;
          const abs = Math.abs(off);
          const hidden = abs > 1;
          return (
            <motion.article key={ind.slug} aria-hidden={off !== 0}
              initial={false}
              animate={{ x: `${off * 78}%`, rotate: reduce ? 0 : off * 16, y: abs * 70, scale: off === 0 ? 1 : 0.9, opacity: hidden ? 0 : off === 0 ? 1 : 0.85 }}
              transition={{ type: "spring", stiffness: 140, damping: 22 }}
              onClick={() => off !== 0 && setI(k)}
              style={{ zIndex: 10 - abs, pointerEvents: hidden ? "none" : "auto" }}
              className={`absolute left-1/2 top-0 -ml-[min(42vw,230px)] flex h-[540px] w-[min(84vw,460px)] cursor-pointer flex-col overflow-hidden rounded-[28px] p-7 shadow-window sm:h-[580px] sm:p-8 ${TONES[k % TONES.length]}`}>
              <div className="flex items-center gap-4">
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-primary font-display text-lg font-semibold text-primary-foreground">{ind.name.slice(0, 2)}</span>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Illustrative scenario</p>
                  <h3 className="truncate text-2xl font-semibold tracking-tight">{ind.name}</h3>
                </div>
              </div>
              <p className="mt-5 leading-relaxed text-muted-foreground">{ind.short}</p>
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {ind.opportunities.slice(0, 2).map((o) => (
                  <li key={o.title} className="flex gap-2 text-sm font-medium leading-snug"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{o.title}</li>
                ))}
              </ul>
              <div className="relative mt-auto h-44 overflow-hidden rounded-[999px_999px_24px_24px] sm:h-52">
                <img src={ind.image} alt="" loading="lazy" className="h-full w-full object-cover" />
                {off === 0 && (
                  <Link to="/solve" search={{ q: ind.prompt }} className="absolute bottom-4 left-1/2 inline-flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full bg-background px-5 py-2.5 text-sm font-semibold text-foreground transition-transform hover:-translate-y-0.5">
                    Analyse a similar problem <ArrowRight className="h-4 w-4" />
                  </Link>
                )}
              </div>
            </motion.article>
          );
        })}
      </div>
    </div>
  );
}
