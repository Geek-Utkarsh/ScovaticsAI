const steps = ["Understanding Problem", "Gathering Context", "Preparing Assessment"];
export function AssessmentProgress({ current }: { current: 0 | 1 | 2 | 3 }) {
  return (
    <ol className="flex flex-wrap items-center gap-x-3 gap-y-2" aria-label="Assessment progress">
      {steps.map((s, i) => {
        const state = i < current ? "done" : i === current ? "active" : "todo";
        return (
          <li key={s} className="flex items-center gap-3" aria-current={state === "active" ? "step" : undefined}>
            <span className={`flex items-center gap-2 text-xs font-medium ${state === "todo" ? "text-muted-foreground" : "text-primary"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${state === "done" ? "bg-primary" : state === "active" ? "pulse-dot bg-signal" : "bg-border-strong"}`} />
              {s}
            </span>
            {i < steps.length - 1 && <span className={`h-px w-6 ${i < current ? "bg-primary" : "bg-border"}`} />}
          </li>
        );
      })}
    </ol>
  );
}
