import type { ReactNode } from "react";
import { PageHero, Section } from "./Section";
export function LegalPage({ eyebrow, title, intro, sections, draft = true }: { eyebrow: string; title: string; intro: string; sections: { h: string; p: ReactNode }[]; draft?: boolean }) {
  return (
    <>
      <PageHero eyebrow={eyebrow} title={title} text={intro} />
      <Section>
        <div className="mx-auto max-w-3xl">
          {draft && <p className="mb-10 rounded-md border border-dashed border-border-strong p-4 text-sm text-muted-foreground">Draft for review. This content must be reviewed by Scovatics and its legal advisers and aligned with actual company practices before publication.</p>}
          <div className="prose-article">{sections.map((s) => <div key={s.h}><h2>{s.h}</h2><p>{s.p}</p></div>)}</div>
        </div>
      </Section>
    </>
  );
}
