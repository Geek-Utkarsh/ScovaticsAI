import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "./Reveal";
import { GridLines } from "./GridLines";

export function CtaBand({ title = "Your Next Business Improvement Could Start Here.", text = "Tell us what your organization wants to improve. Discover relevant AI opportunities and explore the right next step with Scovatics.", cta = "Find My AI Opportunity", prompt }: { title?: string; text?: string; cta?: string; prompt?: string }) {
  return (
    <section className="relative overflow-hidden bg-primary text-primary-foreground" data-no-print>
      <GridLines className="text-primary-foreground/[0.06]" size={80} />
      <div className="container-page relative grid gap-10 py-24 lg:grid-cols-12 lg:items-end lg:py-36">
        <Reveal className="lg:col-span-8">
          <p className="eyebrow mb-6 flex items-center gap-3 text-signal"><span className="h-1.5 w-1.5 bg-signal" />Next step</p>
          <h2 className="display-xl text-primary-foreground">{title}</h2>
          <p className="mt-5 max-w-2xl text-lg leading-relaxed text-primary-foreground/75">{text}</p>
        </Reveal>
        <Reveal delay={0.1} className="lg:col-span-4 lg:text-right">
          <Button asChild size="lg" variant="inverse">
            <Link to="/solve" search={{ q: prompt, c: undefined }}>{cta} <ArrowRight /></Link>
          </Button>
        </Reveal>
      </div>
    </section>
  );
}
