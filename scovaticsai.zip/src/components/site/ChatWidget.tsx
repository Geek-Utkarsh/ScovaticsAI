import { useEffect, useRef, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { AnimatePresence, motion } from "motion/react";
import { ArrowRight, ArrowUp, Loader2, MessageSquare, X } from "lucide-react";
import { askAssistant } from "@/lib/chat.functions";

type Msg = { role: "user" | "assistant"; content: string; action?: "none" | "solve" | "contact"; summary?: string };
const STARTERS = ["What does Scovatics do?", "Where can AI help my operations team?", "How does the free assessment work?"];

export function ChatWidget() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const ask = useServerFn(askAssistant);
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [msgs, busy]);
  useEffect(() => { const f = () => setOpen(true); window.addEventListener("scovatics:chat", f); return () => window.removeEventListener("scovatics:chat", f); }, []);
  if (path.startsWith("/admin")) return null;

  async function send(q: string) {
    const content = q.trim();
    if (!content || busy) return;
    const next = [...msgs, { role: "user" as const, content }];
    setMsgs(next); setText(""); setErr(""); setBusy(true);
    try {
      const r = await ask({ data: { messages: next.slice(-12).map(({ role, content }) => ({ role, content })) } });
      if (r.ok) setMsgs([...next, { role: "assistant", content: r.reply, action: r.action, summary: r.problemSummary }]);
      else setErr(r.error);
    } catch { setErr("The assistant is unavailable right now."); }
    setBusy(false);
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 sm:bottom-6 sm:right-6">
      <AnimatePresence>
        {open && (
          <motion.div
            role="dialog" aria-label="Scovatics assistant"
            initial={{ opacity: 0, y: 16, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 16, scale: 0.97 }}
            transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-x-3 bottom-20 flex max-h-[min(620px,calc(100dvh-7rem))] origin-bottom-right flex-col overflow-hidden rounded-2xl border border-border bg-background shadow-2xl sm:absolute sm:inset-x-auto sm:bottom-16 sm:right-0 sm:w-[390px]"
          >
            <div className="flex items-center justify-between bg-ink px-5 py-4 text-ink-foreground">
              <div>
                <p className="flex items-center gap-2 text-sm font-semibold"><span className="h-2 w-2 animate-pulse rounded-full bg-signal" />Scovatics assistant</p>
                <p className="mt-0.5 text-xs text-ink-foreground/60">AI answers · a consultant follows up when needed</p>
              </div>
              <button onClick={() => setOpen(false)} aria-label="Close assistant" className="grid h-8 w-8 place-items-center rounded-full hover:bg-ink-foreground/10"><X className="h-4 w-4" /></button>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4" data-lenis-prevent>
              <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-surface px-4 py-3 text-sm leading-relaxed text-foreground">Hi. Tell me what your business is trying to improve, or ask how Scovatics works.</div>
              {msgs.length === 0 && (
                <div className="flex flex-wrap gap-2 pt-1">{STARTERS.map((s) => <button key={s} onClick={() => send(s)} className="rounded-full border border-border-strong px-3 py-1.5 text-xs text-foreground transition-colors hover:border-primary hover:text-primary">{s}</button>)}</div>
              )}
              {msgs.map((m, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className={m.role === "user" ? "flex justify-end" : ""}>
                  <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === "user" ? "rounded-tr-sm bg-primary text-primary-foreground" : "rounded-tl-sm bg-surface text-foreground"}`}>{m.content}</div>
                  {m.action === "solve" && (
                    <Link to="/solve" search={{ q: m.summary || msgs[i - 1]?.content, c: undefined }} onClick={() => setOpen(false)} className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground hover:opacity-90">Get my free AI assessment <ArrowRight className="h-3.5 w-3.5" /></Link>
                  )}
                  {m.action === "contact" && (
                    <Link to="/contact" onClick={() => setOpen(false)} className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-primary px-4 py-2 text-xs font-semibold text-primary hover:bg-primary hover:text-primary-foreground">Talk to a consultant <ArrowRight className="h-3.5 w-3.5" /></Link>
                  )}
                </motion.div>
              ))}
              {busy && <div className="inline-flex items-center gap-2 rounded-2xl bg-surface px-4 py-3 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" />Thinking</div>}
              {err && <p role="alert" className="rounded-lg border border-destructive/40 px-3 py-2 text-xs text-destructive">{err}</p>}
              <div ref={end} />
            </div>
            <form onSubmit={(e) => { e.preventDefault(); send(text); }} className="flex items-end gap-2 border-t border-border p-3">
              <label htmlFor="chat-input" className="sr-only">Message</label>
              <textarea id="chat-input" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(text); } }} rows={1} maxLength={1500} placeholder="Ask about your business problem…" className="max-h-28 flex-1 resize-none rounded-xl border border-border-strong bg-background px-3.5 py-2.5 text-[16px] text-foreground focus:border-primary focus:outline-none sm:text-sm" />
              <button type="submit" disabled={!text.trim() || busy} aria-label="Send" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground transition-opacity disabled:opacity-40"><ArrowUp className="h-4 w-4" /></button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button
        onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label={open ? "Close assistant" : "Open assistant"}
        whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
        className="relative grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-xl"
      >
        {!open && <span className="absolute inset-0 animate-ping rounded-full bg-primary/30 [animation-duration:2.5s]" />}
        {open ? <X className="h-5 w-5" /> : <MessageSquare className="h-5 w-5" />}
      </motion.button>
    </div>
  );
}
