import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { listContent, saveContent, deleteContent } from "@/lib/admin.functions";

export type Field = { key: string; label: string; type: "text" | "textarea" | "bool" | "list" | "date" | "number" };
type Table = "use_case_library" | "blog_posts" | "faqs" | "case_studies";
type Row = Record<string, unknown>;
const inp = "mt-1.5 block w-full rounded-md border border-border-strong bg-background px-3 py-2 text-sm";

export function ContentEditor({ table, fields, titleKey, activeKey }: { table: Table; fields: Field[]; titleKey: string; activeKey: string }) {
  const list = useServerFn(listContent); const save = useServerFn(saveContent); const del = useServerFn(deleteContent); const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["admin-content", table], queryFn: async () => JSON.parse(await list({ data: { table } })) as Row[] });
  const [edit, setEdit] = useState<Row | null>(null);
  const [busy, setBusy] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin-content", table] });
  const blank = () => Object.fromEntries(fields.map((f) => [f.key, f.type === "bool" ? true : f.type === "list" ? [] : f.type === "number" ? 0 : ""]));

  const onSave = async () => {
    if (!edit) return;
    setBusy(true);
    const values: Row = {};
    fields.forEach((f) => { values[f.key] = edit[f.key]; });
    try { await save({ data: { table, id: (edit["id"] as string) ?? null, values } }); toast.success("Saved"); setEdit(null); refresh(); }
    catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };
  const onDelete = async (id: string) => { if (!confirm("Delete this item?")) return; try { await del({ data: { table, id } }); refresh(); toast.success("Deleted"); } catch (e) { toast.error((e as Error).message); } };
  const toggle = async (r: Row) => { const values: Row = {}; fields.forEach((f) => { values[f.key] = r[f.key]; }); values[activeKey] = !r[activeKey]; await save({ data: { table, id: r["id"] as string, values } }); refresh(); };

  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-primary" />;
  return (
    <div>
      <Button onClick={() => setEdit(blank())}><Plus /> Add new</Button>
      {edit && (
        <div className="mt-6 rounded-lg border border-primary/40 bg-background p-6">
          <div className="grid gap-4 md:grid-cols-2">
            {fields.map((f) => (
              <label key={f.key} className={`block text-sm ${f.type === "textarea" ? "md:col-span-2" : ""}`}>
                {f.label}
                {f.type === "textarea" ? <textarea rows={f.key === "body" ? 14 : 3} className={inp} value={String(edit[f.key] ?? "")} onChange={(e) => setEdit({ ...edit, [f.key]: e.target.value })} />
                  : f.type === "bool" ? <input type="checkbox" className="ml-2" checked={!!edit[f.key]} onChange={(e) => setEdit({ ...edit, [f.key]: e.target.checked })} />
                  : f.type === "list" ? <input className={inp} value={((edit[f.key] as string[]) ?? []).join(", ")} onChange={(e) => setEdit({ ...edit, [f.key]: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} placeholder="Comma separated" />
                  : <input type={f.type === "date" ? "date" : f.type === "number" ? "number" : "text"} className={inp} value={String(edit[f.key] ?? "")} onChange={(e) => setEdit({ ...edit, [f.key]: f.type === "number" ? Number(e.target.value) : e.target.value })} />}
              </label>
            ))}
          </div>
          <div className="mt-5 flex gap-2"><Button onClick={onSave} disabled={busy}>{busy && <Loader2 className="animate-spin" />}Save</Button><Button variant="outline" onClick={() => setEdit(null)}>Cancel</Button></div>
        </div>
      )}
      <ul className="mt-6 divide-y divide-border rounded-lg border border-border bg-background">
        {(data ?? []).length === 0 && <li className="p-6 text-sm text-muted-foreground">No items yet.</li>}
        {(data ?? []).map((r) => (
          <li key={r["id"] as string} className="flex items-center justify-between gap-4 p-4">
            <span className="min-w-0 text-sm"><span className="font-medium">{String(r[titleKey])}</span>{!r[activeKey] && <span className="ml-2 text-xs text-muted-foreground">(hidden)</span>}</span>
            <span className="flex shrink-0 gap-2">
              <Button size="sm" variant="ghost" onClick={() => toggle(r)}>{r[activeKey] ? "Deactivate" : "Activate"}</Button>
              <Button size="sm" variant="outline" onClick={() => setEdit(r)}>Edit</Button>
              <Button size="sm" variant="ghost" aria-label="Delete" onClick={() => onDelete(r["id"] as string)}><Trash2 /></Button>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
