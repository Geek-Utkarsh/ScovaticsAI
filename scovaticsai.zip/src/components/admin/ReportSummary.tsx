import type { Report } from "@/lib/assessment-schema";
export function ReportSummary({ r }: { r: Report }) {
  return (
    <div className="space-y-5 text-sm">
      <div><p className="font-semibold">{r.title}</p><p className="mt-1 text-muted-foreground">{r.problemOverview}</p></div>
      <div><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Use cases</p><ul className="mt-2 space-y-2">{r.useCases.map((u) => <li key={u.title}><span className="font-medium">{u.title}</span> — <span className="text-muted-foreground">{u.whatItDoes}</span></li>)}</ul></div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Facts provided</p><ul className="mt-2 list-disc pl-4">{r.providedFacts.map((x) => <li key={x}>{x}</li>)}</ul></div>
        <div><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Missing information</p><ul className="mt-2 list-disc pl-4">{r.missingInformation.map((x) => <li key={x}>{x}</li>)}</ul></div>
      </div>
      <div><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Next step</p><p className="mt-1">{r.nextStep.title}: {r.nextStep.description}</p></div>
    </div>
  );
}
