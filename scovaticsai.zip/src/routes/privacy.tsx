import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";
import { seo } from "@/lib/seo";
export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: seo("Privacy Policy", "How Scovatics collects, uses and protects information submitted through this website.") }),
  component: () => <LegalPage eyebrow="Legal" title="Privacy Policy" intro="How information submitted through this website is handled." sections={[
    { h: "Information we collect", p: "Problem descriptions and answers you enter in the AI Problem Solver, the report generated from them, and contact details you submit through enquiry forms, together with a record of your consent." },
    { h: "How we use it", p: "To generate your assessment, to respond to your enquiry, and to improve our services. Assessment content is processed by an AI service to produce your report." },
    { h: "Access", p: "Reports are accessible through a private link. Enquiries and linked assessments are visible only to authorised Scovatics staff." },
    { h: "Retention and your rights", p: "Retention periods and data subject rights will be set out here once confirmed. You may request access to or deletion of your data by contacting Scovatics." },
    { h: "Contact", p: "Contact details for privacy matters will be supplied." },
  ]} />,
});
