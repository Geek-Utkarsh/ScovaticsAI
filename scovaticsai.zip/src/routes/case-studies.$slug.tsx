import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Section } from "@/components/site/Section";
import { CtaBand } from "@/components/site/CtaBand";
import { caseStudyQuery } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/case-studies/$slug")({
  loader: async ({ context, params }) => { const c = await context.queryClient.ensureQueryData(caseStudyQuery(params.slug)); if (!c) throw notFound(); return c; },
  head: ({ loaderData }) => ({ meta: loaderData ? seo(loaderData.title, loaderData.business_problem, "article") : [{ title: "Case study not found | Scovatics" }, { name: "robots", content: "noindex" }] }),
  component: () => {
    const { slug } = Route.useParams();
    const { data: c } = useSuspenseQuery(caseStudyQuery(slug));
    if (!c) return null;
    const parts = [["Client context", c.client_context], ["Business problem", c.business_problem], ["Approach", c.approach], ["Implementation", c.implementation], ["Verified outcomes", c.outcomes], ["Lessons learned", c.lessons]];
    return (
      <>
        <section className="border-b border-border pb-14 pt-32 lg:pt-44"><div className="container-page max-w-4xl">
          <p className="eyebrow mb-5"><Link to="/case-studies" className="hover:underline">Case studies</Link> / {c.industry}</p>
          {c.illustrative && <p className="mb-5 inline-block rounded-md border border-dashed border-border-strong px-3 py-1.5 text-sm text-muted-foreground">Illustrative example — not a real client engagement</p>}
          <h1 className="display-lg text-foreground">{c.title}</h1>
        </div></section>
        <Section><div className="mx-auto max-w-4xl divide-y divide-border border-y border-border">{parts.map(([k, v], i) => <div key={k} className="grid gap-4 py-8 md:grid-cols-3"><h2 className="text-lg font-semibold text-foreground"><span className="mr-3 font-display text-sm text-signal">0{i + 1}</span>{k}</h2><p className="leading-relaxed text-muted-foreground md:col-span-2">{v}</p></div>)}</div></Section>
        <CtaBand />
      </>
    );
  },
});
