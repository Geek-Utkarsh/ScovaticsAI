import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";
import { CtaBand } from "@/components/site/CtaBand";
import { seo } from "@/lib/seo";
export const Route = createFileRoute("/responsible-ai")({
  head: () => ({ meta: seo("Responsible AI", "The principles Scovatics applies to every AI engagement: privacy, human oversight, security, reliability, transparency and fairness.") }),
  component: () => (<><LegalPage draft={false} eyebrow="Responsible AI" title="How We Approach Responsible AI." intro="Principles applied to every engagement and to this website's own AI assessment." sections={[
    { h: "Problem first", p: "We recommend AI only where it addresses a real business need and where a simpler approach would not serve better." },
    { h: "Human oversight", p: "People remain accountable for consequential decisions. We design review and approval steps into workflows." },
    { h: "Privacy and security", p: "We establish what data a system uses, where it is processed and who can access outputs, and apply access controls accordingly." },
    { h: "Reliability", p: "Solutions are evaluated against representative real cases before release and monitored afterwards." },
    { h: "Transparency", p: "Assumptions and limitations are stated plainly. Our own assessment separates the facts you provide from the assumptions it makes, and never presents estimated returns as fact." },
    { h: "Fairness", p: "High-risk uses such as hiring are approached with particular care, including review for bias and legal input." },
  ]} /><CtaBand /></>),
});
