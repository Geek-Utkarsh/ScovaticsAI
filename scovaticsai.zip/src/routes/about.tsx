import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageHero, Section, SectionHeading } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { CtaBand } from "@/components/site/CtaBand";
import { methodology } from "@/content/problems";
import workshop from "@/assets/about-workshop.jpg";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/about")({
  head: () => ({ meta: seo("About Scovatics", "Scovatics is an enterprise AI consulting firm that starts with business problems, not technology, and implements AI with appropriate controls.") }),
  component: () => (
    <>
      <PageHero eyebrow="About Scovatics" title="We Start With Understanding Your Business." text="Scovatics is an enterprise AI consulting company. We help organisations identify where AI can genuinely improve how they operate, and we help them implement it responsibly." />
      <div className="container-page"><img src={workshop} alt="Consultant mapping a business process with a leadership team" width={1440} height={896} className="aspect-[21/9] w-full rounded-lg border border-border object-cover" /></div>
      <Section>
        <div className="grid gap-12 lg:grid-cols-3">
          {[["Mission", "To help organisations turn real operational problems into practical, well-governed AI improvements."], ["Vision", "A world where businesses adopt AI with clarity about its value, its limits and the people it affects."], ["Philosophy", "Problem first, technology second. Improve the workflow before automating it. Keep people accountable."]].map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.06} className="border-t-2 border-primary pt-6"><h2 className="text-2xl font-semibold text-foreground">{t}</h2><p className="mt-3 leading-relaxed text-muted-foreground">{d}</p></Reveal>
          ))}
        </div>
      </Section>
      <Section tone="surface">
        <SectionHeading eyebrow="Methodology" title="Discover → Assess → Prioritize → Design → Implement → Optimize." />
        <ol className="grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">{methodology.map((m, i) => <li key={m.name} className="bg-background p-7"><span className="font-display text-sm text-signal">0{i + 1}</span><h3 className="mt-4 text-lg font-semibold">{m.name}</h3><p className="mt-2 text-sm text-muted-foreground">{m.text}</p></li>)}</ol>
      </Section>
      <Section>
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5"><SectionHeading eyebrow="Leadership & team" title="The people behind Scovatics." /></div>
          <div className="lg:col-span-7"><div className="rounded-lg border border-dashed border-border-strong p-10 text-muted-foreground">Team and leadership profiles will be published here once official information is supplied.</div><Button asChild className="mt-8"><Link to="/contact">Contact Scovatics</Link></Button></div>
        </div>
      </Section>
      <CtaBand />
    </>
  ),
});
