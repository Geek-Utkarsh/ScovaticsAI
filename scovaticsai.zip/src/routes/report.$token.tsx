import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowRight, Copy, Printer, Check, Info } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/site/Reveal";
import { EnquiryForm } from "@/components/site/EnquiryForm";
import { reportQuery, fmtDate } from "@/lib/queries";
import { consultingOptions } from "@/content/services";
import { services } from "@/content/services";
import type { Report } from "@/lib/assessment-schema";

export const Route = createFileRoute("/report/$token")({
  loader: async ({ context, params }) => {
    const d = await context.queryClient.ensureQueryData(reportQuery(params.token));
    if (!d) throw notFound();
    return d;
  },
  head: () => ({ meta: [{ title: "Your AI Opportunity Report | Scovatics" }, { name: "robots", content: "noindex, nofollow" }, { name: "description", content: "A private initial AI opportunity assessment prepared by Scovatics." }, { property: "og:title", content: "AI Opportunity Report | Scovatics" }, { property: "og:description", content: "A private initial AI opportunity assessment." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  notFoundComponent: () => (
    <div className="container-page py-44 text-center">
      <h1 className="display-lg">Report not found</h1>
      <p className="lead mt-4">This report link is invalid or the report is not ready yet.</p>
      <Button asChild className="mt-8"><Link to="/solve">Start a new assessment</Link></Button>
    </div>
  ),
  component: ReportPage,
});

function toText(r: Report, problem: string) {
  const l = (xs: string[]) => xs.map((x) => `- ${x}`).join("\n");
  return `SCOVATICS — AI OPPORTUNITY REPORT\n${r.title}\n\nPROBLEM\n${problem}\n\n01 PROBLEM OVERVIEW\n${r.problemOverview}\n\nFacts provided:\n${l(r.providedFacts)}\nAssumptions:\n${l(r.assumptions)}\n\n02 BUSINESS CHALLENGES\n${r.challenges.map((c) => `- ${c.title}: ${c.detail}`).join("\n")}\n\n03 RECOMMENDED AI USE CASES\n${r.useCases.map((u, i) => `${i + 1}. ${u.title}\n   What it does: ${u.whatItDoes}\n   Relevance: ${u.relevance}\n   Benefit: ${u.benefit}\n   Considerations: ${u.considerations}`).join("\n")}\n\n04 POTENTIAL BUSINESS IMPACT\n${r.impact.map((i) => `- ${i.area}: ${i.description}`).join("\n")}\n\n05 FEASIBILITY\nDependencies:\n${l(r.feasibility.dependencies)}\nData:\n${l(r.feasibility.dataRequirements)}\nTools:\n${l(r.feasibility.existingTools)}\nHuman oversight:\n${l(r.feasibility.humanOversight)}\nRisks:\n${l(r.risks)}\nMissing information:\n${l(r.missingInformation)}\n\n06 RECOMMENDED NEXT STEP\n${r.nextStep.title}: ${r.nextStep.description}\n\nThis is an indicative AI-generated assessment and requires professional validation.`;
}

function Block({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <Reveal as="section" className="grid gap-6 border-t border-border py-12 lg:grid-cols-12 print:break-inside-avoid">
      <div className="lg:col-span-4"><p className="font-display text-sm text-signal">Section {n}</p><h2 className="mt-2 text-2xl font-semibold text-foreground">{title}</h2></div>
      <div className="lg:col-span-8">{children}</div>
    </Reveal>
  );
}
const List = ({ items }: { items: string[] }) => items.length ? <ul className="space-y-2">{items.map((x) => <li key={x} className="flex gap-3 text-[0.95rem] leading-relaxed text-foreground"><span className="mt-2.5 h-1 w-1 shrink-0 rounded-full bg-primary" />{x}</li>)}</ul> : <p className="text-sm text-muted-foreground">None identified.</p>;

function ReportPage() {
  const { token } = Route.useParams();
  const { data } = useSuspenseQuery(reportQuery(token));
  const [choice, setChoice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  if (!data) return null;
  const r = data.report;
  const options = r.consultingOptions.length ? r.consultingOptions : [{ key: "assessment" as const, reason: "Validate this opportunity against your systems and priorities." }];
  const recServices = services.filter((s) => r.serviceSlugs.includes(s.slug));

  const copy = async () => {
    try { await navigator.clipboard.writeText(toText(r, data.problem)); setCopied(true); toast.success("Report copied to clipboard"); setTimeout(() => setCopied(false), 2000); }
    catch { toast.error("Could not copy. Please select the text manually."); }
  };

  return (
    <div className="bg-background pb-24 pt-28 lg:pt-36">
      <div className="container-page">
        <header className="border-b-2 border-primary pb-10">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div>
              <p className="font-display text-sm font-semibold tracking-[0.2em] text-primary">SCOVATICS</p>
              <p className="eyebrow mt-1 text-muted-foreground">Your AI Opportunity Report</p>
            </div>
            <div className="flex gap-2" data-no-print>
              <Button variant="outline" size="sm" onClick={copy}>{copied ? <Check /> : <Copy />} Copy</Button>
              <Button variant="outline" size="sm" onClick={() => window.print()}><Printer /> Print / Save PDF</Button>
            </div>
          </div>
          <h1 className="display-lg mt-10 max-w-4xl text-foreground">{r.title}</h1>
          <div className="mt-6 flex flex-wrap gap-x-8 gap-y-2 text-sm text-muted-foreground">
            <span>Department: <span className="text-foreground">{r.department}</span></span>
            {data.category && <span>Area: <span className="text-foreground">{data.category}</span></span>}
            <span>Prepared: <span className="text-foreground">{fmtDate(data.createdAt)}</span></span>
          </div>
          <p className="mt-8 flex max-w-3xl gap-2.5 rounded-md bg-surface p-4 text-sm leading-relaxed text-muted-foreground"><Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> This is an initial AI-generated assessment based only on what you described. It is not an implementation plan and does not include cost or return estimates, which require validation with your team.</p>
        </header>

        <Block n="01" title="Problem Overview">
          <p className="text-lg leading-relaxed text-foreground">{r.problemOverview}</p>
          <div className="mt-8 grid gap-6 sm:grid-cols-2">
            <div className="rounded-md border border-border p-5"><p className="mb-3 text-xs font-semibold uppercase tracking-[0.12em] text-primary">What you told us</p><List items={r.providedFacts} /></div>
            <div className="rounded-md border border-dashed border-border-strong p-5"><p className="mb-3 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">Our assumptions</p><List items={r.assumptions} /></div>
          </div>
        </Block>

        <Block n="02" title="Business Challenges">
          <dl className="divide-y divide-border border-y border-border">{r.challenges.map((c) => <div key={c.title} className="grid gap-2 py-4 sm:grid-cols-3"><dt className="font-medium text-foreground">{c.title}</dt><dd className="text-[0.95rem] leading-relaxed text-muted-foreground sm:col-span-2">{c.detail}</dd></div>)}</dl>
        </Block>

        <Block n="03" title="Recommended AI Use Cases">
          <div className="space-y-6">
            {r.useCases.map((u, i) => (
              <article key={u.title} className="rounded-lg border border-border p-6 print:break-inside-avoid">
                <div className="flex items-baseline gap-4"><span className="font-display text-sm text-signal">0{i + 1}</span><h3 className="text-xl font-semibold text-foreground">{u.title}</h3></div>
                <dl className="mt-5 grid gap-5 sm:grid-cols-2">
                  {[["What it does", u.whatItDoes], ["How it relates to your problem", u.relevance], ["Potential business benefit", u.benefit], ["Considerations", u.considerations]].map(([k, v]) => (
                    <div key={k}><dt className="text-xs font-semibold uppercase tracking-[0.1em] text-muted-foreground">{k}</dt><dd className="mt-1.5 text-[0.95rem] leading-relaxed text-foreground">{v}</dd></div>
                  ))}
                </dl>
              </article>
            ))}
          </div>
        </Block>

        <Block n="04" title="Potential Business Impact">
          <div className="grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2">{r.impact.map((i) => <div key={i.area} className="bg-background p-5"><p className="font-medium text-foreground">{i.area}</p><p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{i.description}</p></div>)}</div>
          <p className="mt-4 text-xs text-muted-foreground">Impact is described qualitatively. Quantified estimates require a baseline measured with your team.</p>
        </Block>

        <Block n="05" title="Feasibility Considerations">
          <div className="grid gap-8 sm:grid-cols-2">
            {[["Dependencies", r.feasibility.dependencies], ["Data requirements", r.feasibility.dataRequirements], ["Existing tools", r.feasibility.existingTools], ["Human oversight", r.feasibility.humanOversight], ["Risks", r.risks], ["Information still needed", r.missingInformation]].map(([k, v]) => (
              <div key={k as string}><p className="mb-3 text-sm font-semibold text-foreground">{k as string}</p><List items={v as string[]} /></div>
            ))}
          </div>
        </Block>

        <Block n="06" title="Recommended Next Step">
          <div className="rounded-lg bg-navy-soft p-6"><p className="text-lg font-semibold text-primary">{r.nextStep.title}</p><p className="mt-2 leading-relaxed text-foreground">{r.nextStep.description}</p></div>
          {recServices.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-2" data-no-print>{recServices.map((s) => <Link key={s.slug} to="/services/$slug" params={{ slug: s.slug }} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:border-primary hover:text-primary"><s.icon className="h-4 w-4" /> {s.name}</Link>)}</div>
          )}
        </Block>

        <Block n="07" title="Consulting Options">
          <div className="grid gap-4" data-no-print>
            {options.map((o, i) => {
              const c = consultingOptions[o.key];
              const sel = choice === c.name;
              return (
                <button key={o.key} type="button" onClick={() => { setChoice(c.name); setTimeout(() => document.getElementById("enquiry")?.scrollIntoView({ behavior: "smooth" }), 50); }} aria-pressed={sel} className={`rounded-lg border p-6 text-left transition-colors ${sel ? "border-primary bg-navy-soft" : "border-border hover:border-primary/50"}`}>
                  <div className="flex items-center justify-between gap-4"><p className="text-lg font-semibold text-foreground">{c.name}</p>{i === 0 && <span className="rounded-[4px] bg-signal-soft px-2 py-0.5 text-xs font-medium text-primary">Most relevant</span>}</div>
                  <p className="mt-2 text-sm text-muted-foreground">{c.text}</p>
                  <p className="mt-3 text-sm text-foreground"><span className="font-medium">Why for you: </span>{o.reason}</p>
                </button>
              );
            })}
          </div>
          <div className="mt-8 flex flex-wrap gap-3" data-no-print>
            <Button size="lg" onClick={() => { setChoice(choice ?? consultingOptions[options[0]!.key].name); setTimeout(() => document.getElementById("enquiry")?.scrollIntoView({ behavior: "smooth" }), 50); }}>Discuss This Opportunity With Scovatics <ArrowRight /></Button>
            <Button asChild size="lg" variant="outline"><Link to="/services">Explore Our Services</Link></Button>
          </div>
        </Block>

        {choice && (
          <section id="enquiry" className="scroll-mt-28 border-t border-border py-12" data-no-print>
            <div className="grid gap-8 lg:grid-cols-12">
              <div className="lg:col-span-4"><h2 className="text-2xl font-semibold text-foreground">Discuss this opportunity</h2><p className="mt-3 text-sm leading-relaxed text-muted-foreground">Your report will be attached to your enquiry so our team can review it before we speak.</p></div>
              <div className="lg:col-span-8"><EnquiryForm key={choice} defaultInterest={choice} assessmentToken={token} source="report" /></div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
