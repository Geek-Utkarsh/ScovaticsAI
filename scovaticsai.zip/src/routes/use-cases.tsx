import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { PageHero, Section } from "@/components/site/Section";
import { CtaBand } from "@/components/site/CtaBand";
import { useCasesQuery } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/use-cases")({
  head: () => ({ meta: seo("AI Use-Case Library", "Search and filter practical AI use cases by industry, business function, problem category and AI application.") }),
  loader: ({ context }) => context.queryClient.ensureQueryData(useCasesQuery),
  component: UseCases,
});

const sel = "rounded-md border border-border-strong bg-background px-3 py-2.5 text-sm focus:border-primary focus:outline-none";

function UseCases() {
  const { data } = useSuspenseQuery(useCasesQuery);
  const [q, setQ] = useState(""); const [ind, setInd] = useState(""); const [fn, setFn] = useState(""); const [cat, setCat] = useState(""); const [app, setApp] = useState("");
  const uniq = (xs: string[]) => [...new Set(xs)].sort();
  const opts = useMemo(() => ({ ind: uniq(data.flatMap((d) => d.industries)), fn: uniq(data.flatMap((d) => d.functions)), cat: uniq(data.map((d) => d.problem_category)), app: uniq(data.map((d) => d.ai_application)) }), [data]);
  const list = data.filter((d) => (!q || `${d.title} ${d.summary}`.toLowerCase().includes(q.toLowerCase())) && (!ind || d.industries.includes(ind)) && (!fn || d.functions.includes(fn)) && (!cat || d.problem_category === cat) && (!app || d.ai_application === app));
  return (
    <>
      <PageHero eyebrow="Use cases" title="A Curated Library of Practical AI Use Cases." text="These are the reviewed use cases our assessment draws on. Each lists its dependencies and limitations." />
      <Section>
        <div className="sticky top-16 z-10 -mx-1 mb-10 grid gap-3 bg-background px-1 py-4 lg:top-[72px] lg:grid-cols-[1.5fr_repeat(4,1fr)]">
          <label className="relative"><span className="sr-only">Search</span><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search use cases" className={`${sel} w-full pl-9`} /></label>
          {([["Industry", ind, setInd, opts.ind], ["Function", fn, setFn, opts.fn], ["Problem", cat, setCat, opts.cat], ["AI application", app, setApp, opts.app]] as const).map(([l, v, set, o]) => (
            <select key={l} aria-label={l} value={v} onChange={(e) => set(e.target.value)} className={sel}><option value="">All {l.toLowerCase()}s</option>{o.map((x) => <option key={x}>{x}</option>)}</select>
          ))}
        </div>
        <p className="mb-6 text-sm text-muted-foreground">{list.length} use case{list.length === 1 ? "" : "s"}</p>
        {list.length === 0 ? <p className="rounded-lg border border-dashed border-border p-10 text-center text-muted-foreground">No use cases match these filters.</p> : (
          <div className="grid gap-px overflow-hidden rounded-lg border border-border bg-border md:grid-cols-2">
            {list.map((u) => (
              <article key={u.id} className="bg-background p-7">
                <div className="flex flex-wrap gap-2 text-xs"><span className="rounded-[4px] bg-navy-soft px-2 py-0.5 font-medium text-primary">{u.problem_category}</span><span className="rounded-[4px] border border-border px-2 py-0.5 text-muted-foreground">{u.ai_application}</span></div>
                <h2 className="mt-4 text-lg font-semibold text-foreground">{u.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{u.summary}</p>
                <dl className="mt-5 grid gap-3 border-t border-border pt-4 text-sm">
                  {u.dependencies && <div><dt className="font-medium text-foreground">Dependencies</dt><dd className="text-muted-foreground">{u.dependencies}</dd></div>}
                  {u.limitations && <div><dt className="font-medium text-foreground">Limitations</dt><dd className="text-muted-foreground">{u.limitations}</dd></div>}
                  <div className="text-xs text-muted-foreground">{u.industries.join(" · ")}</div>
                </dl>
              </article>
            ))}
          </div>
        )}
      </Section>
      <CtaBand />
    </>
  );
}
