import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowRight, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Section, SectionHeading } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { CtaBand } from "@/components/site/CtaBand";
import { getIndustry } from "@/content/industries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/industries/$slug")({
  loader: ({ params }) => { if (!getIndustry(params.slug)) throw notFound(); return null; },
  head: ({ params }) => { const i = getIndustry(params.slug); return { meta: i ? seo(`AI for ${i.name}`, i.intro) : [{ title: "Industry not found | Scovatics" }, { name: "robots", content: "noindex" }] }; },
  component: IndustryPage,
});

function IndustryPage() {
  const { slug } = Route.useParams();
  const ind = getIndustry(slug)!;
  return (
    <>
      <section className="pb-12 pt-32 lg:pt-44">
        <div className="container-page">
          <Reveal className="max-w-4xl">
            <p className="eyebrow mb-5"><Link to="/industries" className="hover:underline">Industries</Link> <span className="text-muted-foreground">/</span> {ind.name}</p>
            <h1 className="display-xl text-foreground">AI for {ind.name}.</h1>
            <p className="lead mt-6 max-w-2xl">{ind.intro}</p>
            <div className="mt-9"><Button asChild size="lg"><Link to="/solve" search={{ q: ind.prompt, c: undefined }}>Analyze a Similar Problem <ArrowRight /></Link></Button></div>
          </Reveal>
        </div>
        <div className="container-page mt-14"><img src={ind.image} alt={`${ind.name} operations`} width={1280} height={896} className="aspect-[21/9] w-full rounded-lg border border-border object-cover" /></div>
      </section>
      <Section>
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4"><SectionHeading eyebrow="Typical challenges" title="What slows teams down." /></div>
          <ul className="grid gap-px self-start overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:col-span-8">{ind.challenges.map((c) => <li key={c} className="bg-background p-6 text-foreground">{c}</li>)}</ul>
        </div>
      </Section>
      <Section tone="surface">
        <SectionHeading eyebrow="AI opportunities" title="Where AI can help." />
        <div className="grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">{ind.opportunities.map((o, i) => <Reveal key={o.title} delay={i * 0.05} className="border-t-2 border-primary pt-5"><h3 className="text-lg font-semibold text-foreground">{o.title}</h3><p className="mt-2 text-sm leading-relaxed text-muted-foreground">{o.text}</p></Reveal>)}</div>
      </Section>
      <Section>
        <div className="grid gap-12 lg:grid-cols-2">
          <div><SectionHeading eyebrow="Example use cases" title="Illustrative applications." text="Examples of the kind of work involved. These are not descriptions of client projects." /><ul className="border-t border-border">{ind.examples.map((e) => <li key={e} className="border-b border-border py-4 text-foreground">{e}</li>)}</ul></div>
          <div className="rounded-lg border border-border bg-surface p-8 self-start"><ShieldCheck className="h-6 w-6 text-primary" strokeWidth={1.5} /><h2 className="mt-5 text-2xl font-semibold text-foreground">Responsible AI considerations</h2><ul className="mt-5 space-y-3">{ind.responsible.map((r) => <li key={r} className="flex gap-3 text-foreground"><span className="mt-2.5 h-1 w-1 shrink-0 rounded-full bg-primary" />{r}</li>)}</ul><Link to="/responsible-ai" className="mt-6 inline-block text-sm font-medium text-primary hover:underline">Our principles</Link></div>
        </div>
      </Section>
      <CtaBand title={`Facing a Similar Challenge in ${ind.name}?`} text="Describe it in your own words and receive an initial AI opportunity assessment." cta="Analyze a Similar Problem" prompt={ind.prompt} />
    </>
  );
}
