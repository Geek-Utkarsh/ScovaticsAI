import { createFileRoute } from "@tanstack/react-router";
import { services } from "@/content/services";
import { industries } from "@/content/industries";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const origin = new URL(request.url).origin;
        const { createClient } = await import("@supabase/supabase-js");
        const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
        const db = createClient(process.env["SUPABASE_URL"]!, key, { auth: { persistSession: false }, global: { fetch: (i, init) => { const h = new Headers(init?.headers); if (key.startsWith("sb_")) h.delete("Authorization"); h.set("apikey", key); return fetch(i, { ...init, headers: h }); } } });
        const { data: posts } = await db.from("blog_posts").select("slug").eq("published", true);
        const { data: cases } = await db.from("case_studies").select("slug").eq("published", true);
        const paths = ["/", "/solve", "/how-it-works", "/services", "/industries", "/use-cases", "/case-studies", "/insights", "/about", "/contact", "/faq", "/responsible-ai", "/privacy", "/terms",
          ...services.map((s) => `/services/${s.slug}`), ...industries.map((i) => `/industries/${i.slug}`),
          ...(posts ?? []).map((p) => `/insights/${p.slug}`), ...(cases ?? []).map((c) => `/case-studies/${c.slug}`)];
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map((p) => `<url><loc>${origin}${p}</loc></url>`).join("")}</urlset>`;
        return new Response(xml, { headers: { "Content-Type": "application/xml" } });
      },
    },
  },
});
