import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { ArrowRight, ArrowUpRight, Lock, UserCheck, ShieldCheck, Gauge, Eye, Scale } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Section, SectionHeading } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { ProblemComposer } from "@/components/site/ProblemComposer";
import { Rail } from "@/components/site/Rail";
import { Marquee } from "@/components/site/Marquee";
import { LineReveal } from "@/components/site/SplitReveal";
import { HeroSpotlight } from "@/components/site/HeroSpotlight";
import { Coverflow } from "@/components/site/Coverflow";
import { StackCards } from "@/components/site/StackCards";
import { CountUp } from "@/components/site/CountUp";
import { StageList } from "@/components/site/StageList";
import heroImg from "@/assets/hero-architecture.jpg";
import bannerImg from "@/assets/banner-facade.jpg";
import { CtaBand } from "@/components/site/CtaBand";
import { problemAreas, methodology } from "@/content/problems";
import { services } from "@/content/services";
import { industries } from "@/content/industries";
import { postsQuery, fmtDate } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/")({
  head: () => ({ meta: seo("Scovatics — Enterprise AI Consulting & Business Problem Solving", "Describe a business challenge and receive an initial AI opportunity assessment. Scovatics helps organisations identify, prioritise and implement practical AI.") }),
  loader: ({ context }) => context.queryClient.ensureQueryData(postsQuery),
  component: Home,
});

const WIDE = [0, 5, 6, 11];
const Arrow = ({ className = "" }: { className?: string }) => (
  <svg aria-hidden viewBox="0 0 40 48" className={`h-[0.72em] w-auto shrink-0 fill-signal ${className}`}><path d="M0 0 L40 20 L40 28 L0 48 L0 34 L24 24 L0 14 Z" /></svg>
);

function Home() {
  const reduce = useReducedMotion();
  const { data: posts } = useSuspenseQuery(postsQuery);
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", reduce ? "0%" : "18%"]);
  const stage = (d: number) => ({ initial: reduce ? false : { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.7, delay: d, ease: [0.22, 1, 0.36, 1] as const } });
  const heroLine = "text-[clamp(3.4rem,10.5vw,7.75rem)]";

  return (
    <>
      {/* HERO */}
      <section ref={heroRef} className="relative overflow-hidden bg-ink text-ink-foreground">
        <motion.img style={{ y: imgY }} src={heroImg} alt="" aria-hidden width={1920} height={1088} className="absolute inset-0 h-[115%] w-full object-cover opacity-25" />
        <div className="absolute inset-0 bg-ink/55" />
        <div className="container-page relative pb-14 pt-28 sm:pt-36 lg:pb-20 lg:pt-44">
          <div className="grid gap-12 lg:grid-cols-12 lg:items-center lg:gap-10">
            <h1 aria-label="Problems first. Then AI." className="font-display font-semibold uppercase leading-[0.88] tracking-[-0.05em] lg:col-span-8">
              <LineReveal delay={0.05} className={heroLine}>Problems</LineReveal>
              <LineReveal delay={0.15} className={`${heroLine} sm:pl-[14%]`}>first<span className="text-signal">.</span></LineReveal>
              <LineReveal delay={0.25} className={`${heroLine} sm:pl-[22%]`}><span className="flex items-center gap-[0.16em]">Then <Arrow /> AI</span></LineReveal>
            </h1>
            <motion.div {...stage(0.45)} className="lg:col-span-4"><HeroSpotlight /></motion.div>
          </div>

          <motion.div {...stage(0.6)} className="mt-14 lg:mt-20">
            <Rail tone="invert" label="Featured insights" slide="basis-[82%] sm:basis-1/2 lg:basis-1/4" heading={<p className="text-xs font-semibold uppercase tracking-[0.16em] text-ink-foreground/60">Featured thinking</p>}>
              {posts.slice(0, 6).map((p, i) => {
                const tone = ["bg-background text-foreground", "bg-secondary text-foreground", "bg-primary text-primary-foreground", "bg-navy-soft text-foreground"][i % 4];
                const kick = i % 4 === 2 ? "text-signal" :  "text-muted-foreground";
                const chip = i % 4 === 2 ? "bg-signal text-ink" :  "bg-primary text-primary-foreground";
                return (
                  <Link key={p.slug} to="/insights/$slug" params={{ slug: p.slug }} className={`group flex h-full min-h-[220px] flex-col justify-between p-7 transition-transform duration-300 hover:-translate-y-1.5 sm:min-h-[260px] ${tone}`}>
                    <div>
                      <p className={`text-xs font-semibold uppercase tracking-[0.12em] ${kick}`}>{p.category}</p>
                      <h3 className="mt-5 text-[1.375rem] font-medium leading-[1.2] tracking-tight">{p.title}</h3>
                    </div>
                    <span className="mt-8 inline-flex items-center gap-2 text-sm font-semibold">Read <span className={`grid h-7 w-7 place-items-center transition-transform group-hover:translate-x-1 ${chip}`}><ArrowRight className="h-3.5 w-3.5" /></span></span>
                  </Link>
                );
              })}
            </Rail>
          </motion.div>
        </div>
      </section>

      {/* TICKER */}
      <div className="border-b border-border bg-primary py-5 text-primary-foreground" aria-label="Areas we help with">
        <Marquee items={problemAreas.map((p) => (
          <Link to="/solve" search={{ q: p.prompt, c: p.category }} className="flex items-center gap-6 px-6 text-[clamp(1.25rem,2.4vw,2rem)] font-medium tracking-[-0.03em] hover:text-signal">
            {p.title}<Arrow className="h-[0.6em]" />
          </Link>
        ))} />
      </div>

      {/* FACTS — what the assessment covers (real counts from site content) */}
      <section className="border-b border-border bg-background">
        <div className="container-page grid grid-cols-2 lg:grid-cols-4">
          {[[services.length, "Consulting services", "/services"], [industries.length, "Industries covered", "/industries"], [problemAreas.length, "Problem areas mapped", "/solve"], [methodology.length, "Stages in our method", "/how-it-works"]].map(([n, l, to], i) => (
            <Reveal key={l as string} delay={i * 0.08} className={`border-border py-10 sm:py-14 ${i % 2 ? "border-l pl-6 sm:pl-10" : "lg:pl-0"} ${i === 2 ? "lg:border-l lg:pl-10" : ""} ${i > 1 ? "border-t lg:border-t-0" : ""}`}>
              <Link to={to as string} className="group block">
                <CountUp to={n as number} className="font-display text-[clamp(3.5rem,8vw,6.5rem)] font-semibold leading-none tracking-[-0.06em] text-primary" />
                <p className="mt-3 flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors group-hover:text-foreground">{l as string}<ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></p>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* PROBLEM SOLVER */}
      <Section tone="surface">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-5 lg:sticky lg:top-28 lg:self-start">
            <SectionHeading eyebrow="AI Problem Solver" title="Start With Your Business Problem. Not With AI Tools." text="Every business operates differently. Describe what's slowing your organization down, and discover where AI could help." />
            <ol className="-mt-4 space-y-0 border-l border-border-strong">
              {[["Describe", "Plain language. No technical terms needed."], ["Answer a few questions", "Tailored to what you wrote, not a fixed form."], ["Get your report", "Use cases, feasibility and a clear next step."]].map(([t, d], i) => (
                <Reveal as="li" key={t} delay={0.1 + i * 0.1} className="relative py-3 pl-6">
                  <span className="absolute -left-[5px] top-[1.15rem] h-2.5 w-2.5 rounded-full border-2 border-background bg-primary" />
                  <p className="font-semibold text-foreground"><span className="mr-2 font-display text-xs text-muted-foreground">0{i + 1}</span>{t}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{d}</p>
                </Reveal>
              ))}
            </ol>
          </div>
          <Reveal delay={0.1} className="lg:col-span-7"><ProblemComposer /></Reveal>
        </div>
      </Section>

      {/* HOW IT WORKS */}
      <Section>
        <SectionHeading eyebrow="How it works" title="From Business Challenge to Practical AI Opportunity." />
        <ol className="relative grid gap-10 md:grid-cols-3 md:gap-8">
          <motion.span aria-hidden initial={reduce ? false : { scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true, margin: "-80px" }} transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }} className="absolute left-0 right-0 top-[2.6rem] hidden h-px origin-left bg-border-strong md:block" />
          {[["01", "Describe", "Tell us what is happening inside your business."], ["02", "Discover", "Our AI assessment identifies relevant use cases and potential improvements."], ["03", "Connect", "Explore consulting and implementation options with Scovatics."]].map(([n, t, d], i) => (
            <Reveal as="li" key={n} delay={0.2 + i * 0.15} className="relative">
              <span className="relative z-10 inline-block bg-background pr-4 font-display text-[5.25rem] font-semibold leading-none tracking-[-0.06em] text-outline-muted">{n}</span>
              <h3 className="mt-6 text-2xl font-semibold text-foreground">{t}</h3>
              <p className="mt-3 max-w-xs leading-relaxed text-muted-foreground">{d}</p>
            </Reveal>
          ))}
        </ol>
        <Reveal className="mt-12"><Link to="/how-it-works" className="group inline-flex items-center gap-2 text-sm font-semibold text-primary">See the full journey <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></Link></Reveal>
      </Section>

      {/* SCENARIOS — tilted card carousel */}
      <section className="section-y overflow-hidden bg-ink text-ink-foreground">
        <div className="container-page">
          <Reveal className="mx-auto mb-12 max-w-3xl text-center">
            <p className="eyebrow mb-5 inline-flex items-center gap-3 text-signal"><span className="h-1.5 w-1.5 bg-signal" />Where AI fits</p>
            <h2 className="display-lg text-ink-foreground">One Method. Every Industry.</h2>
            <p className="mt-5 text-lg text-ink-foreground/65">Illustrative examples of where an assessment typically starts. Pick an industry to explore.</p>
          </Reveal>
          <Coverflow />
        </div>
      </section>

      {/* PROBLEMS — bento-style grid */}
      <Section tone="surface">
        <SectionHeading eyebrow="Problems we help solve" title="Where Is Your Business Losing Time?" text="Select an area to start an assessment with a relevant starting point." />
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
          {problemAreas.map((p, i) => (
            <Reveal key={p.title} delay={(i % 4) * 0.05} className={WIDE.includes(i) ? "col-span-2" : ""}>
              <Link to="/solve" search={{ q: p.prompt, c: p.category }} className={`group relative flex h-full min-h-[150px] flex-col overflow-hidden rounded-xl border border-border bg-background p-5 transition-all duration-300 hover:-translate-y-1 hover:border-primary hover:bg-primary sm:p-7 ${WIDE.includes(i) ? "lg:min-h-[220px]" : ""}`}>
                <div className="flex items-start justify-between">
                  <span className="grid h-10 w-10 place-items-center rounded-lg bg-navy-soft transition-colors group-hover:bg-primary-foreground/10"><p.icon className="h-[18px] w-[18px] text-primary transition-colors group-hover:text-signal" strokeWidth={1.6} /></span>
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-signal" />
                </div>
                <h3 className={`mt-auto pt-6 font-sans font-semibold tracking-tight text-foreground transition-colors group-hover:text-primary-foreground ${WIDE.includes(i) ? "text-xl sm:text-2xl" : "text-[0.95rem]"}`}>{p.title}</h3>
                <p className={`mt-2 text-sm leading-relaxed text-muted-foreground transition-colors group-hover:text-primary-foreground/70 ${WIDE.includes(i) ? "" : "hidden sm:block"}`}>{p.text}</p>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* SERVICES — scroll-stacking cards */}
      <section className="section-y bg-ink text-ink-foreground">
        <div className="container-page">
          <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
            <div className="lg:col-span-8">
              <p className="eyebrow mb-6 flex items-center gap-3 text-signal"><span className="h-1.5 w-1.5 bg-signal" />Services</p>
              <h2 className="display-lg text-ink-foreground">AI Strategy Meets Real Business Implementation.</h2>
            </div>
            <div className="lg:col-span-4 lg:text-right"><Button asChild variant="outline" className="border-ink-foreground/25 bg-transparent text-ink-foreground hover:bg-ink-foreground hover:text-ink"><Link to="/services">All services <ArrowRight /></Link></Button></div>
          </div>
          <StackCards />
        </div>
      </section>

      {/* INDUSTRIES — image card carousel */}
      <Section>
        <Rail label="Industries" slide="basis-[86%] sm:basis-1/2 lg:basis-[38%]" heading={<SectionHeading eyebrow="Industries" title="AI Opportunities Across Industries." />}>
          {industries.map((ind) => (
            <Link key={ind.slug} to="/industries/$slug" params={{ slug: ind.slug }} className="group relative block aspect-[4/5] overflow-hidden rounded-2xl sm:aspect-[3/4] lg:aspect-[4/5]">
              <img src={ind.image} alt="" loading="lazy" width={1280} height={896} className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-x-3 bottom-3 rounded-xl bg-background p-5 transition-transform duration-300 group-hover:-translate-y-1 sm:inset-x-4 sm:bottom-4 sm:p-6">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">Industry</p>
                <h3 className="mt-2 flex items-center justify-between text-xl font-semibold text-foreground">{ind.name}<span className="grid h-8 w-8 place-items-center rounded-full bg-primary text-primary-foreground transition-transform group-hover:rotate-[-45deg]"><ArrowRight className="h-3.5 w-3.5" /></span></h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{ind.short}</p>
              </div>
            </Link>
          ))}
        </Rail>
      </Section>

      {/* APPROACH — expandable stages */}
      <Section tone="surface">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4 lg:sticky lg:top-28 lg:self-start">
            <SectionHeading eyebrow="Our approach" title="We Don't Start With Technology. We Start With Understanding Your Business." />
          </div>
          <Reveal delay={0.1} className="lg:col-span-8"><StageList items={methodology} /></Reveal>
        </div>
      </Section>

      {/* RESPONSIBLE AI BANNER + PRINCIPLES */}
      <Section>
        <Reveal>
          <Link to="/responsible-ai" className="group relative block overflow-hidden rounded-2xl bg-ink text-ink-foreground">
            <img src={bannerImg} alt="" loading="lazy" width={1920} height={832} className="absolute inset-0 h-full w-full object-cover opacity-60 transition-transform duration-700 group-hover:scale-[1.03]" />
            <div className="absolute inset-0 bg-ink/40" />
            <div className="relative grid gap-8 p-7 sm:p-10 lg:grid-cols-2 lg:items-end lg:p-14">
              <div>
                <p className="eyebrow mb-5 flex items-center gap-3 text-signal"><span className="h-1.5 w-1.5 bg-signal" />Trust & responsible AI</p>
                <h2 className="display-lg text-ink-foreground">AI That Your Organisation Can Rely On.</h2>
              </div>
              <div className="lg:pb-2">
                <p className="text-lg leading-relaxed text-ink-foreground/80">Controls are designed into every engagement from the beginning, not added afterwards.</p>
                <span className="mt-6 inline-flex items-center gap-2 rounded-full bg-signal px-5 py-2.5 text-sm font-semibold text-ink">Read our principles <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></span>
              </div>
            </div>
          </Link>
        </Reveal>
        <div className="mt-3 grid grid-cols-2 gap-3 lg:mt-6 lg:grid-cols-3">
          {[
            [Lock, "Data privacy", "Clarity on what data is used, where it is processed and who can access the outputs."],
            [UserCheck, "Human oversight", "People review and approve wherever outcomes are consequential."],
            [ShieldCheck, "Security", "Access controls and secure integration patterns are part of the design."],
            [Scale, "Responsible AI", "Use cases are assessed for fairness, appropriateness and risk."],
            [Gauge, "Reliability", "Solutions are evaluated against real cases before and after release."],
            [Eye, "Transparency", "Assumptions, limitations and sources are made visible to users."],
          ].map(([Icon, t, d], i) => {
            const I = Icon as typeof Lock;
            return (
              <Reveal key={t as string} delay={i * 0.05} className="group rounded-xl border border-border p-5 transition-colors sm:p-7 duration-300 hover:border-primary">
                <I className="h-5 w-5 text-primary transition-transform duration-300 group-hover:scale-110" strokeWidth={1.6} />
                <h3 className="mt-4 text-base font-semibold text-foreground sm:mt-5 sm:text-lg">{t as string}</h3>
                <p className="mt-2 text-xs sm:text-sm leading-relaxed text-muted-foreground">{d as string}</p>
              </Reveal>
            );
          })}
        </div>
      </Section>

      {/* INSIGHTS — editorial carousel */}
      <Section tone="surface">
        <Rail label="Insights" slide="basis-[86%] sm:basis-1/2 lg:basis-1/3" heading={<SectionHeading eyebrow="Insights" title="Practical Thinking on Enterprise AI." />}>
          {posts.map((p) => (
            <Link key={p.slug} to="/insights/$slug" params={{ slug: p.slug }} className="group flex h-full min-h-[300px] flex-col rounded-2xl border border-border bg-background p-7 transition-all duration-300 hover:-translate-y-1 hover:border-primary">
              <div className="flex items-center justify-between gap-3">
                <span className="rounded-full bg-navy-soft px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.1em] text-primary">{p.category}</span>
                <span className="text-xs text-muted-foreground">{p.readingMinutes} min</span>
              </div>
              <h3 className="mt-6 text-[1.375rem] font-semibold leading-snug tracking-tight text-foreground transition-colors group-hover:text-primary">{p.title}</h3>
              <p className="mt-3 line-clamp-3 flex-1 text-sm leading-relaxed text-muted-foreground">{p.excerpt}</p>
              <div className="mt-6 flex items-center justify-between border-t border-border pt-5">
                <time dateTime={p.published_at} className="text-xs text-muted-foreground">{fmtDate(p.published_at)}</time>
                <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-primary-foreground transition-transform duration-300 group-hover:rotate-[-45deg]"><ArrowRight className="h-4 w-4" /></span>
              </div>
            </Link>
          ))}
        </Rail>
        <Reveal className="mt-10"><Button asChild variant="outline"><Link to="/insights">All insights <ArrowRight /></Link></Button></Reveal>
      </Section>

      <CtaBand />
    </>
  );
}
