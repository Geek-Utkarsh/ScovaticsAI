import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { PageHero, Section } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { StackCards } from "@/components/site/StackCards";
import { CtaBand } from "@/components/site/CtaBand";
import { services } from "@/content/services";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/services/")({
  head: () => ({ meta: seo("AI Consulting Services", "AI strategy, enterprise integration, solution development, process transformation, responsible AI adoption and decision intelligence.") }),
  component: () => (
    <>
      <PageHero eyebrow="Services" title="From First Assessment to Working Solution." text="Six connected services that take an organisation from understanding where AI fits to running it responsibly in daily operations." />
      <Section>
        <div className="grid gap-px overflow-hidden rounded-lg border border-border bg-border md:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal key={s.slug} delay={(i % 3) * 0.06}>
              <Link to="/services/$slug" params={{ slug: s.slug }} className="group flex h-full flex-col bg-background p-8 transition-colors hover:bg-surface">
                <div className="flex items-center justify-between"><s.icon className="h-6 w-6 text-primary" strokeWidth={1.5} /><span className="font-display text-sm text-muted-foreground">{s.number}</span></div>
                <h2 className="mt-10 text-xl font-semibold text-foreground group-hover:text-primary">{s.name}</h2>
                <p className="mt-3 flex-1 leading-relaxed text-muted-foreground">{s.short}</p>
                <ul className="mt-6 space-y-1.5 border-t border-border pt-5 text-sm text-foreground/80">{s.capabilities.slice(0, 3).map((c) => <li key={c.title}>{c.title}</li>)}</ul>
                <span className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary">Explore service <ArrowUpRight className="h-4 w-4" /></span>
              </Link>
            </Reveal>
          ))}
        </div>
      </Section>
      <section className="section-y bg-ink text-ink-foreground"><div className="container-page"><p className="eyebrow flex items-center gap-3 text-signal"><span className="h-1.5 w-1.5 bg-signal" />Scroll through each service</p><StackCards /></div></section>
      <CtaBand title="Not Sure Which Service Fits?" text="Describe the problem instead. The assessment will suggest the most relevant starting point." cta="Analyze a Business Problem" />
    </>
  ),
});
