import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHero, Section, SectionHeading } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { CtaBand } from "@/components/site/CtaBand";
import { methodology } from "@/content/problems";
import { seo } from "@/lib/seo";

const journey = [
  ["Describe your problem", "In plain language, explain what is taking too much time, costing too much or slowing the business. No technical knowledge is needed."],
  ["Answer a few targeted questions", "The assessment asks only what it needs to understand your situation — typically two to five short questions."],
  ["Receive your opportunity report", "A structured initial assessment: challenges, relevant AI use cases, qualitative impact, feasibility and a suggested next step. Facts you provided are separated from assumptions."],
  ["Choose how to continue", "If the report is useful, select a consulting option and share your details. The report is attached to your enquiry."],
  ["Consultation", "A Scovatics consultant reviews your report and discusses your systems, data and priorities to validate the opportunity."],
  ["Engagement and implementation", "Where it makes sense, we agree a defined scope — from an opportunity assessment through to implementation and ongoing optimisation."],
];

export const Route = createFileRoute("/how-it-works")({
  head: () => ({ meta: seo("How It Works", "The journey from describing a business problem to an AI opportunity report, consultation and implementation with Scovatics.") }),
  component: () => (
    <>
      <PageHero eyebrow="How it works" title="From Business Challenge to Practical AI Opportunity." text="A clear path from your first description of a problem to a validated, implemented improvement.">
        <Button asChild size="lg"><Link to="/solve">Start the Assessment <ArrowRight /></Link></Button>
      </PageHero>
      <Section>
        <ol className="relative mx-auto max-w-3xl">
          <span aria-hidden className="absolute bottom-6 left-[19px] top-6 w-px bg-border" />
          {journey.map(([t, d], i) => (
            <Reveal as="li" key={t} delay={i * 0.04} className="relative grid grid-cols-[40px_1fr] gap-6 pb-12 last:pb-0">
              <span className={`relative z-10 grid h-10 w-10 place-items-center rounded-full border font-display text-sm ${i < 3 ? "border-primary bg-primary text-primary-foreground" : "border-border-strong bg-background text-primary"}`}>{i + 1}</span>
              <div className="pt-1.5"><p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">{i < 3 ? "Online assessment" : i === 3 ? "Your decision" : "With Scovatics"}</p><h2 className="mt-2 text-2xl font-semibold text-foreground">{t}</h2><p className="mt-3 leading-relaxed text-muted-foreground">{d}</p></div>
            </Reveal>
          ))}
        </ol>
      </Section>
      <Section tone="surface">
        <SectionHeading eyebrow="Methodology" title="How engagements are structured." />
        <ol className="grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">{methodology.map((m, i) => <li key={m.name} className="bg-background p-7"><span className="font-display text-sm text-signal">0{i + 1}</span><h3 className="mt-4 text-lg font-semibold">{m.name}</h3><p className="mt-2 text-sm text-muted-foreground">{m.text}</p></li>)}</ol>
      </Section>
      <Section>
        <div className="grid gap-10 lg:grid-cols-2">
          <div><SectionHeading eyebrow="What the free assessment includes" title="Genuine value, clearly scoped." /></div>
          <div className="grid gap-8 sm:grid-cols-2">
            <div><p className="mb-3 font-semibold text-foreground">Included</p><ul className="space-y-2 text-sm text-muted-foreground">{["Problem overview and challenges", "Two to four relevant use cases", "Qualitative impact", "Feasibility and oversight considerations", "A recommended next step"].map((x) => <li key={x}>{x}</li>)}</ul></div>
            <div><p className="mb-3 font-semibold text-foreground">Requires an engagement</p><ul className="space-y-2 text-sm text-muted-foreground">{["System architecture", "Integration design", "Cost estimates", "Validated business case", "Deployment planning"].map((x) => <li key={x}>{x}</li>)}</ul></div>
          </div>
        </div>
      </Section>
      <CtaBand />
    </>
  ),
});
