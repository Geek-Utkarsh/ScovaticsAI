import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { PageHero, Section } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { Coverflow } from "@/components/site/Coverflow";
import { CtaBand } from "@/components/site/CtaBand";
import { industries } from "@/content/industries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/industries/")({
  head: () => ({ meta: seo("Industries", "AI opportunities in manufacturing, logistics, finance, healthcare and technology, grounded in each sector's real operational challenges.") }),
  component: () => (
    <>
      <PageHero eyebrow="Industries" title="AI Opportunities Across Industries." text="Every sector has its own constraints, data and risks. We start from the operational reality of each one." />
      <section className="section-y overflow-hidden bg-ink text-ink-foreground">
        <div className="container-page"><Coverflow /></div>
      </section>
      <Section>
        <div className="space-y-20">
          {industries.map((ind, i) => (
            <Reveal key={ind.slug} className="grid items-center gap-10 lg:grid-cols-12">
              <div className={`group overflow-hidden rounded-2xl lg:col-span-7 ${i % 2 ? "lg:order-2" : ""}`}><img src={ind.image} alt="" loading="lazy" width={1280} height={896} className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105" /></div>
              <div className="lg:col-span-5">
                <span className="font-display text-sm text-signal">0{i + 1}</span>
                <h2 className="mt-3 text-3xl font-semibold text-foreground">{ind.name}</h2>
                <p className="mt-4 leading-relaxed text-muted-foreground">{ind.intro}</p>
                <ul className="mt-6 space-y-2 text-sm text-foreground">{ind.opportunities.map((o) => <li key={o.title} className="flex gap-3"><span className="mt-2 h-1 w-1 rounded-full bg-primary" />{o.title}</li>)}</ul>
                <Link to="/industries/$slug" params={{ slug: ind.slug }} className="mt-8 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">Explore {ind.name} <ArrowUpRight className="h-4 w-4" /></Link>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>
      <CtaBand />
    </>
  ),
});
