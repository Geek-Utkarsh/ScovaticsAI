import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Section, SectionHeading } from "@/components/site/Section";
import { Reveal } from "@/components/site/Reveal";
import { CtaBand } from "@/components/site/CtaBand";
import { Faq } from "@/components/site/Faq";
import { getService, services } from "@/content/services";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => { const s = getService(params.slug); if (!s) throw notFound(); return { slug: s.slug }; },
  head: ({ params }) => { const s = getService(params.slug); return { meta: s ? seo(s.name, s.intro) : [{ title: "Service not found | Scovatics" }, { name: "robots", content: "noindex" }] }; },
  component: ServicePage,
});

function ServicePage() {
  const { slug } = Route.useParams();
  const s = getService(slug)!;
  const others = services.filter((x) => x.slug !== slug).slice(0, 3);
  return (
    <>
      <section className="border-b border-border pb-16 pt-32 lg:pb-24 lg:pt-44">
        <div className="container-page grid gap-12 lg:grid-cols-12">
          <Reveal className="lg:col-span-8">
            <p className="eyebrow mb-5 flex items-center gap-3"><Link to="/services" className="hover:underline">Services</Link><span className="text-muted-foreground">/</span>{s.number}</p>
            <h1 className="display-xl text-foreground">{s.headline}</h1>
            <p className="lead mt-6 max-w-2xl">{s.intro}</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button asChild size="lg"><Link to="/solve">Assess a Problem <ArrowRight /></Link></Button>
              <Button asChild size="lg" variant="outline"><Link to="/contact">Talk to Scovatics</Link></Button>
            </div>
          </Reveal>
          <Reveal delay={0.1} className="flex items-start lg:col-span-4 lg:justify-end">
            <div className="grid h-28 w-28 place-items-center rounded-xl border border-border bg-surface"><s.icon className="h-10 w-10 text-primary" strokeWidth={1.3} /></div>
          </Reveal>
        </div>
      </section>

      <Section>
        <SectionHeading eyebrow="What's included" title={`${s.name}, in practice.`} />
        <div className="grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
          {s.capabilities.map((c, i) => (
            <Reveal key={c.title} delay={(i % 3) * 0.05} className="border-t border-border pt-5">
              <h3 className="font-sans text-base font-semibold tracking-normal text-foreground">{c.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.text}</p>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section tone="surface">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <SectionHeading eyebrow="Business challenges" title="When organisations come to us." />
            <ul className="space-y-0 border-t border-border">{s.challenges.map((c) => <li key={c} className="border-b border-border py-4 text-foreground">{c}</li>)}</ul>
          </div>
          <div>
            <SectionHeading eyebrow="Relevant use cases" title="Typical outcomes we work towards." />
            <ul className="space-y-0 border-t border-border">{s.useCases.map((c) => <li key={c} className="border-b border-border py-4 text-foreground">{c}</li>)}</ul>
            <Link to="/use-cases" className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">Browse the use-case library <ArrowUpRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </Section>

      <Section>
        <SectionHeading eyebrow="Our approach" title="How Scovatics approaches the work." />
        <ol className="grid gap-px overflow-hidden rounded-lg border border-border bg-border md:grid-cols-4">
          {s.approach.map((a, i) => (
            <Reveal as="li" key={a.step} delay={i * 0.06} className="bg-background p-7">
              <span className="font-display text-sm text-signal">0{i + 1}</span>
              <h3 className="mt-4 text-lg font-semibold text-foreground">{a.step}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{a.text}</p>
            </Reveal>
          ))}
        </ol>
      </Section>

      <Section tone="surface">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHeading eyebrow="Engagement structure" title="Ways to work together." text="Scope and fees are agreed before any work begins." />
            <div className="space-y-4">{s.engagement.map((e) => <div key={e.name} className="rounded-lg border border-border bg-background p-6"><p className="font-semibold text-foreground">{e.name}</p><p className="mt-1.5 text-sm text-muted-foreground">{e.text}</p></div>)}</div>
          </div>
          <div className="lg:col-span-7">
            <SectionHeading eyebrow="FAQ" title="Common questions." />
            <Faq items={s.faqs} />
          </div>
        </div>
      </Section>

      <Section>
        <p className="eyebrow mb-6">Related services</p>
        <div className="grid gap-6 md:grid-cols-3">{others.map((o) => <Link key={o.slug} to="/services/$slug" params={{ slug: o.slug }} className="group border-t border-border pt-5"><o.icon className="h-5 w-5 text-primary" /><p className="mt-4 font-semibold text-foreground group-hover:text-primary">{o.name}</p><p className="mt-1 text-sm text-muted-foreground">{o.short}</p></Link>)}</div>
      </Section>
      <CtaBand />
    </>
  );
}
