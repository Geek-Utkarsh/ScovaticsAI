import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Section } from "@/components/site/Section";
import { PostCard } from "@/components/site/PostCard";
import { CtaBand } from "@/components/site/CtaBand";
import { postQuery, postsQuery, fmtDate } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/insights/$slug")({
  loader: async ({ context, params }) => {
    const [p] = await Promise.all([context.queryClient.ensureQueryData(postQuery(params.slug)), context.queryClient.ensureQueryData(postsQuery)]);
    if (!p) throw notFound();
    return p;
  },
  head: ({ loaderData }) => ({
    meta: loaderData ? seo(loaderData.title, loaderData.excerpt, "article") : [{ title: "Article unavailable | Scovatics" }, { name: "robots", content: "noindex" }],
    scripts: loaderData ? [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@type": "Article", headline: loaderData.title, datePublished: loaderData.published_at, publisher: { "@type": "Organization", name: "Scovatics" } }) }] : [],
  }),
  component: Article,
});

function render(body: string) {
  return body.split(/\n\n+/).map((b, i) => b.startsWith("## ") ? <h2 key={i}>{b.slice(3)}</h2> : <p key={i}>{b}</p>);
}

function Article() {
  const { slug } = Route.useParams();
  const { data: p } = useSuspenseQuery(postQuery(slug));
  const { data: all } = useSuspenseQuery(postsQuery);
  if (!p) return null;
  const related = all.filter((x) => x.slug !== slug).sort((a, b) => Number(b.category === p.category) - Number(a.category === p.category)).slice(0, 3);
  return (
    <>
      <article className="pb-16 pt-32 lg:pt-44">
        <div className="container-page max-w-3xl">
          <Link to="/insights" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> All insights</Link>
          <p className="mt-10 flex flex-wrap gap-3 text-sm text-muted-foreground"><span className="font-medium uppercase tracking-[0.12em] text-primary">{p.category}</span><span>·</span><time dateTime={p.published_at}>{fmtDate(p.published_at)}</time><span>·</span><span>{p.readingMinutes} min read</span></p>
          <h1 className="display-lg mt-5 text-foreground">{p.title}</h1>
          <p className="lead mt-6 border-b border-border pb-10">{p.excerpt}</p>
          <div className="prose-article mt-10">{render(p.body)}</div>
        </div>
      </article>
      <Section tone="surface"><p className="eyebrow mb-8">Related articles</p><div className="grid gap-10 md:grid-cols-3">{related.map((r) => <PostCard key={r.slug} p={r} />)}</div></Section>
      <CtaBand />
    </>
  );
}
