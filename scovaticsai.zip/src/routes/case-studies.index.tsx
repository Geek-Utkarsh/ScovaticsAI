import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowUpRight } from "lucide-react";
import { PageHero, Section } from "@/components/site/Section";
import { CtaBand } from "@/components/site/CtaBand";
import { caseStudiesQuery } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/case-studies/")({
  head: () => ({ meta: seo("Case Studies", "How Scovatics documents AI engagements: client context, problem, approach, implementation, verified outcomes and lessons learned.") }),
  loader: ({ context }) => context.queryClient.ensureQueryData(caseStudiesQuery),
  component: () => {
    const { data } = useSuspenseQuery(caseStudiesQuery);
    return (
      <>
        <PageHero eyebrow="Case studies" title="Evidence, Not Claims." text="We publish case studies only with verified outcomes and client permission. Examples marked illustrative show the structure we use and do not describe real clients." />
        <Section>
          {data.length === 0 ? <p className="rounded-lg border border-dashed border-border p-12 text-center text-muted-foreground">Verified case studies will be published here.</p> : (
            <div className="grid gap-6 md:grid-cols-2">{data.map((c) => (
              <Link key={c.id} to="/case-studies/$slug" params={{ slug: c.slug }} className="group rounded-lg border border-border p-8 hover:border-primary/50">
                <div className="flex gap-2 text-xs">{c.illustrative && <span className="rounded-[4px] border border-dashed border-border-strong px-2 py-0.5 font-medium text-muted-foreground">Illustrative example</span>}<span className="rounded-[4px] bg-navy-soft px-2 py-0.5 text-primary">{c.industry}</span></div>
                <h2 className="mt-5 text-xl font-semibold text-foreground group-hover:text-primary">{c.title}</h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c.business_problem}</p>
                <span className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary">Read <ArrowUpRight className="h-4 w-4" /></span>
              </Link>
            ))}</div>
          )}
        </Section>
        <CtaBand />
      </>
    );
  },
});
