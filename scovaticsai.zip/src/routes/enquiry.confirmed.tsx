import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/enquiry/confirmed")({
  validateSearch: (s: Record<string, unknown>): { ref?: string | undefined } => { const r = s["ref"]; return { ref: typeof r === "string" && /^SCV-\d{6}-[A-Z0-9]{6}$/.test(r) ? r : undefined }; },
  head: () => ({ meta: [{ title: "Enquiry Received | Scovatics" }, { name: "description", content: "Thank you for contacting Scovatics." }, { name: "robots", content: "noindex" }, { property: "og:title", content: "Enquiry Received | Scovatics" }, { property: "og:description", content: "Thank you for contacting Scovatics." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: Confirmed,
});

function Confirmed() {
  const { ref } = Route.useSearch();
  return (
    <div className="container-page flex min-h-[80vh] items-center py-36">
      <div className="max-w-2xl">
        <CheckCircle2 className="h-8 w-8 text-primary" strokeWidth={1.6} />
        <h1 className="display-lg mt-6 text-foreground">Thank you. Your enquiry has been received.</h1>
        {ref ? (
          <p className="mt-6 text-lg text-muted-foreground">Your enquiry reference is <span className="font-display font-semibold text-primary">{ref}</span>. Please quote it in any correspondence.</p>
        ) : (
          <p className="mt-6 text-lg text-muted-foreground">If you reached this page without submitting a form, please use the contact page.</p>
        )}
        <p className="mt-4 leading-relaxed text-muted-foreground">A member of the Scovatics team will review your enquiry and any linked assessment, and respond using the business email you provided.</p>
        <div className="mt-10 flex flex-wrap gap-3">
          <Button asChild><Link to="/services">Explore Our Services</Link></Button>
          <Button asChild variant="outline"><Link to="/insights">Read Insights</Link></Button>
        </div>
      </div>
    </div>
  );
}
