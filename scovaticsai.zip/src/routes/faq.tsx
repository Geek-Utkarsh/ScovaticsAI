import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { PageHero, Section } from "@/components/site/Section";
import { Faq } from "@/components/site/Faq";
import { CtaBand } from "@/components/site/CtaBand";
import { faqsQuery } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/faq")({
  head: () => ({ meta: seo("Frequently Asked Questions", "Answers about AI consulting, assessments, data privacy, pricing, timelines, existing systems and human oversight.") }),
  loader: ({ context }) => context.queryClient.ensureQueryData(faqsQuery),
  component: () => {
    const { data } = useSuspenseQuery(faqsQuery);
    const topics = [...new Set(data.map((f) => f.topic))];
    return (
      <>
        <PageHero eyebrow="FAQ" title="Frequently Asked Questions." />
        <Section>
          <div className="mx-auto max-w-4xl space-y-14">
            {topics.map((t) => <div key={t} className="grid gap-6 md:grid-cols-3"><h2 className="text-lg font-semibold text-foreground">{t}</h2><div className="md:col-span-2"><Faq items={data.filter((f) => f.topic === t).map((f) => ({ q: f.question, a: f.answer }))} /></div></div>)}
          </div>
        </Section>
        <CtaBand />
      </>
    );
  },
});
