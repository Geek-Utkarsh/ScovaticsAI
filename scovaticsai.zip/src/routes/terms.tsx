import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/site/LegalPage";
import { seo } from "@/lib/seo";
export const Route = createFileRoute("/terms")({
  head: () => ({ meta: seo("Terms of Use", "Terms governing use of the Scovatics website and the AI Problem Solver.") }),
  component: () => <LegalPage eyebrow="Legal" title="Terms of Use" intro="Terms governing use of this website and its tools." sections={[
    { h: "Use of the website", p: "This website provides information about Scovatics services and an online AI assessment tool for business visitors." },
    { h: "AI-generated assessments", p: "Assessments are automatically generated, indicative and based only on the information provided. They are not professional advice, implementation plans or guarantees of any outcome, and should be validated before any decision is made." },
    { h: "Your responsibilities", p: "Do not submit confidential, personal or unlawful content to the assessment tool." },
    { h: "Intellectual property", p: "Website content is owned by Scovatics unless stated otherwise." },
    { h: "Liability", p: "Limitations of liability and governing law will be set out here following legal review." },
  ]} />,
});
