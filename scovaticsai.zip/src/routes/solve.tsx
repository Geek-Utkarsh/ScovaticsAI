import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowLeft, ArrowRight, Loader2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AssessmentProgress } from "@/components/site/Progress";
import { categories } from "@/content/problems";
import { startAssessment, generateReport } from "@/lib/assessment.functions";
import type { Understanding } from "@/lib/assessment-schema";
import { seo } from "@/lib/seo";

type Search = { q?: string | undefined; c?: string | undefined };

export const Route = createFileRoute("/solve")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    q: typeof s["q"] === "string" ? s["q"].slice(0, 3000) : undefined,
    c: typeof s["c"] === "string" ? s["c"].slice(0, 40) : undefined,
  }),
  head: () => ({ meta: seo("AI Problem Solver", "Describe your business challenge in plain language and receive a structured initial AI opportunity assessment from Scovatics.") }),
  component: Solve,
});

type Phase = "entry" | "understanding" | "questions" | "report";

const ease = [0.22, 1, 0.36, 1] as const;

function Solve() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const start = useServerFn(startAssessment);
  const gen = useServerFn(generateReport);
  const [problem, setProblem] = useState(search.q ?? "");
  const [category, setCategory] = useState<string | null>(search.c ?? null);
  const [phase, setPhase] = useState<Phase>("entry");
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [u, setU] = useState<Understanding | null>(null);
  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const topRef = useRef<HTMLDivElement>(null);

  useEffect(() => { if (search.q) setProblem(search.q); if (search.c) setCategory(search.c); }, [search.q, search.c]);
  useEffect(() => { topRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }); }, [phase]);

  const analyze = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (problem.trim().length < 15) { setError("Please describe the problem in a little more detail (at least a sentence)."); return; }
    setPhase("understanding");
    try {
      const r = await start({ data: { problem: problem.trim(), category } });
      if (!r.ok) { setError(r.error); setPhase("entry"); return; }
      setToken(r.token); setU(r.understanding); setIdx(0);
      if (r.understanding.questions.length === 0) await finish(r.token, r.understanding, {});
      else setPhase("questions");
    } catch {
      setError("Something went wrong while starting your assessment. Please try again."); setPhase("entry");
    }
  };

  const finish = async (t: string, und: Understanding, ans: Record<string, string>) => {
    setPhase("report"); setError(null);
    try {
      const r = await gen({ data: { token: t, answers: und.questions.map((q) => ({ id: q.id, question: q.question, answer: ans[q.id] ?? "" })) } });
      if (!r.ok) { setError(r.error); setPhase("questions"); return; }
      navigate({ to: "/report/$token", params: { token: t } });
    } catch {
      setError("Your report could not be generated. Please try again."); setPhase("questions");
    }
  };

  const qs = u?.questions ?? [];
  const q = qs[idx];
  const next = () => { if (idx < qs.length - 1) setIdx(idx + 1); else if (token && u) finish(token, u, answers); };
  const stageIndex = phase === "entry" ? 0 : phase === "understanding" ? 0 : phase === "questions" ? 1 : 2;

  return (
    <div ref={topRef} className="min-h-screen scroll-mt-0 bg-surface pb-24 pt-28 lg:pt-36">
      <div className="container-page">
        <div className="mx-auto max-w-3xl">
          <div className="mb-10 flex items-center justify-between gap-4 border-b border-border pb-5">
            <span className="eyebrow">AI Problem Solver</span>
            {phase !== "entry" && <AssessmentProgress current={stageIndex as 0 | 1 | 2} />}
          </div>

          {error && (
            <div role="alert" className="mb-6 flex gap-3 rounded-md border border-destructive/30 bg-background p-4 text-sm text-foreground">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" /> <span>{error}</span>
            </div>
          )}

          <AnimatePresence mode="wait">
            {phase === "entry" && (
              <motion.form key="entry" onSubmit={analyze} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3, ease }}>
                <h1 className="display-lg text-foreground">Let's Understand Your Business Challenge.</h1>
                <p className="lead mt-4">Describe what's happening in your organization. You don't need technical knowledge or an understanding of AI.</p>
                <label htmlFor="problem" className="mt-10 block text-sm font-medium text-foreground">What problem is your company trying to solve?</label>
                <textarea id="problem" value={problem} onChange={(e) => setProblem(e.target.value)} rows={7} maxLength={3000} placeholder="For example: our finance team spends the first week of every month collecting figures from three systems to build the management report..." className="mt-3 block w-full resize-y rounded-lg border border-border-strong bg-background px-5 py-4 text-base leading-relaxed text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none" />
                <div className="mt-2 flex justify-between text-xs text-muted-foreground"><span>Please avoid confidential or personal information.</span><span>{problem.length}/3000</span></div>
                <fieldset className="mt-8">
                  <legend className="text-sm font-medium text-foreground">Area (optional)</legend>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {categories.map((c) => (
                      <button key={c} type="button" aria-pressed={category === c} onClick={() => setCategory(category === c ? null : c)} className={`rounded-md border px-3.5 py-2 text-sm transition-colors ${category === c ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background text-foreground/80 hover:border-primary/50"}`}>{c}</button>
                    ))}
                  </div>
                </fieldset>
                <Button type="submit" size="lg" className="mt-10">Analyze My Problem <ArrowRight /></Button>
              </motion.form>
            )}

            {phase === "understanding" && (
              <motion.div key="und" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="rounded-lg border border-border bg-background p-8">
                <div className="flex items-center gap-3 text-sm text-foreground"><Loader2 className="h-4 w-4 animate-spin text-primary" /> Reading your description and identifying what we need to know…</div>
                <p className="mt-6 border-l-2 border-border pl-4 text-sm leading-relaxed text-muted-foreground">{problem}</p>
              </motion.div>
            )}

            {phase === "questions" && q && u && (
              <motion.div key={`q-${idx}`} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.28, ease }}>
                {idx === 0 && (
                  <div className="mb-8 rounded-lg border border-border bg-background p-5">
                    <p className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">Our understanding · {u.department}</p>
                    <p className="mt-2 leading-relaxed text-foreground">{u.summary}</p>
                  </div>
                )}
                <p className="text-sm text-muted-foreground">Question {idx + 1} of {qs.length}</p>
                <div className="mt-3 h-[2px] w-full bg-border"><div className="h-full bg-primary transition-[width] duration-300" style={{ width: `${((idx + 1) / qs.length) * 100}%` }} /></div>
                <h2 className="mt-8 text-2xl font-semibold leading-snug text-foreground">{q.question}</h2>
                <p className="mt-2 text-sm text-muted-foreground">{q.reason}</p>
                <div className="mt-6 flex flex-wrap gap-2">
                  {q.options.map((o) => (
                    <button key={o} type="button" aria-pressed={answers[q.id] === o} onClick={() => setAnswers({ ...answers, [q.id]: o })} className={`rounded-md border px-3.5 py-2 text-sm transition-colors ${answers[q.id] === o ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background hover:border-primary/50"}`}>{o}</button>
                  ))}
                </div>
                <label htmlFor={`a-${q.id}`} className="mt-6 block text-sm font-medium text-foreground">Or in your own words</label>
                <textarea id={`a-${q.id}`} rows={3} maxLength={1000} value={answers[q.id] ?? ""} onChange={(e) => setAnswers({ ...answers, [q.id]: e.target.value })} className="mt-2 block w-full rounded-lg border border-border-strong bg-background px-4 py-3 text-base focus:border-primary focus:outline-none" />
                <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
                  <Button type="button" variant="ghost" disabled={idx === 0} onClick={() => setIdx(idx - 1)}><ArrowLeft /> Back</Button>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={next}>Skip</Button>
                    <Button type="button" onClick={next}>{idx === qs.length - 1 ? "Prepare My Assessment" : "Continue"} <ArrowRight /></Button>
                  </div>
                </div>
              </motion.div>
            )}

            {phase === "report" && (
              <motion.div key="rep" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-lg border border-border bg-background p-8">
                <div className="flex items-center gap-3 text-sm text-foreground"><Loader2 className="h-4 w-4 animate-spin text-primary" /> Preparing your AI opportunity report. This usually takes under a minute.</div>
                <ul className="mt-6 space-y-2 text-sm text-muted-foreground">
                  <li>Matching your situation against our curated use-case library</li>
                  <li>Separating the facts you provided from our assumptions</li>
                  <li>Identifying feasibility considerations and oversight needs</li>
                </ul>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
