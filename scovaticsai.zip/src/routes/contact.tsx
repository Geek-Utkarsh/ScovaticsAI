import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { EnquiryForm } from "@/components/site/EnquiryForm";
import { seo } from "@/lib/seo";
import { Mail, Phone, MapPin } from "lucide-react";
import { contact, telHref } from "@/content/contact";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: seo("Contact & Consultation", "Request a consultation with Scovatics about AI strategy, integration, solution development or process transformation.") }),
  component: () => (
    <>
      <PageHero eyebrow="Contact" title="Let's Discuss What Your Business Wants to Improve." text="Share a few details and a Scovatics consultant will respond. If you have not yet run an assessment, you can start with the AI Problem Solver." />
      <Section>
        <div className="grid gap-14 lg:grid-cols-12">
          <aside className="space-y-8 lg:col-span-4">
            {[
              { icon: Mail, label: "Email", lines: contact.emails.map((e) => ({ t: e, href: `mailto:${e}` })) },
              { icon: Phone, label: "Phone", lines: contact.phones.map((p) => ({ t: p, href: telHref(p) })) },
              { icon: MapPin, label: "Headquarters", lines: contact.address.map((t) => ({ t, href: "" })) },
            ].map(({ icon: Icon, label, lines }) => (
              <div key={label} className="flex gap-4">
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-navy-soft text-primary"><Icon className="h-5 w-5" /></span>
                <div><p className="text-sm font-semibold text-foreground">{label}</p>
                  {lines.map((l) => l.href ? <a key={l.t} href={l.href} className="mt-1 block text-sm text-muted-foreground transition-colors hover:text-primary">{l.t}</a> : <p key={l.t} className="mt-1 text-sm text-muted-foreground">{l.t}</p>)}
                </div>
              </div>
            ))}
            <div className="rounded-lg border border-border bg-surface p-5"><p className="text-sm font-semibold text-foreground">Office hours</p>{contact.hours.map((h) => <p key={h} className="mt-1.5 text-sm text-muted-foreground">{h}</p>)}</div>
            <div className="border-t border-border pt-8 text-sm leading-relaxed text-muted-foreground">We use your details only to respond to this enquiry. See the Privacy Policy for more.</div>
          </aside>
          <div className="lg:col-span-8"><EnquiryForm source="contact" /></div>
        </div>
      </Section>
    </>
  ),
});
