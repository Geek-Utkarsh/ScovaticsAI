import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { getDashboard } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/")({ component: Overview });

function Overview() {
  const fn = useServerFn(getDashboard);
  const { data, isLoading, error } = useQuery({ queryKey: ["admin-dash"], queryFn: () => fn() });
  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-primary" />;
  if (error || !data) return <p className="text-destructive">Could not load dashboard.</p>;
  const conv = data.completed ? Math.round((data.withAssessment / data.completed) * 100) : 0;
  const stats = [["Total enquiries", data.leads], ["New leads", data.newLeads], ["Qualified leads", data.qualified], ["Consultation requests (from reports)", data.consult], ["Assessments started", data.assessments], ["Assessments completed", data.completed], ["Report → enquiry conversion", data.completed ? `${conv}%` : "—"]];
  return (
    <div>
      <h1 className="text-2xl font-semibold">Overview</h1>
      <div className="mt-6 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 xl:grid-cols-4">
        {stats.map(([k, v]) => <div key={k} className="bg-background p-5"><p className="text-xs text-muted-foreground">{k}</p><p className="mt-2 font-display text-3xl font-semibold text-foreground">{v}</p></div>)}
      </div>
      <div className="mt-10 grid gap-8 xl:grid-cols-3">
        <div className="rounded-lg border border-border bg-background xl:col-span-2">
          <div className="flex items-center justify-between border-b border-border p-4"><h2 className="font-semibold">Recent enquiries</h2><Link to="/admin/leads" className="text-sm text-primary">View all</Link></div>
          {data.recent.length === 0 ? <p className="p-6 text-sm text-muted-foreground">No enquiries yet.</p> : (
            <ul className="divide-y divide-border">{data.recent.map((l) => <li key={l.id}><Link to="/admin/leads/$id" params={{ id: l.id }} className="flex items-center justify-between gap-4 p-4 hover:bg-surface"><span><span className="block text-sm font-medium">{l.full_name} · {l.company}</span><span className="text-xs text-muted-foreground">{l.enquiry_ref} · {l.interest}</span></span><span className="rounded-[4px] bg-navy-soft px-2 py-0.5 text-xs capitalize text-primary">{l.status}</span></Link></li>)}</ul>
          )}
        </div>
        <div className="rounded-lg border border-border bg-background">
          <h2 className="border-b border-border p-4 font-semibold">Common problem areas</h2>
          {data.categories.length === 0 ? <p className="p-6 text-sm text-muted-foreground">No assessments yet.</p> : <ul className="divide-y divide-border">{data.categories.map(([c, n]) => <li key={c} className="flex justify-between p-4 text-sm"><span>{c}</span><span className="text-muted-foreground">{n}</span></li>)}</ul>}
        </div>
      </div>
    </div>
  );
}
