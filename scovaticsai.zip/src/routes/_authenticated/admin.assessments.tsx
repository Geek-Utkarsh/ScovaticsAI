import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { listAssessments } from "@/lib/admin.functions";
import { ReportSummary } from "@/components/admin/ReportSummary";
import type { Report } from "@/lib/assessment-schema";

export const Route = createFileRoute("/_authenticated/admin/assessments")({ component: Assessments });

function Assessments() {
  const fn = useServerFn(listAssessments);
  const { data, isLoading } = useQuery({ queryKey: ["admin-assessments"], queryFn: () => fn() });
  const [open, setOpen] = useState<string | null>(null);
  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-primary" />;
  const rows = data ?? [];
  return (
    <div>
      <h1 className="text-2xl font-semibold">Assessments</h1>
      <p className="mt-1 text-sm text-muted-foreground">{rows.length} submitted problems</p>
      <div className="mt-6 space-y-3">
        {rows.length === 0 && <p className="rounded-lg border border-border bg-background p-6 text-sm text-muted-foreground">No assessments yet.</p>}
        {rows.map((a) => (
          <div key={a.id} className="rounded-lg border border-border bg-background">
            <button className="flex w-full items-start justify-between gap-4 p-5 text-left" onClick={() => setOpen(open === a.id ? null : a.id)} aria-expanded={open === a.id}>
              <span className="min-w-0"><span className="line-clamp-2 text-sm">{a.problem}</span><span className="mt-1 block text-xs text-muted-foreground">{a.category ?? "Uncategorised"} · {new Date(a.created_at).toLocaleString()}</span></span>
              <span className="shrink-0 rounded-[4px] bg-navy-soft px-2 py-0.5 text-xs capitalize text-primary">{a.status}</span>
            </button>
            {open === a.id && <div className="border-t border-border p-5">{a.report ? <ReportSummary r={a.report as unknown as Report} /> : <p className="text-sm text-muted-foreground">No report generated.</p>}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
