import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ArrowLeft, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { getLead, updateLead } from "@/lib/admin.functions";
import { ReportSummary } from "@/components/admin/ReportSummary";
import type { Report } from "@/lib/assessment-schema";

export const Route = createFileRoute("/_authenticated/admin/leads/$id")({ component: LeadDetail });
const statuses = ["new", "contacted", "qualified", "proposal", "won", "lost"] as const;
const inp = "mt-1.5 block w-full rounded-md border border-border-strong bg-background px-3 py-2 text-sm";

function LeadDetail() {
  const { id } = Route.useParams();
  const fn = useServerFn(getLead); const save = useServerFn(updateLead); const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["admin-lead", id], queryFn: () => fn({ data: { id } }) });
  const [form, setForm] = useState({ status: "new" as (typeof statuses)[number], notes: "", assigned_to: "", next_follow_up: "" });
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data?.lead) setForm({ status: data.lead.status as (typeof statuses)[number], notes: data.lead.notes ?? "", assigned_to: data.lead.assigned_to ?? "", next_follow_up: data.lead.next_follow_up ?? "" }); }, [data]);
  if (isLoading) return <Loader2 className="h-5 w-5 animate-spin text-primary" />;
  if (!data) return <p>Lead not found.</p>;
  const l = data.lead;
  const onSave = async () => {
    setBusy(true);
    try { await save({ data: { id, status: form.status, notes: form.notes || null, assigned_to: form.assigned_to || null, next_follow_up: form.next_follow_up || null } }); toast.success("Lead updated"); qc.invalidateQueries({ queryKey: ["admin-leads"] }); qc.invalidateQueries({ queryKey: ["admin-lead", id] }); }
    catch (e) { toast.error((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <div>
      <Link to="/admin/leads" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Leads</Link>
      <h1 className="mt-4 text-2xl font-semibold">{l.full_name} <span className="font-normal text-muted-foreground">· {l.company}</span></h1>
      <p className="mt-1 text-sm text-muted-foreground">{l.enquiry_ref} · received {new Date(l.created_at).toLocaleString()}</p>
      <div className="mt-8 grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <section className="rounded-lg border border-border bg-background p-6">
            <h2 className="font-semibold">Contact details</h2>
            <dl className="mt-4 grid gap-4 text-sm sm:grid-cols-2">
              {[["Email", l.email], ["Job role", l.job_role], ["Company size", l.company_size], ["Country", l.country], ["Interest", l.interest], ["Timeframe", l.timeframe], ["Source", l.source]].map(([k, v]) => <div key={k}><dt className="text-xs text-muted-foreground">{k}</dt><dd className="mt-0.5">{k === "Email" ? <a className="text-primary" href={`mailto:${v}`}>{v}</a> : v}</dd></div>)}
            </dl>
            {l.message && <div className="mt-4 border-t border-border pt-4 text-sm"><p className="text-xs text-muted-foreground">Message</p><p className="mt-1 whitespace-pre-wrap">{l.message}</p></div>}
            {data.consents.map((c) => <p key={c.id} className="mt-4 border-t border-border pt-4 text-xs text-muted-foreground">Consent recorded {new Date(c.created_at).toLocaleString()}: “{c.consent_text}”</p>)}
          </section>
          <section className="rounded-lg border border-border bg-background p-6">
            <h2 className="font-semibold">Associated assessment</h2>
            {data.assessment ? (
              <div className="mt-4 space-y-5">
                <div className="text-sm"><p className="text-xs text-muted-foreground">Problem described</p><p className="mt-1 whitespace-pre-wrap">{data.assessment.problem}</p></div>
                {Array.isArray(data.assessment.answers) && (data.assessment.answers as { question: string; answer: string }[]).filter((a) => a.answer).map((a) => <div key={a.question} className="text-sm"><p className="text-xs text-muted-foreground">{a.question}</p><p>{a.answer}</p></div>)}
                {data.report && <div className="border-t border-border pt-5"><ReportSummary r={data.report as unknown as Report} /></div>}
              </div>
            ) : <p className="mt-2 text-sm text-muted-foreground">This enquiry came from the contact form without an assessment.</p>}
          </section>
        </div>
        <section className="self-start rounded-lg border border-border bg-background p-6">
          <h2 className="font-semibold">Follow-up</h2>
          <div className="mt-4 space-y-4 text-sm">
            <label className="block">Status<select className={inp} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as (typeof statuses)[number] })}>{statuses.map((s) => <option key={s}>{s}</option>)}</select></label>
            <label className="block">Assigned to<input className={inp} value={form.assigned_to} onChange={(e) => setForm({ ...form, assigned_to: e.target.value })} placeholder="Team member" /></label>
            <label className="block">Next follow-up<input type="date" className={inp} value={form.next_follow_up} onChange={(e) => setForm({ ...form, next_follow_up: e.target.value })} /></label>
            <label className="block">Internal notes<textarea rows={6} className={inp} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
            <Button onClick={onSave} disabled={busy} className="w-full">{busy && <Loader2 className="animate-spin" />}Save</Button>
          </div>
        </section>
      </div>
    </div>
  );
}
