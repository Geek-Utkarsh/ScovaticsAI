import { createFileRoute, Link, Outlet, useMatch } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { listLeads } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/leads")({ component: Leads });

function Leads() {
  const child = useMatch({ from: "/_authenticated/admin/leads/$id", shouldThrow: false });
  const fn = useServerFn(listLeads);
  const { data, isLoading } = useQuery({ queryKey: ["admin-leads"], queryFn: () => fn() });
  const [q, setQ] = useState(""); const [st, setSt] = useState("");
  if (child) return <Outlet />;
  const rows = (data ?? []).filter((l) => (!st || l.status === st) && (!q || `${l.full_name} ${l.company} ${l.email} ${l.enquiry_ref}`.toLowerCase().includes(q.toLowerCase())));
  return (
    <div>
      <h1 className="text-2xl font-semibold">Leads</h1>
      <div className="mt-6 flex flex-wrap gap-3">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, company, email, reference" className="w-full max-w-sm rounded-md border border-border-strong bg-background px-3 py-2 text-sm" />
        <select value={st} onChange={(e) => setSt(e.target.value)} className="rounded-md border border-border-strong bg-background px-3 py-2 text-sm"><option value="">All statuses</option>{["new", "contacted", "qualified", "proposal", "won", "lost"].map((s) => <option key={s}>{s}</option>)}</select>
      </div>
      <div className="mt-6 overflow-x-auto rounded-lg border border-border bg-background">
        {isLoading ? <div className="p-6"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div> : rows.length === 0 ? <p className="p-6 text-sm text-muted-foreground">No leads found.</p> : (
          <table className="w-full text-left text-sm">
            <thead className="border-b border-border text-xs text-muted-foreground"><tr>{["Reference", "Name", "Company", "Interest", "Source", "Status", "Follow-up", "Received"].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-border">{rows.map((l) => (
              <tr key={l.id} className="hover:bg-surface">
                <td className="px-4 py-3"><Link to="/admin/leads/$id" params={{ id: l.id }} className="font-medium text-primary hover:underline">{l.enquiry_ref}</Link></td>
                <td className="px-4 py-3">{l.full_name}</td><td className="px-4 py-3">{l.company}</td><td className="px-4 py-3">{l.interest}</td>
                <td className="px-4 py-3">{l.assessment_id ? "Report" : "Contact"}</td><td className="px-4 py-3 capitalize">{l.status}</td>
                <td className="px-4 py-3">{l.next_follow_up ?? "—"}</td><td className="px-4 py-3 text-muted-foreground">{new Date(l.created_at).toLocaleDateString()}</td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </div>
  );
}
