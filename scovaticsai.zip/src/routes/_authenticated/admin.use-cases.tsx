import { createFileRoute } from "@tanstack/react-router";
import { ContentEditor } from "@/components/admin/ContentEditor";

export const Route = createFileRoute("/_authenticated/admin/use-cases")({
  component: () => (
    <div>
      <h1 className="text-2xl font-semibold">Use-case library</h1>
      <p className="mb-6 mt-1 text-sm text-muted-foreground">Active use cases are shown publicly and used by the AI assessment when making recommendations.</p>
      <ContentEditor table="use_case_library" titleKey="title" activeKey="active" fields={[
        { key: "title", label: "Title", type: "text" }, { key: "problem_category", label: "Problem category", type: "text" },
        { key: "ai_application", label: "AI application", type: "text" }, { key: "active", label: "Active", type: "bool" },
        { key: "industries", label: "Industries", type: "list" }, { key: "functions", label: "Business functions", type: "list" },
        { key: "summary", label: "Description", type: "textarea" }, { key: "dependencies", label: "Dependencies", type: "textarea" }, { key: "limitations", label: "Limitations", type: "textarea" },
      ]} />
    </div>
  ),
});
