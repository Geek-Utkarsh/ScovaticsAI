import { createFileRoute, Link, Outlet, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { LayoutDashboard, Users, FileSearch, Library, Newspaper, LogOut, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/site/Logo";
import { supabase } from "@/integrations/supabase/client";
import { getAdminStatus, claimFirstAdmin } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin | Scovatics" }, { name: "robots", content: "noindex, nofollow" }] }),
  component: AdminLayout,
});

const nav = [
  ["/admin", "Overview", LayoutDashboard],
  ["/admin/leads", "Leads", Users],
  ["/admin/assessments", "Assessments", FileSearch],
  ["/admin/use-cases", "Use cases", Library],
  ["/admin/content", "Content", Newspaper],
] as const;

function AdminLayout() {
  const status = useServerFn(getAdminStatus);
  const claim = useServerFn(claimFirstAdmin);
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({ queryKey: ["admin-status"], queryFn: () => status() });
  const signOut = async () => { await supabase.auth.signOut(); navigate({ to: "/auth" }); };

  if (isLoading) return <div className="grid min-h-screen place-items-center"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>;
  if (!data?.isAdmin) {
    return (
      <div className="grid min-h-screen place-items-center bg-surface px-5">
        <div className="max-w-md rounded-lg border border-border bg-background p-8">
          <Logo />
          <h1 className="mt-8 text-xl font-semibold">Admin access required</h1>
          <p className="mt-2 text-sm text-muted-foreground">Your account does not have admin access. If this is a new installation with no administrator yet, you can claim the first admin role.</p>
          <div className="mt-6 flex gap-2">
            <Button onClick={async () => { const r = await claim(); if (r.isAdmin) qc.invalidateQueries({ queryKey: ["admin-status"] }); else alert("An administrator already exists. Ask them to grant you access."); }}>Claim first admin</Button>
            <Button variant="outline" onClick={signOut}>Sign out</Button>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-surface lg:grid lg:grid-cols-[240px_1fr]">
      <aside className="border-b border-border bg-background lg:sticky lg:top-0 lg:h-screen lg:border-b-0 lg:border-r">
        <div className="flex items-center justify-between p-5 lg:block"><Logo /><p className="mt-1 hidden text-xs text-muted-foreground lg:block">Admin</p></div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:pb-0">
          {nav.map(([to, label, Icon]) => (
            <Link key={to} to={to} activeOptions={{ exact: to === "/admin" }} className="flex items-center gap-2.5 whitespace-nowrap rounded-md px-3 py-2 text-sm text-foreground/75 hover:bg-surface" activeProps={{ className: "bg-navy-soft font-medium text-primary" }}><Icon className="h-4 w-4" />{label}</Link>
          ))}
          <button onClick={signOut} className="flex items-center gap-2.5 whitespace-nowrap rounded-md px-3 py-2 text-sm text-foreground/75 hover:bg-surface lg:mt-6"><LogOut className="h-4 w-4" />Sign out</button>
        </nav>
      </aside>
      <div className="min-w-0 p-5 lg:p-10"><Outlet /></div>
    </div>
  );
}
