import { createFileRoute } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ContentEditor } from "@/components/admin/ContentEditor";

export const Route = createFileRoute("/_authenticated/admin/content")({
  component: () => (
    <div>
      <h1 className="text-2xl font-semibold">Content</h1>
      <p className="mb-6 mt-1 text-sm text-muted-foreground">Service and industry page copy is maintained in the site code; ask your developer to change it.</p>
      <Tabs defaultValue="blog">
        <TabsList><TabsTrigger value="blog">Blog posts</TabsTrigger><TabsTrigger value="faq">FAQ</TabsTrigger><TabsTrigger value="cases">Case studies</TabsTrigger></TabsList>
        <TabsContent value="blog" className="mt-6"><ContentEditor table="blog_posts" titleKey="title" activeKey="published" fields={[
          { key: "title", label: "Title", type: "text" }, { key: "slug", label: "URL slug", type: "text" }, { key: "category", label: "Category", type: "text" },
          { key: "published_at", label: "Publication date", type: "date" }, { key: "published", label: "Published", type: "bool" },
          { key: "excerpt", label: "Excerpt", type: "textarea" }, { key: "body", label: "Body (use ## for subheadings, blank line between paragraphs)", type: "textarea" },
        ]} /></TabsContent>
        <TabsContent value="faq" className="mt-6"><ContentEditor table="faqs" titleKey="question" activeKey="published" fields={[
          { key: "topic", label: "Topic", type: "text" }, { key: "sort_order", label: "Order", type: "number" }, { key: "question", label: "Question", type: "text" }, { key: "published", label: "Published", type: "bool" }, { key: "answer", label: "Answer", type: "textarea" },
        ]} /></TabsContent>
        <TabsContent value="cases" className="mt-6"><ContentEditor table="case_studies" titleKey="title" activeKey="published" fields={[
          { key: "title", label: "Title", type: "text" }, { key: "slug", label: "URL slug", type: "text" }, { key: "industry", label: "Industry", type: "text" },
          { key: "illustrative", label: "Illustrative example (not a real client)", type: "bool" }, { key: "published", label: "Published", type: "bool" },
          { key: "client_context", label: "Client context", type: "textarea" }, { key: "business_problem", label: "Business problem", type: "textarea" }, { key: "approach", label: "Approach", type: "textarea" },
          { key: "implementation", label: "Implementation", type: "textarea" }, { key: "outcomes", label: "Verified outcomes", type: "textarea" }, { key: "lessons", label: "Lessons learned", type: "textarea" },
        ]} /></TabsContent>
      </Tabs>
    </div>
  ),
});
