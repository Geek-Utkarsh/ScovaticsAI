import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { PageHero, Section } from "@/components/site/Section";
import { PostCard } from "@/components/site/PostCard";
import { CtaBand } from "@/components/site/CtaBand";
import { postsQuery } from "@/lib/queries";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/insights/")({
  head: () => ({ meta: seo("Insights", "Practical articles on AI strategy, operations, responsible AI and decision intelligence for business leaders.") }),
  loader: ({ context }) => context.queryClient.ensureQueryData(postsQuery),
  component: Insights,
});

function Insights() {
  const { data } = useSuspenseQuery(postsQuery);
  const [cat, setCat] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const cats = [...new Set(data.map((p) => p.category))];
  const list = data.filter((p) => (!cat || p.category === cat) && (!q || `${p.title} ${p.excerpt}`.toLowerCase().includes(q.toLowerCase())));
  return (
    <>
      <PageHero eyebrow="Insights" title="Practical Thinking on Enterprise AI." text="Short, useful articles for leaders deciding where and how to use AI." />
      <Section>
        <div className="mb-12 flex flex-col gap-4 border-b border-border pb-6 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2">
            {[null, ...cats].map((c) => <button key={c ?? "all"} type="button" aria-pressed={cat === c} onClick={() => setCat(c)} className={`rounded-md px-3 py-1.5 text-sm transition-colors ${cat === c ? "bg-primary text-primary-foreground" : "text-foreground/75 hover:text-primary"}`}>{c ?? "All"}</button>)}
          </div>
          <label className="relative md:w-72"><span className="sr-only">Search articles</span><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search articles" className="w-full rounded-md border border-border-strong py-2 pl-9 pr-3 text-sm focus:border-primary focus:outline-none" /></label>
        </div>
        {list.length ? <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-3">{list.map((p) => <PostCard key={p.slug} p={p} />)}</div> : <p className="py-16 text-center text-muted-foreground">No articles match your search.</p>}
      </Section>
      <CtaBand />
    </>
  );
}
