import { Compass, Plug, Boxes, Workflow, ShieldCheck, LineChart, type LucideIcon } from "lucide-react";

export type Service = {
  slug: string;
  number: string;
  name: string;
  icon: LucideIcon;
  short: string;
  headline: string;
  intro: string;
  capabilities: { title: string; text: string }[];
  challenges: string[];
  useCases: string[];
  approach: { step: string; text: string }[];
  engagement: { name: string; text: string }[];
  faqs: { q: string; a: string }[];
};

export const services: Service[] = [
  {
    slug: "ai-strategy-consulting",
    number: "01",
    name: "AI Strategy Consulting",
    icon: Compass,
    short: "Identify where AI creates measurable value, and decide what to pursue first.",
    headline: "Know Where AI Can Create Value Before You Invest.",
    intro: "We work with leadership teams to understand operations, assess readiness and build a prioritised view of the AI opportunities that matter to the business.",
    capabilities: [
      { title: "AI readiness", text: "An honest view of your data, systems, skills and governance today." },
      { title: "Use-case discovery", text: "Structured workshops with the people who run the processes." },
      { title: "Opportunity prioritisation", text: "Ranking opportunities by value, feasibility and risk." },
      { title: "Business case development", text: "Clear assumptions and measurable outcomes, without inflated projections." },
      { title: "Adoption roadmap", text: "A sequenced plan from pilot to wider rollout." },
      { title: "Governance considerations", text: "Ownership, oversight and controls defined from the start." },
    ],
    challenges: ["Many AI ideas, no agreed priorities", "Uncertainty about where to start or what is realistic", "Pressure to act without a clear business case", "Concern about risk, data and governance"],
    useCases: ["Portfolio of prioritised AI opportunities", "Readiness assessment across departments", "Executive briefing and decision workshop"],
    approach: [
      { step: "Understand", text: "Interviews and process walkthroughs with the teams involved." },
      { step: "Assess", text: "Data, systems and readiness reviewed against each opportunity." },
      { step: "Prioritise", text: "A shortlist ranked by value, effort and risk." },
      { step: "Plan", text: "Roadmap, ownership and success measures agreed." },
    ],
    engagement: [
      { name: "Opportunity Assessment", text: "A focused review of one department or process area." },
      { name: "Enterprise AI Strategy", text: "A cross-functional programme with a multi-phase roadmap." },
    ],
    faqs: [
      { q: "Do we need clean data before starting?", a: "No. Assessing data readiness is part of the work, and many opportunities start with data you already have." },
      { q: "Who should be involved?", a: "A senior sponsor plus the people who run the processes being reviewed." },
    ],
  },
  {
    slug: "enterprise-ai-integration",
    number: "02",
    name: "Enterprise AI Integration",
    icon: Plug,
    short: "Connect AI capabilities to the systems and data your business already relies on.",
    headline: "Connect AI to the Systems Your Business Already Uses.",
    intro: "AI is only useful when it fits into existing work. We integrate AI capabilities with your applications, documents and knowledge, with the right access controls.",
    capabilities: [
      { title: "Existing system assessment", text: "Map current applications, data flows and integration points." },
      { title: "API integrations", text: "Reliable connections between AI services and business systems." },
      { title: "Enterprise knowledge systems", text: "Assistants grounded in approved company information." },
      { title: "Document workflows", text: "Extraction and routing for document-heavy processes." },
      { title: "Application integration", text: "AI features embedded in tools teams already use." },
      { title: "Testing and deployment", text: "Evaluation, staged rollout and monitoring." },
    ],
    challenges: ["Systems that do not communicate with each other", "AI pilots that never reach daily work", "Data spread across tools and documents", "Security and access concerns"],
    useCases: ["Knowledge assistant over internal documentation", "CRM and support system integration", "Automated document intake into ERP"],
    approach: [
      { step: "Map", text: "Document systems, data and integration constraints." },
      { step: "Design", text: "Integration approach with security and access controls." },
      { step: "Build", text: "Implement, test and evaluate against real cases." },
      { step: "Operate", text: "Monitor, support and improve after launch." },
    ],
    engagement: [
      { name: "Integration Pilot", text: "One workflow connected end-to-end and evaluated." },
      { name: "Integration Programme", text: "Multiple systems and teams in planned phases." },
    ],
    faqs: [
      { q: "Can you work with legacy systems?", a: "Often, yes. Where a system has no integration point, we identify practical alternatives." },
      { q: "Where is our data processed?", a: "That is agreed during design and depends on your requirements and the services selected." },
    ],
  },
  {
    slug: "ai-solution-development",
    number: "03",
    name: "AI Solution Development",
    icon: Boxes,
    short: "Design and build AI solutions shaped around specific business requirements.",
    headline: "Build AI Solutions Around Real Business Needs.",
    intro: "When off-the-shelf tools do not fit, we design and build AI solutions around your workflows, with evaluation built in from the first prototype.",
    capabilities: [
      { title: "Custom AI applications", text: "Purpose-built tools for specific operational needs." },
      { title: "Intelligent assistants", text: "Assistants for staff or customers, grounded in your content." },
      { title: "Document intelligence", text: "Understanding and extracting information from documents." },
      { title: "Predictive analytics", text: "Models that forecast, score or flag what needs attention." },
      { title: "Prototyping", text: "Fast, testable prototypes to validate value early." },
      { title: "Evaluation and deployment", text: "Measured quality before and after release." },
    ],
    challenges: ["Generic tools do not fit the workflow", "Unclear whether an idea will work in practice", "Need for reliability and auditability"],
    useCases: ["Internal operations assistant", "Document classification and extraction", "Forecasting for planning teams"],
    approach: [
      { step: "Define", text: "Requirements, users and measures of success." },
      { step: "Prototype", text: "A working prototype tested with real examples." },
      { step: "Build", text: "Production implementation with controls." },
      { step: "Evaluate", text: "Ongoing quality measurement and refinement." },
    ],
    engagement: [
      { name: "Prototype Sprint", text: "A short engagement to validate a concept." },
      { name: "Solution Delivery", text: "Design through to production deployment." },
    ],
    faqs: [
      { q: "Who owns what is built?", a: "Ownership terms are agreed in the engagement contract before work starts." },
      { q: "How do you measure quality?", a: "Against a test set of real cases agreed with your team." },
    ],
  },
  {
    slug: "business-process-transformation",
    number: "04",
    name: "Business Process Transformation",
    icon: Workflow,
    short: "Redesign workflows first, then apply automation where it genuinely helps.",
    headline: "Improve the Workflow Before Automating It.",
    intro: "Automating a broken process only makes it fail faster. We map how work actually happens, simplify it, and then introduce AI and automation with human approval where it matters.",
    capabilities: [
      { title: "Process mapping", text: "A clear picture of how work flows today." },
      { title: "Repetitive work identification", text: "Where time goes, and which tasks repeat." },
      { title: "Workflow redesign", text: "Simpler processes with clear ownership." },
      { title: "Automation opportunities", text: "Targeted automation where it adds value." },
      { title: "Human approval workflows", text: "Review steps designed into the process." },
      { title: "Performance measurement", text: "Baselines and measures to track change." },
    ],
    challenges: ["Manual handoffs and duplicated effort", "Processes that differ by team or person", "No baseline to measure improvement"],
    useCases: ["Order-to-cash workflow redesign", "Approval routing with AI-prepared summaries", "Onboarding process automation"],
    approach: [
      { step: "Observe", text: "Walk through the process with those doing the work." },
      { step: "Simplify", text: "Remove steps that add no value." },
      { step: "Automate", text: "Apply AI and automation to the right steps." },
      { step: "Measure", text: "Compare against the baseline and refine." },
    ],
    engagement: [
      { name: "Process Review", text: "Map and redesign one end-to-end process." },
      { name: "Transformation Programme", text: "Multiple processes across functions." },
    ],
    faqs: [
      { q: "Will this replace staff?", a: "Our focus is removing repetitive work so people spend time on work that needs judgement." },
      { q: "How do you establish a baseline?", a: "By measuring the current process before changes, using available data and observation." },
    ],
  },
  {
    slug: "responsible-ai-adoption",
    number: "05",
    name: "Responsible AI Adoption",
    icon: ShieldCheck,
    short: "Put privacy, security, oversight and governance in place as AI scales.",
    headline: "Adopt AI With the Right Controls in Place.",
    intro: "Responsible AI is an operating practice. We help you define the controls, ownership and monitoring that let AI be used with confidence.",
    capabilities: [
      { title: "Privacy", text: "Clarity on what data is used, where and by whom." },
      { title: "Security", text: "Access controls and secure integration patterns." },
      { title: "Human oversight", text: "Defined review and approval points." },
      { title: "Reliability", text: "Evaluation and fallback behaviour." },
      { title: "Governance", text: "Policies, ownership and decision rights." },
      { title: "Monitoring", text: "Ongoing review of outputs and usage." },
    ],
    challenges: ["Staff using AI tools without guidance", "Uncertainty about data handling", "No defined accountability for AI outputs"],
    useCases: ["AI usage policy and guidance", "Review framework for AI-assisted decisions", "Monitoring approach for deployed systems"],
    approach: [
      { step: "Review", text: "Current AI use, data flows and risk areas." },
      { step: "Define", text: "Policies, controls and ownership." },
      { step: "Embed", text: "Controls built into workflows and systems." },
      { step: "Monitor", text: "Regular review and improvement." },
    ],
    engagement: [
      { name: "Governance Review", text: "Assessment of current AI use and gaps." },
      { name: "Governance Framework", text: "Policies, controls and monitoring established." },
    ],
    faqs: [
      { q: "Do you provide legal advice?", a: "No. We work alongside your legal and compliance advisers on operational controls." },
      { q: "Is this only for large organisations?", a: "No. Controls are scaled to how you use AI." },
    ],
  },
  {
    slug: "decision-intelligence",
    number: "06",
    name: "Decision Intelligence",
    icon: LineChart,
    short: "Turn operational data into clearer reporting, forecasts and decision support.",
    headline: "Turn Business Data Into Better Decisions.",
    intro: "We help teams spend less time assembling numbers and more time acting on them, with reporting, forecasting and decision support built on reliable data.",
    capabilities: [
      { title: "Reporting", text: "Recurring reports assembled automatically with draft commentary." },
      { title: "Analytics", text: "Clear analysis of what is changing and where." },
      { title: "Forecasting", text: "Forward-looking estimates for planning." },
      { title: "Scenario analysis", text: "Compare options before committing." },
      { title: "Decision-support systems", text: "The right information at the moment of decision." },
      { title: "Business intelligence", text: "Consistent, trusted metrics across teams." },
    ],
    challenges: ["Hours spent preparing the same reports", "Inconsistent numbers between teams", "Planning based on intuition alone"],
    useCases: ["Automated management reporting", "Demand and capacity forecasting", "Exception alerts for operational metrics"],
    approach: [
      { step: "Clarify", text: "Which decisions matter and what informs them." },
      { step: "Prepare", text: "Reliable, consistent data foundations." },
      { step: "Model", text: "Reporting, forecasts and analysis." },
      { step: "Adopt", text: "Embedded in planning and review routines." },
    ],
    engagement: [
      { name: "Reporting Assessment", text: "Review of current reporting effort and quality." },
      { name: "Decision Intelligence Build", text: "Reporting and forecasting implemented." },
    ],
    faqs: [
      { q: "Do we need a data warehouse?", a: "Not necessarily. We start with what exists and recommend changes where needed." },
      { q: "How reliable are forecasts?", a: "They are estimates with stated uncertainty, intended to support planners." },
    ],
  },
];

export const getService = (slug: string) => services.find((s) => s.slug === slug);

export const consultingOptions = {
  assessment: { key: "assessment", name: "AI Opportunity Assessment", text: "A focused engagement to validate this opportunity against your systems, data and priorities." },
  workflow: { key: "workflow", name: "AI Workflow Implementation", text: "Design, build and deploy a specific AI-enabled workflow with human oversight." },
  transformation: { key: "transformation", name: "Enterprise AI Transformation", text: "A multi-phase programme across departments, including strategy and governance." },
} as const;
export type ConsultingKey = keyof typeof consultingOptions;
