/** Company contact details as supplied by the client. */
export const contact = {
  primaryEmail: "contact@scovatics.com",
  primaryPhone: "+1 (555) 123-4567",
  emails: ["contact@scovatics.com", "sales@scovatics.com"],
  phones: ["+1 (555) 123-4567", "+1 (555) 987-6543"],
  address: ["123 Innovation Drive", "San Francisco, CA 94105", "United States"],
  hours: ["Monday – Friday: 9:00 AM – 6:00 PM PST", "Saturday – Sunday: Closed"],
};
export const telHref = (p: string) => "tel:" + p.replace(/[^\d+]/g, "");
