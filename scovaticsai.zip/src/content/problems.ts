import { Megaphone, Target, Headphones, Users, Calculator, Factory, Truck, BarChart3, FileText, GitBranch, Server, BookOpen, type LucideIcon } from "lucide-react";

export const problemAreas: { title: string; text: string; icon: LucideIcon; prompt: string; category: string }[] = [
  { title: "Marketing & Social Media Operations", text: "Content creation, scheduling and reporting that consume the team's week.", icon: Megaphone, category: "Marketing", prompt: "Our marketing team spends too much time creating, scheduling and reporting on social media content." },
  { title: "Sales & Lead Management", text: "Leads that go cold and follow-ups that slip through.", icon: Target, category: "Sales", prompt: "Our sales team struggles to prioritise and follow up with leads consistently." },
  { title: "Customer Support", text: "Repetitive queries crowding out complex customer issues.", icon: Headphones, category: "Customer Support", prompt: "My customer support team handles too many repetitive queries." },
  { title: "HR & Recruitment", text: "Screening, onboarding and policy questions handled by hand.", icon: Users, category: "HR", prompt: "Our HR team spends too much time screening candidates and answering repeated policy questions." },
  { title: "Finance & Administration", text: "Invoices, reconciliations and approvals moving slowly.", icon: Calculator, category: "Finance", prompt: "Our finance and admin team manually processes invoices and approvals." },
  { title: "Manufacturing Operations", text: "Maintenance, quality and production reporting effort.", icon: Factory, category: "Manufacturing", prompt: "Our production team spends too long on maintenance planning, quality checks and shift reporting." },
  { title: "Logistics & Supply Chain", text: "Exceptions, inventory and partner coordination.", icon: Truck, category: "Logistics", prompt: "We struggle to manage shipment exceptions and inventory planning across locations." },
  { title: "Data & Reporting", text: "Hours spent assembling the same reports.", icon: BarChart3, category: "Operations", prompt: "We spend too much time preparing reports." },
  { title: "Document Processing", text: "Forms, contracts and records entered manually.", icon: FileText, category: "Operations", prompt: "We manually process hundreds of business documents." },
  { title: "Internal Business Workflows", text: "Handoffs, approvals and duplicated effort.", icon: GitBranch, category: "Operations", prompt: "Our internal approval workflows involve many manual handoffs and duplicated work." },
  { title: "Software & IT Operations", text: "Routine IT requests and engineering overhead.", icon: Server, category: "Technology", prompt: "Our IT team is overwhelmed with routine requests and access issues." },
  { title: "Enterprise Knowledge Management", text: "Information that is hard to find when it is needed.", icon: BookOpen, category: "Operations", prompt: "Our employees struggle to find the right internal information and documents." },
];

export const examplePrompts = [
  "My customer support team handles too many repetitive queries.",
  "Our social media team spends too much time creating and managing content.",
  "We manually process hundreds of business documents.",
  "Our sales team struggles to follow up with leads.",
  "We spend too much time preparing reports.",
  "Our internal systems do not communicate with each other.",
];

export const categories = ["Marketing", "Sales", "Operations", "Customer Support", "Finance", "HR", "Manufacturing", "Logistics", "Technology", "Other"];

export const methodology = [
  { name: "Discover", text: "Understand how the business works and where effort goes." },
  { name: "Assess", text: "Evaluate data, systems and readiness for each opportunity." },
  { name: "Prioritize", text: "Rank opportunities by value, feasibility and risk." },
  { name: "Design", text: "Shape the solution, workflow and controls." },
  { name: "Implement", text: "Build, integrate and roll out in measured stages." },
  { name: "Optimize", text: "Monitor results and improve over time." },
];
