import manufacturing from "@/assets/industry-manufacturing.jpg";
import logistics from "@/assets/industry-logistics.jpg";
import finance from "@/assets/industry-finance.jpg";
import healthcare from "@/assets/industry-healthcare.jpg";
import technology from "@/assets/industry-technology.jpg";

export type Industry = {
  slug: string;
  name: string;
  image: string;
  short: string;
  intro: string;
  challenges: string[];
  opportunities: { title: string; text: string }[];
  examples: string[];
  responsible: string[];
  prompt: string;
};

export const industries: Industry[] = [
  {
    slug: "manufacturing", name: "Manufacturing", image: manufacturing,
    short: "Maintenance, quality, reporting and production planning.",
    intro: "Manufacturers generate large amounts of operational data, yet much of the planning, inspection and reporting effort remains manual.",
    challenges: ["Unplanned equipment downtime", "Manual quality inspection and variability", "Time-consuming production reporting", "Planning with incomplete visibility"],
    opportunities: [
      { title: "Predictive maintenance", text: "Flag equipment likely to need attention using sensor and maintenance history." },
      { title: "Quality inspection support", text: "Help inspectors identify possible defects for confirmation." },
      { title: "Operational reporting", text: "Assemble shift and production reports automatically." },
      { title: "Production planning", text: "Support planners with demand and capacity estimates." },
    ],
    examples: ["Shift handover summaries drafted from production logs", "Maintenance prioritisation from sensor alerts", "Supplier document processing"],
    responsible: ["Safety-related decisions remain with qualified staff", "Predictions are probabilistic and need validation"],
    prompt: "We are a manufacturer and our maintenance, quality checks and production reporting take too much manual effort.",
  },
  {
    slug: "logistics", name: "Logistics & Supply Chain", image: logistics,
    short: "Inventory, exceptions, forecasting and documents.",
    intro: "Logistics teams manage constant change across shipments, inventory and partners, often through email, spreadsheets and documents.",
    challenges: ["Shipment exceptions found too late", "Inventory imbalance across locations", "High volume of shipping documents", "Forecasts that rely on manual adjustment"],
    opportunities: [
      { title: "Inventory planning", text: "Better visibility of stock needs by location." },
      { title: "Shipment exception handling", text: "Detect at-risk shipments and draft communications." },
      { title: "Demand forecasting", text: "Forecasts that support planners' decisions." },
      { title: "Document processing", text: "Extract data from bills of lading, invoices and customs forms." },
    ],
    examples: ["Delay alerts with drafted customer updates", "Automated proof-of-delivery matching", "Carrier invoice reconciliation"],
    responsible: ["Customer-facing messages reviewed where needed", "Data sharing with partners governed by agreement"],
    prompt: "Our logistics team spends too much time handling shipment exceptions and processing shipping documents.",
  },
  {
    slug: "finance", name: "Finance", image: finance,
    short: "Document intelligence, reporting, anomaly detection and decision support.",
    intro: "Finance teams carry significant document and reporting workloads, with high expectations for accuracy and auditability.",
    challenges: ["Manual document review and data entry", "Time spent preparing recurring reports", "Detecting unusual transactions", "Limited time for analysis"],
    opportunities: [
      { title: "Document intelligence", text: "Extract and validate data from financial documents." },
      { title: "Reporting assistance", text: "Assemble reports with draft commentary." },
      { title: "Anomaly detection", text: "Highlight unusual entries for review." },
      { title: "Decision support", text: "Scenario and forecast support for planning." },
    ],
    examples: ["Invoice extraction into accounts payable", "Month-end variance commentary drafts", "Expense anomaly review queue"],
    responsible: ["Auditability of AI-assisted steps", "Human sign-off on financial decisions", "Strict access controls on financial data"],
    prompt: "Our finance team manually processes many documents and spends days preparing monthly reports.",
  },
  {
    slug: "healthcare", name: "Healthcare", image: healthcare,
    short: "Administrative workflows, scheduling, forecasting and knowledge.",
    intro: "Healthcare organisations face significant administrative load. We focus on operational and administrative work, not clinical decision-making.",
    challenges: ["Administrative workload on staff", "Complex scheduling constraints", "Fluctuating demand", "Hard-to-find internal guidance"],
    opportunities: [
      { title: "Administrative workflows", text: "Reduce manual handling of forms and correspondence." },
      { title: "Scheduling assistance", text: "Propose schedules that respect constraints." },
      { title: "Operational forecasting", text: "Anticipate demand for planning." },
      { title: "Knowledge management", text: "Help staff find approved internal guidance." },
    ],
    examples: ["Referral document intake", "Staff rota drafting support", "Internal policy assistant"],
    responsible: ["Patient data protection is paramount", "No autonomous clinical decisions", "Compliance with applicable health data regulation"],
    prompt: "Our healthcare administration team is overloaded with forms, scheduling and correspondence.",
  },
  {
    slug: "technology", name: "Technology", image: technology,
    short: "Development workflows, knowledge, support and product intelligence.",
    intro: "Technology companies move quickly, and internal knowledge, support and engineering workflows often struggle to keep up.",
    challenges: ["Knowledge scattered across tools", "Growing support volume", "Engineering time lost to routine tasks", "Product feedback hard to synthesise"],
    opportunities: [
      { title: "Software development workflows", text: "Assist with reviews, documentation and routine tasks." },
      { title: "Internal knowledge systems", text: "Answers grounded in your documentation." },
      { title: "Support automation", text: "Triage and draft responses for support teams." },
      { title: "Product intelligence", text: "Synthesise feedback and usage signals." },
    ],
    examples: ["Support ticket triage", "Engineering documentation assistant", "Customer feedback theme analysis"],
    responsible: ["Generated code is reviewed and tested", "Customer data handled under existing policies"],
    prompt: "Our support team and engineers spend too much time on repetitive questions and finding internal information.",
  },
];

export const getIndustry = (slug: string) => industries.find((i) => i.slug === slug);
