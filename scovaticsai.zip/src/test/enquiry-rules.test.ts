import { describe, it, expect } from "vitest";
import { enquirySchema, makeEnquiryRef } from "@/lib/enquiry-schema";

const valid = { fullName: "Jane Doe", email: "jane@acme.com", company: "Acme", jobRole: "COO", companySize: "51–200", country: "India", interest: "AI Opportunity Assessment", timeframe: "Within 3 months", message: "", consent: true as const, assessmentToken: null, source: "contact" as const };

describe("enquiry rules", () => {
  it("accepts a complete business enquiry", () => { expect(enquirySchema.safeParse(valid).success).toBe(true); });
  it("rejects submission without consent", () => { expect(enquirySchema.safeParse({ ...valid, consent: false }).success).toBe(false); });
  it("rejects personal email domains", () => { expect(enquirySchema.safeParse({ ...valid, email: "jane@gmail.com" }).success).toBe(false); });
  it("requires company size from the list", () => { expect(enquirySchema.safeParse({ ...valid, companySize: "huge" }).success).toBe(false); });
  it("generates enquiry ids in SCV-YYMMDD-XXXXXX format", () => { expect(makeEnquiryRef(new Date("2026-11-10T00:00:00Z"), () => 0)).toBe("SCV-261110-AAAAAA"); });
});
