export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      assessments: {
        Row: {
          access_token: string
          answers: Json
          category: string | null
          created_at: string
          id: string
          problem: string
          questions: Json
          status: string
          understanding: Json | null
          updated_at: string
        }
        Insert: {
          access_token?: string
          answers?: Json
          category?: string | null
          created_at?: string
          id?: string
          problem: string
          questions?: Json
          status?: string
          understanding?: Json | null
          updated_at?: string
        }
        Update: {
          access_token?: string
          answers?: Json
          category?: string | null
          created_at?: string
          id?: string
          problem?: string
          questions?: Json
          status?: string
          understanding?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      blog_posts: {
        Row: {
          body: string
          category: string
          created_at: string
          excerpt: string
          id: string
          published: boolean
          published_at: string
          slug: string
          title: string
        }
        Insert: {
          body: string
          category: string
          created_at?: string
          excerpt: string
          id?: string
          published?: boolean
          published_at?: string
          slug: string
          title: string
        }
        Update: {
          body?: string
          category?: string
          created_at?: string
          excerpt?: string
          id?: string
          published?: boolean
          published_at?: string
          slug?: string
          title?: string
        }
        Relationships: []
      }
      case_studies: {
        Row: {
          approach: string
          business_problem: string
          client_context: string
          created_at: string
          id: string
          illustrative: boolean
          implementation: string
          industry: string
          lessons: string
          outcomes: string
          published: boolean
          slug: string
          title: string
        }
        Insert: {
          approach: string
          business_problem: string
          client_context: string
          created_at?: string
          id?: string
          illustrative?: boolean
          implementation: string
          industry: string
          lessons: string
          outcomes: string
          published?: boolean
          slug: string
          title: string
        }
        Update: {
          approach?: string
          business_problem?: string
          client_context?: string
          created_at?: string
          id?: string
          illustrative?: boolean
          implementation?: string
          industry?: string
          lessons?: string
          outcomes?: string
          published?: boolean
          slug?: string
          title?: string
        }
        Relationships: []
      }
      consent_records: {
        Row: {
          consent_text: string
          created_at: string
          id: string
          lead_id: string
        }
        Insert: {
          consent_text: string
          created_at?: string
          id?: string
          lead_id: string
        }
        Update: {
          consent_text?: string
          created_at?: string
          id?: string
          lead_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "consent_records_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      faqs: {
        Row: {
          answer: string
          id: string
          published: boolean
          question: string
          sort_order: number
          topic: string
        }
        Insert: {
          answer: string
          id?: string
          published?: boolean
          question: string
          sort_order?: number
          topic: string
        }
        Update: {
          answer?: string
          id?: string
          published?: boolean
          question?: string
          sort_order?: number
          topic?: string
        }
        Relationships: []
      }
      leads: {
        Row: {
          assessment_id: string | null
          assigned_to: string | null
          company: string
          company_size: string
          country: string
          created_at: string
          email: string
          enquiry_ref: string
          full_name: string
          id: string
          interest: string
          job_role: string
          message: string | null
          next_follow_up: string | null
          notes: string | null
          source: string
          status: string
          timeframe: string
          updated_at: string
        }
        Insert: {
          assessment_id?: string | null
          assigned_to?: string | null
          company: string
          company_size: string
          country: string
          created_at?: string
          email: string
          enquiry_ref: string
          full_name: string
          id?: string
          interest: string
          job_role: string
          message?: string | null
          next_follow_up?: string | null
          notes?: string | null
          source?: string
          status?: string
          timeframe: string
          updated_at?: string
        }
        Update: {
          assessment_id?: string | null
          assigned_to?: string | null
          company?: string
          company_size?: string
          country?: string
          created_at?: string
          email?: string
          enquiry_ref?: string
          full_name?: string
          id?: string
          interest?: string
          job_role?: string
          message?: string | null
          next_follow_up?: string | null
          notes?: string | null
          source?: string
          status?: string
          timeframe?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "leads_assessment_id_fkey"
            columns: ["assessment_id"]
            isOneToOne: false
            referencedRelation: "assessments"
            referencedColumns: ["id"]
          },
        ]
      }
      opportunity_reports: {
        Row: {
          assessment_id: string
          created_at: string
          id: string
          report: Json
        }
        Insert: {
          assessment_id: string
          created_at?: string
          id?: string
          report: Json
        }
        Update: {
          assessment_id?: string
          created_at?: string
          id?: string
          report?: Json
        }
        Relationships: [
          {
            foreignKeyName: "opportunity_reports_assessment_id_fkey"
            columns: ["assessment_id"]
            isOneToOne: true
            referencedRelation: "assessments"
            referencedColumns: ["id"]
          },
        ]
      }
      use_case_library: {
        Row: {
          active: boolean
          ai_application: string
          created_at: string
          dependencies: string | null
          functions: string[]
          id: string
          industries: string[]
          limitations: string | null
          problem_category: string
          summary: string
          title: string
        }
        Insert: {
          active?: boolean
          ai_application: string
          created_at?: string
          dependencies?: string | null
          functions?: string[]
          id?: string
          industries?: string[]
          limitations?: string | null
          problem_category: string
          summary: string
          title: string
        }
        Update: {
          active?: boolean
          ai_application?: string
          created_at?: string
          dependencies?: string | null
          functions?: string[]
          id?: string
          industries?: string[]
          limitations?: string | null
          problem_category?: string
          summary?: string
          title?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_first_admin: { Args: never; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
